#!/usr/bin/env python3
"""Regression check for the bundled iraq_classic template pack.

This mirrors the current Android template classifier's 24x24 RGB feature resize,
mean absolute distance, distance threshold, confidence threshold and ambiguity gate.
It validates the supplied initial-position screenshot against all 26 packaged templates.
It is an asset-level regression check, not a substitute for on-device MediaProjection tests.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import sys

try:
    import numpy as np
    from PIL import Image
except ImportError as exc:  # pragma: no cover - CI installs these dependencies
    raise SystemExit("Install requirements with: python -m pip install Pillow numpy") from exc

ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = ROOT / "app/src/main/assets/piece_templates/iraq_classic"
REFERENCE = ROOT / "tools/fixtures/starting_position_reference.png"
EXPECTED_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
MAX_DISTANCE = 0.20
MIN_CONFIDENCE = 0.82
MIN_MARGIN = 0.008
FEATURE_SIZE = (24, 24)


def feature(image: Image.Image) -> np.ndarray:
    resized = image.convert("RGB").resize(FEATURE_SIZE, Image.Resampling.BILINEAR)
    return np.asarray(resized, dtype=np.float32).reshape(-1) / 255.0


def square_color_name(cell: Image.Image, palette: dict[str, tuple[int, int, int]]) -> str:
    px = np.asarray(cell.convert("RGB"), dtype=np.uint8)
    samples = [px[3, 3], px[3, -4], px[-4, 3], px[-4, -4]]
    colors = [tuple(int(v) for v in p) for p in samples]
    dominant = Counter(colors).most_common(1)[0][0]
    nearest = min(palette, key=lambda key: sum((dominant[i] - palette[key][i]) ** 2 for i in range(3)))
    error = sum((dominant[i] - palette[nearest][i]) ** 2 for i in range(3)) ** 0.5
    if error > 8:
        raise AssertionError(f"Unknown board square color {dominant}; distance={error:.2f}")
    return nearest


def fen_placement(pieces: dict[str, str]) -> str:
    rows: list[str] = []
    for rank in range(8, 0, -1):
        out = ""
        empties = 0
        for file_index in range(8):
            square = f"{chr(ord('a') + file_index)}{rank}"
            piece = pieces.get(square)
            if piece is None:
                empties += 1
            else:
                if empties:
                    out += str(empties)
                    empties = 0
                out += piece
        if empties:
            out += str(empties)
        rows.append(out)
    return "/".join(rows)


def main() -> None:
    required = {"empty_light.png", "empty_dark.png"}
    required |= {f"{piece}_{color}.png" for piece in "PNBRQKpnbrqk" for color in ("light", "dark")}
    actual = {p.name for p in TEMPLATES.glob("*.png")}
    if actual != required:
        raise AssertionError(f"Expected 26 exact PNG names; missing={sorted(required-actual)}, extra={sorted(actual-required)}")
    print("PASS: template pack contains exactly 26 required PNGs")

    palette: dict[str, tuple[int, int, int]] = {}
    template_features: dict[str, np.ndarray] = {}
    for name in ("light", "dark"):
        image = Image.open(TEMPLATES / f"empty_{name}.png").convert("RGB")
        px = np.asarray(image)
        palette[name] = tuple(int(v) for v in px[3, 3])
    for path in sorted(TEMPLATES.glob("*.png")):
        with Image.open(path) as image:
            if image.width < 32 or image.height < 32 or image.width > 512 or image.height > 512:
                raise AssertionError(f"Invalid dimensions: {path.name} {image.size}")
            if abs(image.width - image.height) / max(image.size) > 0.15:
                raise AssertionError(f"Template is not square enough: {path.name} {image.size}")
            template_features[path.stem] = feature(image)
    print("PASS: every template is readable, square, and within importer dimensions")

    board = Image.open(REFERENCE).convert("RGB")
    if board.width != board.height or board.width < 160:
        raise AssertionError(f"Reference board must be square and at least 160px: {board.size}")
    width = board.width
    pixels = np.asarray(board)
    recognized: dict[str, str] = {}
    mismatches: list[str] = []
    min_margin = float("inf")
    max_distance = 0.0

    for row in range(8):
        for col in range(8):
            x0, x1 = int(col * width / 8), int((col + 1) * width / 8)
            y0, y1 = int(row * width / 8), int((row + 1) * width / 8)
            cell = Image.fromarray(pixels[y0:y1, x0:x1])
            bg = square_color_name(cell, palette)
            if row == 0:
                expected_piece = "rnbqkbnr"[col]
            elif row == 1:
                expected_piece = "p"
            elif row == 6:
                expected_piece = "P"
            elif row == 7:
                expected_piece = "RNBQKBNR"[col]
            else:
                expected_piece = None
            expected_template = f"{expected_piece}_{bg}" if expected_piece else f"empty_{bg}"
            vector = feature(cell)
            ranked = sorted(
                (float(np.mean(np.abs(vector - candidate))), name)
                for name, candidate in template_features.items()
            )
            best_distance, best_name = ranked[0]
            second_distance = ranked[1][0]
            margin = second_distance - best_distance
            confidence = max(0.0, min(1.0, 1.0 - best_distance / MAX_DISTANCE))
            max_distance = max(max_distance, best_distance)
            min_margin = min(min_margin, margin)
            if best_distance > MAX_DISTANCE or confidence < MIN_CONFIDENCE or margin < MIN_MARGIN:
                raise AssertionError(
                    f"Ambiguous square {chr(97+col)}{8-row}: best={best_name}, "
                    f"distance={best_distance:.5f}, confidence={confidence:.3f}, margin={margin:.5f}"
                )
            if best_name != expected_template:
                mismatches.append(
                    f"{chr(97+col)}{8-row}: expected {expected_template}, got {best_name}, d={best_distance:.5f}"
                )
            if not best_name.startswith("empty_"):
                recognized[f"{chr(97+col)}{8-row}"] = best_name[0]

    if mismatches:
        raise AssertionError("Incorrect squares:\n" + "\n".join(mismatches))
    print("PASS: 64/64 squares classified with the expected template")
    print(f"PASS: confidence gates; max distance={max_distance:.5f}, min margin={min_margin:.5f}")

    if len(recognized) != 32:
        raise AssertionError(f"Expected 32 pieces, found {len(recognized)}")
    counts = Counter(recognized.values())
    white_count = sum(counts[p] for p in "PNBRQK")
    black_count = sum(counts[p] for p in "pnbrqk")
    if (white_count, black_count) != (16, 16):
        raise AssertionError(f"Expected 16 white and 16 black pieces; got {white_count}/{black_count}")
    print("PASS: 32 pieces detected (16 white, 16 black)")

    placement = fen_placement(recognized)
    fen = placement + " w KQkq - 0 1"
    if fen != EXPECTED_FEN:
        raise AssertionError(f"FEN mismatch:\nexpected: {EXPECTED_FEN}\nactual:   {fen}")
    print("PASS: FEN matches the standard starting position exactly")
    print("VISION_REFERENCE_CHECK: 64/64 squares, 32/32 pieces, exact FEN")


if __name__ == "__main__":
    main()
