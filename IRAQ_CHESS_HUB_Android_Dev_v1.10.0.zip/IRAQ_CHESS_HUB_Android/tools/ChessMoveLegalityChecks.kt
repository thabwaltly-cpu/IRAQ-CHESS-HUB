import com.iraqchesshub.game.ChessMoveLegality
import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.MoveDeltaDetector

private fun verify(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

private fun position(board: Map<String, Char>, metadata: FenMetadata = FenMetadata('w')): FenPosition =
    requireNotNull(FenPosition.fromPieceMap(board, metadata)) { "invalid test position: $board / $metadata" }

private fun move(
    uci: String,
    promotion: Char? = null,
    castling: Boolean = false,
    capturedOn: String? = null
) = MoveDeltaDetector.MoveDelta(
    uci = uci,
    from = uci.take(2),
    to = uci.substring(2, 4),
    promotion = promotion,
    isCastling = castling,
    capturedOn = capturedOn
)

fun main() {
    val start = position(mapOf(
        "e1" to 'K', "e8" to 'k', "e2" to 'P', "e7" to 'p',
        "b1" to 'N', "c1" to 'B', "a1" to 'R', "d1" to 'Q', "d2" to 'P'
    ))
    verify("legal white pawn single step", ChessMoveLegality.isLegal(start, move("e2e3")))
    verify("legal white pawn double step", ChessMoveLegality.isLegal(start, move("e2e4")))
    verify("reject pawn moving three squares", !ChessMoveLegality.isLegal(start, move("e2e5")))
    verify("reject pawn moving backwards", !ChessMoveLegality.isLegal(start, move("e2e1")))
    verify("reject move by side not on turn", !ChessMoveLegality.isLegal(start, move("e7e6")))
    verify("legal knight L move", ChessMoveLegality.isLegal(start, move("b1a3")))
    verify("reject invalid knight move", !ChessMoveLegality.isLegal(start, move("b1b3")))
    verify("reject bishop blocked by own pawn", !ChessMoveLegality.isLegal(start, move("c1h6")))
    verify("reject rook diagonal move", !ChessMoveLegality.isLegal(start, move("a1b2")))
    verify("reject queen jumping over blocker", !ChessMoveLegality.isLegal(start, move("d1d7")))
    verify("reject king capturing opposing king", !ChessMoveLegality.isLegal(
        position(mapOf("e1" to 'K', "e3" to 'k')), move("e1e3", capturedOn = "e3")
    ))

    val capture = position(mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P', "d5" to 'p'))
    verify("legal pawn capture on destination", ChessMoveLegality.isLegal(capture, move("e4d5", capturedOn = "d5")))
    verify("reject capture without capture marker", !ChessMoveLegality.isLegal(capture, move("e4d5")))
    verify("reject pawn diagonal move to empty square", !ChessMoveLegality.isLegal(
        position(mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P')), move("e4d5")
    ))

    val blackTurn = position(
        mapOf("e1" to 'K', "e8" to 'k', "e7" to 'p', "d6" to 'P'),
        FenMetadata('b')
    )
    verify("legal black pawn double step", ChessMoveLegality.isLegal(blackTurn, move("e7e5")))
    verify("legal black pawn capture", ChessMoveLegality.isLegal(blackTurn, move("e7d6", capturedOn = "d6")))

    val clearSliders = position(mapOf("h1" to 'K', "a8" to 'k', "c3" to 'B', "e1" to 'R'))
    verify("legal bishop diagonal move", ChessMoveLegality.isLegal(clearSliders, move("c3f6")))
    verify("legal rook straight move", ChessMoveLegality.isLegal(clearSliders, move("e1e4")))
    val queenPosition = position(mapOf("h1" to 'K', "a8" to 'k', "d4" to 'Q'))
    verify("legal queen diagonal move", ChessMoveLegality.isLegal(queenPosition, move("d4g7")))

    val pinned = position(mapOf("e1" to 'K', "e2" to 'R', "e8" to 'r', "a8" to 'k'))
    verify("reject pinned rook move exposing king", !ChessMoveLegality.isLegal(pinned, move("e2f2")))

    val kingStep = position(mapOf("e1" to 'K', "e8" to 'k', "d2" to 'r'))
    verify("reject king move onto attacked square", !ChessMoveLegality.isLegal(kingStep, move("e1e2")))

    val ep = position(
        mapOf("e1" to 'K', "e8" to 'k', "e5" to 'P', "d5" to 'p'),
        FenMetadata('w', "-", "d6")
    )
    verify("legal en-passant with trusted target", ChessMoveLegality.isLegal(ep, move("e5d6", capturedOn = "d5")))
    val noEp = position(mapOf("e1" to 'K', "e8" to 'k', "e5" to 'P', "d5" to 'p'))
    verify("reject en-passant without FEN target", !ChessMoveLegality.isLegal(noEp, move("e5d6", capturedOn = "d5")))

    val promote = position(mapOf("e1" to 'K', "e8" to 'k', "a7" to 'P'))
    verify("legal queen promotion", ChessMoveLegality.isLegal(promote, move("a7a8q", promotion = 'q')))
    verify("legal underpromotion to knight", ChessMoveLegality.isLegal(promote, move("a7a8n", promotion = 'n')))
    verify("reject promotion without promoted piece", !ChessMoveLegality.isLegal(promote, move("a7a8")))
    verify("reject promotion before last rank", !ChessMoveLegality.isLegal(promote, move("a7a8q", promotion = 'k')))

    val castle = position(
        mapOf("a8" to 'k', "e1" to 'K', "h1" to 'R'),
        FenMetadata('w', "K")
    )
    verify("legal kingside castling", ChessMoveLegality.isLegal(castle, move("e1g1", castling = true)))
    verify("reject castling without explicit castling marker", !ChessMoveLegality.isLegal(castle, move("e1g1")))
    verify("reject castling without right", !ChessMoveLegality.isLegal(
        position(mapOf("a8" to 'k', "e1" to 'K', "h1" to 'R')), move("e1g1", castling = true)
    ))
    val attackedTransit = position(
        mapOf("a8" to 'k', "f8" to 'r', "e1" to 'K', "h1" to 'R'),
        FenMetadata('w', "K")
    )
    verify("reject castling through attacked transit square", !ChessMoveLegality.isLegal(attackedTransit, move("e1g1", castling = true)))
    val inCheckCastle = position(
        mapOf("a8" to 'k', "e8" to 'r', "e1" to 'K', "h1" to 'R'),
        FenMetadata('w', "K")
    )
    verify("reject castling while king is in check", !ChessMoveLegality.isLegal(inCheckCastle, move("e1g1", castling = true)))
    val queenSideCastle = position(
        mapOf("a8" to 'k', "a1" to 'R', "e1" to 'K'),
        FenMetadata('w', "Q")
    )
    verify("legal queenside castling", ChessMoveLegality.isLegal(queenSideCastle, move("e1c1", castling = true)))

    println("32 chess move legality checks passed")
}
