import com.iraqchesshub.analysis.LiveChessAnalysisSession
import com.iraqchesshub.analysis.PositionAnalyzer
import com.iraqchesshub.analysis.EngineScore
import com.iraqchesshub.engine.EngineResult
import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.LiveBoardTracker

private fun verifySession(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

fun main() {
    val before = mapOf("e1" to 'K', "e8" to 'k', "e2" to 'P', "e7" to 'p')
    val after = before - "e2" + ("e4" to 'P')
    var calls = 0
    var requestedDepth = 0
    var analyzedFen = ""
    val fakeAnalyzer = PositionAnalyzer { position, depth ->
        calls++
        requestedDepth = depth
        analyzedFen = position.toFen()
        EngineResult("e7e5", EngineScore(centipawns = 31), 9, listOf("e7e5", "g1f3"))
    }
    val session = LiveChessAnalysisSession(LiveBoardTracker(3), fakeAnalyzer, depth = 9)
    verifySession("trusted FEN seed accepted", session.seed(before, FenMetadata('w')) != null)
    verifySession("analysis not run on first transient frame", session.accept(after, 0.99f) is LiveChessAnalysisSession.Update.Tracking)
    verifySession("analysis not run on second transient frame", session.accept(after, 0.99f) is LiveChessAnalysisSession.Update.Tracking)
    val completed = session.accept(after, 0.99f)
    verifySession("stable move flows to position analysis", completed is LiveChessAnalysisSession.Update.AnalysisCompleted)
    verifySession("engine receives requested search depth", requestedDepth == 9)
    verifySession("engine receives the verified FEN", analyzedFen == "4k3/4p3/8/8/4P3/8/8/4K3 b - e3 0 1")
    verifySession("engine analyzed exactly once", calls == 1)
    verifySession("best move and numeric score returned", completed is LiveChessAnalysisSession.Update.AnalysisCompleted && completed.result.bestMoveUci == "e7e5" && completed.result.score == EngineScore(centipawns = 31))
    verifySession("accepted FEN is retained in analysis result", completed is LiveChessAnalysisSession.Update.AnalysisCompleted && completed.position.toFen() == "4k3/4p3/8/8/4P3/8/8/4K3 b - e3 0 1")
    val unchanged = session.accept(after, 0.99f)
    verifySession("repeated screen frames do not re-run engine", unchanged is LiveChessAnalysisSession.Update.Tracking && calls == 1)
    verifySession("no pending request remains after success", session.pendingPosition() == null)
    verifySession("retry without failed request is a no-op", session.retryPendingAnalysis() is LiveChessAnalysisSession.Update.NoPendingAnalysis)

    var retryCalls = 0
    var retryFen = ""
    val retryAnalyzer = PositionAnalyzer { position, depth ->
        retryCalls++
        retryFen = position.toFen()
        if (retryCalls == 1) error("engine not ready")
        EngineResult("g8f6", EngineScore(mateIn = 3), depth, listOf("g8f6"))
    }
    val retrySession = LiveChessAnalysisSession(LiveBoardTracker(2), retryAnalyzer, depth = 12)
    retrySession.seed(before, FenMetadata('w'))
    retrySession.accept(after, 0.99f)
    val failed = retrySession.accept(after, 0.99f)
    verifySession("engine error is surfaced instead of swallowed", failed is LiveChessAnalysisSession.Update.AnalysisFailed && failed.reason == "engine not ready")
    verifySession("failed analysis remains retryable", retrySession.pendingPosition() != null && retryFen == "4k3/4p3/8/8/4P3/8/8/4K3 b - e3 0 1")
    val retried = retrySession.retryPendingAnalysis()
    verifySession("pending analysis succeeds on retry", retried is LiveChessAnalysisSession.Update.AnalysisCompleted && retried.result.score?.mateIn == 3)
    verifySession("retry clears pending analysis", retrySession.pendingPosition() == null && retryCalls == 2)

    val blockedCastleBefore = mapOf("e1" to 'K', "h1" to 'R', "f1" to 'N', "e8" to 'k')
    val blockedCastleAfter = blockedCastleBefore - "e1" - "h1" - "f1" + ("g1" to 'K') + ("f1" to 'R')
    val castleTracker = LiveBoardTracker(2)
    verifySession("blocked-castle test seed accepted", castleTracker.seed(blockedCastleBefore, FenMetadata('w', "K")) != null)
    castleTracker.accept(blockedCastleAfter, 0.99f)
    val blockedCastle = castleTracker.accept(blockedCastleAfter, 0.99f)
    verifySession("reject castling when a path square is occupied", blockedCastle == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.TRANSITION_MISMATCH))

    var invalidDepthRejected = false
    try {
        LiveChessAnalysisSession(LiveBoardTracker(), fakeAnalyzer, depth = 31)
    } catch (_: IllegalArgumentException) {
        invalidDepthRejected = true
    }
    verifySession("reject engine depth outside supported range", invalidDepthRejected)

    println("19 live analysis session checks passed")
}
