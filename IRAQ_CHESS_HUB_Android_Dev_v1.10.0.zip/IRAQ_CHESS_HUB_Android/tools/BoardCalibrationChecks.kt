import com.iraqchesshub.vision.BoardCalibration

fun main() {
    val portrait = BoardCalibration(left = 0.05f, top = 0.20f, size = 0.80f)
    val portraitBounds = portrait.pixelBounds(1080, 2400)
    check(portraitBounds != null)
    check(portraitBounds.left == 54 && portraitBounds.top == 480)
    check(portraitBounds.width == 864 && portraitBounds.height == 864)

    // Same normalized size uses the shorter axis, not the width, in landscape.
    val landscape = BoardCalibration(left = 0.70f, top = 0.05f, size = 0.80f)
    check(landscape.pixelBounds(2400, 1080) == null) // right edge would exceed the frame

    val fitsLandscape = BoardCalibration(left = 0.10f, top = 0.05f, size = 0.80f)
    val landscapeBounds = fitsLandscape.pixelBounds(2400, 1080)
    check(landscapeBounds != null)
    check(landscapeBounds.left == 240 && landscapeBounds.top == 54)
    check(landscapeBounds.width == 864 && landscapeBounds.height == 864)

    check(BoardCalibration(0f, 0f, 0.2f).pixelBounds(100, 100) == null)
    check(BoardCalibration(0f, 0f, 0.5f).pixelBounds(0, 100) == null)
    check(portrait.squareCenter("e4") != null)
    check(portrait.squareCenter("z9") == null)
    println("BoardCalibration: 9 checks passed")
}
