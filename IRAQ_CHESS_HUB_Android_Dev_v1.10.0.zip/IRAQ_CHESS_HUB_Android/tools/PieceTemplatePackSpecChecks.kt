import com.iraqchesshub.vision.PieceTemplatePackSpec

private fun verifyPack(name: String, ok: Boolean) { check(ok) { "FAILED: $name" }; println("PASS: $name") }

fun main() {
    verifyPack("template manifest contains exactly 26 images", PieceTemplatePackSpec.requiredFiles.size == 26)
    verifyPack("manifest includes both empty-square colors", setOf("empty_light.png", "empty_dark.png").all { it in PieceTemplatePackSpec.requiredFiles })
    verifyPack("manifest includes every white and black piece color", "PNBRQKpnbrqk".all { p -> listOf("${p}_light.png", "${p}_dark.png").all { it in PieceTemplatePackSpec.requiredFiles } })
    verifyPack("theme accepts safe ASCII name", PieceTemplatePackSpec.isValidTheme("chess_com_classic-1"))
    verifyPack("theme rejects path traversal", !PieceTemplatePackSpec.isValidTheme("../classic"))
    verifyPack("theme rejects long names", !PieceTemplatePackSpec.isValidTheme("a".repeat(49)))
    verifyPack("accepts file at ZIP root", PieceTemplatePackSpec.safeEntryFileName("P_light.png") == "P_light.png")
    verifyPack("accepts one common folder in ZIP", PieceTemplatePackSpec.safeEntryFileName("classic/P_light.png") == "P_light.png")
    verifyPack("rejects parent traversal", PieceTemplatePackSpec.safeEntryFileName("../P_light.png") == null)
    verifyPack("rejects nested arbitrary paths", PieceTemplatePackSpec.safeEntryFileName("root/sub/P_light.png") == null)
    verifyPack("rejects unknown archive files", PieceTemplatePackSpec.safeEntryFileName("readme.txt") == null)
    verifyPack("rejects backslash paths", PieceTemplatePackSpec.safeEntryFileName("root\\P_light.png") == null)
    println("12 template-pack rule checks passed")
}
