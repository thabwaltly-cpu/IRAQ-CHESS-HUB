import com.iraqchesshub.analysis.*
import com.iraqchesshub.engine.EngineResult
import com.iraqchesshub.game.*
import com.iraqchesshub.vision.*

private fun verifyRuntime(name: String, ok: Boolean) { check(ok) { "FAILED: $name" }; println("PASS: $name") }
private fun obs(board: Map<String, Char>, confidence: Float = 0.99f) = BoardObservation(
    board.map { (square, symbol) -> DetectedPiece(square, symbol, confidence) }, confidence
)

fun main() {
    val initial = mapOf("e1" to 'K', "e8" to 'k', "e2" to 'P', "e7" to 'p')
    val metadata = FenMetadata('w')
    val expected = requireNotNull(FenPosition.fromPieceMap(initial, metadata))
    val analyzer = PositionAnalyzer { _, depth -> EngineResult("e7e5", null, depth, listOf("e7e5")) }
    val coordinator = RecognizedBoardAnalysisCoordinator(LiveChessAnalysisSession(LiveBoardTracker(3), analyzer, 8))
    val runtime = RecognizedBoardCaptureRuntime(expected, coordinator, seedStableFrames = 3)
    verifyRuntime("first matching seed frame waits", runtime.process(obs(initial)) is RecognizedBoardCaptureRuntime.Result.WaitingForSeedStability)
    verifyRuntime("second matching seed frame waits", runtime.process(obs(initial)) is RecognizedBoardCaptureRuntime.Result.WaitingForSeedStability)
    verifyRuntime("third matching seed frame commits trusted FEN", runtime.process(obs(initial)) is RecognizedBoardCaptureRuntime.Result.Seeded)
    verifyRuntime("seeded runtime exposes current FEN", runtime.currentPosition()?.toFen() == expected.toFen())

    val mismatchRuntime = RecognizedBoardCaptureRuntime(expected, RecognizedBoardAnalysisCoordinator(
        LiveChessAnalysisSession(LiveBoardTracker(), analyzer)
    ))
    val mismatchBoard = initial - "e2" + ("e3" to 'P')
    verifyRuntime("different visible placement cannot seed trusted FEN", mismatchRuntime.process(obs(mismatchBoard)) is RecognizedBoardCaptureRuntime.Result.SeedPlacementMismatch)
    verifyRuntime("low-confidence seed frame is rejected", mismatchRuntime.process(obs(initial, 0.70f)) == RecognizedBoardCaptureRuntime.Result.InvalidObservation)
    mismatchRuntime.process(obs(initial))
    mismatchRuntime.process(obs(initial))
    verifyRuntime("seed requires three new matching frames after mismatch", mismatchRuntime.process(obs(initial)) is RecognizedBoardCaptureRuntime.Result.Seeded)

    val after = initial - "e2" + ("e4" to 'P')
    runtime.process(obs(after))
    runtime.process(obs(after))
    val accepted = runtime.process(obs(after))
    verifyRuntime(
        "stable post-seed board change reaches coordinator",
        accepted is RecognizedBoardCaptureRuntime.Result.Update &&
            accepted.value is RecognizedBoardAnalysisCoordinator.Result.Update &&
            accepted.value.value is LiveChessAnalysisSession.Update.AnalysisCompleted
    )

    val noSeed = RecognizedBoardCaptureRuntime(null, RecognizedBoardAnalysisCoordinator(
        LiveChessAnalysisSession(LiveBoardTracker(), analyzer)
    ))
    verifyRuntime("missing FEN reports needs trusted seed", noSeed.process(obs(initial)) is RecognizedBoardCaptureRuntime.Result.NeedsTrustedSeed)
    println("9 capture-runtime checks passed")
}
