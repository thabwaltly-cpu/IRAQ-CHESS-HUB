import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.GameOutcome
import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.LiveBoardTracker
import com.iraqchesshub.game.MoveDeltaDetector

private fun verify(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

private fun awaitMove(
    tracker: LiveBoardTracker,
    before: Map<String, Char>,
    after: Map<String, Char>,
    metadata: FenMetadata
): LiveBoardTracker.Update {
    check(tracker.seed(before, metadata) != null) { "test seed must be valid" }
    tracker.accept(after, 0.99f)
    tracker.accept(after, 0.99f)
    return tracker.accept(after, 0.99f)
}


fun main() {
    val kingsAndPawns = mapOf("e1" to 'K', "e8" to 'k', "e2" to 'P', "e7" to 'p')
    val tracker = LiveBoardTracker(requiredStableFrames = 3)
    verify("seed trusted starting board", tracker.seed(kingsAndPawns, FenMetadata('w')) != null)

    val e4 = kingsAndPawns - "e2" + ("e4" to 'P')
    verify("first frame waits for stability", tracker.accept(e4, 0.99f) is LiveBoardTracker.Update.WaitingForStability)
    verify("second frame still waits", tracker.accept(e4, 0.99f) is LiveBoardTracker.Update.WaitingForStability)
    val acceptedE4 = tracker.accept(e4, 0.99f)
    verify("third matching frame accepts e2e4", acceptedE4 is LiveBoardTracker.Update.MoveAccepted && acceptedE4.move.uci == "e2e4")
    verify("FEN metadata advances after e4", tracker.currentPosition()?.toFen() == "4k3/4p3/8/8/4P3/8/8/4K3 b - e3 0 1")
    verify("same position does not emit duplicate move", tracker.accept(e4, 0.99f) is LiveBoardTracker.Update.Unchanged)

    tracker.reset()
    verify("reset clears current game state", tracker.currentPosition() == null)
    tracker.accept(e4, 0.99f); tracker.accept(e4, 0.99f)
    verify("stable board requires trusted seed after reset", tracker.accept(e4, 0.99f) is LiveBoardTracker.Update.NeedsTrustedSeed)

    val badConfidenceTracker = LiveBoardTracker()
    verify("reject NaN confidence", badConfidenceTracker.accept(kingsAndPawns, Float.NaN) == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.INVALID_CONFIDENCE))
    verify("reject low confidence", badConfidenceTracker.accept(kingsAndPawns, 0.79f) == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.INVALID_CONFIDENCE))
    verify("reject invalid square snapshot", badConfidenceTracker.accept(mapOf("e1" to 'K', "e8" to 'k', "i9" to 'Q'), 0.99f) == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.INVALID_BOARD))

    val captureBefore = mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P', "d5" to 'p')
    val captureAfter = captureBefore - "e4" - "d5" + ("d5" to 'P')
    val captureResult = awaitMove(LiveBoardTracker(), captureBefore, captureAfter, FenMetadata('w'))
    verify("accept capture with exact resulting board", captureResult is LiveBoardTracker.Update.MoveAccepted && captureResult.move.capturedOn == "d5")

    val castleBefore = mapOf("e1" to 'K', "h1" to 'R', "e8" to 'k')
    val castleAfter = castleBefore - "e1" - "h1" + ("g1" to 'K') + ("f1" to 'R')
    val castleResult = awaitMove(LiveBoardTracker(), castleBefore, castleAfter, FenMetadata('w', "K"))
    verify("accept kingside castling and clear rights", castleResult is LiveBoardTracker.Update.MoveAccepted && castleResult.move.isCastling && castleResult.position.metadata.castling == "-")

    val promotionBefore = mapOf("e1" to 'K', "e8" to 'k', "a7" to 'P')
    val promotionAfter = promotionBefore - "a7" + ("a8" to 'Q')
    val promotionResult = awaitMove(LiveBoardTracker(), promotionBefore, promotionAfter, FenMetadata('w'))
    verify("accept promotion and retain promoted piece", promotionResult is LiveBoardTracker.Update.MoveAccepted && promotionResult.move.promotion == 'q' && promotionResult.position.placement.startsWith("Q3k3/"))

    val epBefore = mapOf("e1" to 'K', "e8" to 'k', "e5" to 'P', "d5" to 'p')
    val epAfter = epBefore - "e5" - "d5" + ("d6" to 'P')
    val epResult = awaitMove(LiveBoardTracker(), epBefore, epAfter, FenMetadata('w', "-", "d6"))
    verify("accept en-passant and remove captured pawn", epResult is LiveBoardTracker.Update.MoveAccepted && epResult.move.capturedOn == "d5" && epResult.position.placement == "4k3/8/3P4/8/8/8/8/4K3")

    val wrongSideTracker = LiveBoardTracker()
    wrongSideTracker.seed(kingsAndPawns, FenMetadata('b'))
    wrongSideTracker.accept(e4, 0.99f); wrongSideTracker.accept(e4, 0.99f)
    val wrongSide = wrongSideTracker.accept(e4, 0.99f)
    verify("reject move by side not on move", wrongSide == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.ILLEGAL_MOVE))
    verify("rejected move does not mutate saved position", wrongSideTracker.currentPosition()?.metadata?.sideToMove == 'b')

    val multiBefore = mapOf("e1" to 'K', "e8" to 'k', "a2" to 'P', "h2" to 'P')
    val multiAfter = multiBefore - "a2" - "h2" + ("a3" to 'P') + ("h3" to 'P')
    val multiTracker = LiveBoardTracker()
    multiTracker.seed(multiBefore, FenMetadata('w'))
    multiTracker.accept(multiAfter, 0.99f); multiTracker.accept(multiAfter, 0.99f)
    verify("reject multiple simultaneous piece changes", multiTracker.accept(multiAfter, 0.99f) == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.NO_SINGLE_MOVE))

    val illegalMoveTracker = LiveBoardTracker()
    val illegalSeed = illegalMoveTracker.seed(kingsAndPawns, FenMetadata('w'))
    val impossibleE5 = kingsAndPawns - "e2" + ("e5" to 'P')
    illegalMoveTracker.accept(impossibleE5, 0.99f)
    illegalMoveTracker.accept(impossibleE5, 0.99f)
    val illegalMoveResult = illegalMoveTracker.accept(impossibleE5, 0.99f)
    verify("tracker rejects a visually matched illegal pawn leap", illegalMoveResult == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.ILLEGAL_MOVE))
    verify("illegal visual move does not mutate committed FEN", illegalMoveTracker.currentPosition() == illegalSeed)

    val outcomeTracker = LiveBoardTracker()
    val openingPosition = requireNotNull(FenPosition.parse("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"))
    verify("tracker reports ongoing game after trusted opening seed", outcomeTracker.seed(openingPosition.toPieceMap(), openingPosition.metadata) != null && outcomeTracker.currentOutcome() == GameOutcome.ONGOING)
    val matePosition = requireNotNull(FenPosition.parse("7k/6Q1/6K1/8/8/8/8/8 b - - 0 1"))
    verify("tracker exposes checkmate outcome from trusted FEN", outcomeTracker.seed(matePosition.toPieceMap(), matePosition.metadata) != null && outcomeTracker.currentOutcome() == GameOutcome.WHITE_WINS_BY_CHECKMATE)

    outcomeTracker.accept(matePosition.toPieceMap(), 0.99f)
    outcomeTracker.accept(matePosition.toPieceMap(), 0.99f)
    verify("tracker blocks further move updates after checkmate", outcomeTracker.accept(matePosition.toPieceMap(), 0.99f) == LiveBoardTracker.Update.Rejected(LiveBoardTracker.Rejection.GAME_FINISHED))

    println("23 live board tracker checks passed")
}
