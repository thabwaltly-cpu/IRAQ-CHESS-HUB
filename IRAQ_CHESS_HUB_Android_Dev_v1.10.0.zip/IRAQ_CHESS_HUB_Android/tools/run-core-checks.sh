#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
KOTLIN_FILES=(
  tools/test-stubs/com/iraqchesshub/vision/DetectedPiece.kt
  tools/test-stubs/com/iraqchesshub/vision/BoardObservation.kt
  app/src/main/java/com/iraqchesshub/game/MoveDeltaDetector.kt
  app/src/main/java/com/iraqchesshub/game/FenPosition.kt
  app/src/main/java/com/iraqchesshub/game/ChessMoveLegality.kt
  app/src/main/java/com/iraqchesshub/game/GameAdjudicator.kt
  app/src/main/java/com/iraqchesshub/game/PgnParser.kt
  app/src/main/java/com/iraqchesshub/game/PgnReplay.kt
  app/src/main/java/com/iraqchesshub/game/PositionStabilityGate.kt
  app/src/main/java/com/iraqchesshub/game/LiveBoardTracker.kt
  app/src/main/java/com/iraqchesshub/analysis/ProfessionalAnalysis.kt
  app/src/main/java/com/iraqchesshub/engine/StockfishUciEngine.kt
  app/src/main/java/com/iraqchesshub/analysis/LiveChessAnalysisSession.kt
  app/src/main/java/com/iraqchesshub/analysis/RecognizedBoardAnalysisCoordinator.kt
  app/src/main/java/com/iraqchesshub/analysis/RecognizedBoardCaptureRuntime.kt
  app/src/main/java/com/iraqchesshub/vision/PieceTemplatePackSpec.kt
  app/src/main/java/com/iraqchesshub/vision/BoardCalibration.kt
  tools/test-stubs/com/iraqchesshub/vision/BoardBounds.kt
  tools/FenPositionChecks.kt
  tools/ChessMoveLegalityChecks.kt
  tools/GameAdjudicatorChecks.kt
  tools/PgnParserChecks.kt
  tools/PgnReplayChecks.kt
  tools/MoveDeltaDetectorChecks.kt
  tools/RealStockfishChecks.kt
  tools/LiveBoardTrackerChecks.kt
  tools/LiveChessAnalysisSessionChecks.kt
  tools/RecognizedBoardAnalysisCoordinatorChecks.kt
  tools/RecognizedBoardCaptureRuntimeChecks.kt
  tools/PieceTemplatePackSpecChecks.kt
  tools/BoardCalibrationChecks.kt
)
kotlinc "${KOTLIN_FILES[@]}" -include-runtime -d /tmp/iraq-chess-core-checks.jar
java -cp /tmp/iraq-chess-core-checks.jar FenPositionChecksKt
java -cp /tmp/iraq-chess-core-checks.jar ChessMoveLegalityChecksKt
java -cp /tmp/iraq-chess-core-checks.jar GameAdjudicatorChecksKt
java -cp /tmp/iraq-chess-core-checks.jar PgnParserChecksKt
java -cp /tmp/iraq-chess-core-checks.jar PgnReplayChecksKt
java -cp /tmp/iraq-chess-core-checks.jar LiveBoardTrackerChecksKt
java -cp /tmp/iraq-chess-core-checks.jar LiveChessAnalysisSessionChecksKt
java -cp /tmp/iraq-chess-core-checks.jar RecognizedBoardAnalysisCoordinatorChecksKt
java -cp /tmp/iraq-chess-core-checks.jar RecognizedBoardCaptureRuntimeChecksKt
java -cp /tmp/iraq-chess-core-checks.jar PieceTemplatePackSpecChecksKt
java -cp /tmp/iraq-chess-core-checks.jar BoardCalibrationChecksKt
java -cp /tmp/iraq-chess-core-checks.jar MoveDeltaDetectorChecksKt tools/fake-stockfish.sh tools/fake-stockfish-hang.sh
if [[ -n "${REAL_STOCKFISH_BINARY:-}" ]]; then
  java -cp /tmp/iraq-chess-core-checks.jar RealStockfishChecksKt "$REAL_STOCKFISH_BINARY"
fi
rm -f /tmp/iraq-chess-core-checks.jar
