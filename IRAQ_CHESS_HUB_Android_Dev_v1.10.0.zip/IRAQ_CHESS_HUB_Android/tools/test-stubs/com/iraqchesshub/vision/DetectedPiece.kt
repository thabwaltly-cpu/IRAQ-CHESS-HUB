package com.iraqchesshub.vision

data class DetectedPiece(val square: String, val symbol: Char, val confidence: Float)
