package com.iraqchesshub.vision

data class BoardBounds(val left: Int, val top: Int, val width: Int, val height: Int)
