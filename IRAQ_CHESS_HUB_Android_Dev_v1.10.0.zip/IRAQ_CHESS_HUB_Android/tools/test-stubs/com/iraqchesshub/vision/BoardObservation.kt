package com.iraqchesshub.vision

data class BoardObservation(val pieces: List<DetectedPiece>, val confidence: Float) {
    fun toPieceMap(): Map<String, Char>? {
        if (pieces.size > 32 || pieces.map { it.square }.toSet().size != pieces.size) return null
        if (pieces.any { it.square !in (('a'..'h').flatMap { f -> (1..8).map { r -> "$f$r" } }) || it.symbol !in "pnbrqkPNBRQK" || !it.confidence.isFinite() || it.confidence !in 0.80f..1.0f }) return null
        return pieces.associate { it.square to it.symbol }
    }
    fun toFenPlacement(): String? {
        val map = toPieceMap() ?: return null
        if (map.size !in 2..32 || map.values.count { it == 'K' } != 1 || map.values.count { it == 'k' } != 1) return null
        val board = Array(8) { CharArray(8) { '.' } }
        for ((square, piece) in map) board[7 - (square[1] - '1')][square[0] - 'a'] = piece
        return board.joinToString("/") { row ->
            val out = StringBuilder(); var empty = 0
            for (cell in row) if (cell == '.') empty++ else {
                if (empty > 0) { out.append(empty); empty = 0 }; out.append(cell)
            }
            if (empty > 0) out.append(empty)
            out.toString()
        }
    }
}
