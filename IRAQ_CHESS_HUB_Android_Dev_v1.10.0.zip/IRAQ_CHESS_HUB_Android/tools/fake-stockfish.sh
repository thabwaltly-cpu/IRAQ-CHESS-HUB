#!/bin/sh
while IFS= read -r cmd; do
  case "$cmd" in
    uci) echo 'id name IRAQ_CHESS_HUB_FakeEngine'; echo 'uciok' ;;
    isready) echo 'readyok' ;;
    'go depth '*) echo 'info depth 5 score cp 23 nodes 100 pv e2e4 e7e5'; echo 'bestmove e2e4' ;;
    quit) exit 0 ;;
  esac
done
