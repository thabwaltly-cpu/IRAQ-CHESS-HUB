import com.iraqchesshub.game.PgnParser
import com.iraqchesshub.game.PgnReplay

fun main() {
    var checks = 0
    fun check(ok: Boolean, message: String) { checks++; check(ok) { message } }

    val ruy = PgnParser.parse("""
        [Event "Ruy Lopez"]
        [Result "*"]
        1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 *
    """.trimIndent())!!
    val replay = PgnReplay.replay(ruy)
    check(replay.complete, "common opening SAN line replays")
    check(replay.positions.size == 11, "initial FEN plus ten plies")
    check(replay.positions.last().metadata.sideToMove == 'w', "side to move toggled correctly")
    check(replay.positions.last().metadata.castling == "kq", "white castling rights removed")
    check(replay.positions.last().toPieceMap()["f1"] == 'R', "castling rook relocated")

    val illegal = PgnParser.parse("[Event \"Illegal\"]\n1. e5 *")!!
    val rejected = PgnReplay.replay(illegal)
    check(!rejected.complete && rejected.failedPly == 1, "illegal SAN rejected at exact ply")
    check(rejected.positions.size == 1, "failed move does not mutate history")

    val capture = PgnParser.parse("[Event \"Capture\"]\n1. e4 d5 2. exd5 *")!!
    val captureReplay = PgnReplay.replay(capture)
    check(captureReplay.complete, "pawn capture with SAN disambiguation replays")
    check(captureReplay.positions.last().toPieceMap()["d5"] == 'P', "capturing pawn lands on target")
    check(captureReplay.positions.last().metadata.halfmoveClock == 0, "capture resets halfmove clock")

    val blackCastle = PgnParser.parse("""
        [Event "Black castle"]
        [SetUp "1"]
        [FEN "r3k2r/8/8/8/8/8/8/R3K2R b KQkq - 0 1"]
        [Result "*"]
        1... O-O *
    """.trimIndent())!!
    val castleReplay = PgnReplay.replay(blackCastle)
    check(castleReplay.complete, "black kingside castling replays from FEN")
    check(castleReplay.positions.last().toPieceMap()["f8"] == 'r', "black castling rook relocated")
    check(castleReplay.positions.last().toPieceMap()["g8"] == 'k', "black king castled to g8")

    val badFenSetup = PgnParser.parse("[Event \"Bad setup\"]\n[FEN \"${PgnReplay.START_FEN}\"]\n1. e4 *")!!
    check(!PgnReplay.replay(badFenSetup).complete, "FEN without SetUp=1 rejected")

    println("PgnReplayChecks: $checks checks passed")
}
