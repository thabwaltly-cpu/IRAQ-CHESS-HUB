import com.iraqchesshub.game.PgnParser

fun main() {
    var checks = 0
    fun check(ok: Boolean, message: String) { checks++; check(ok) { message } }

    val basic = PgnParser.parse("""
        [Event "Casual Game"]
        [White "Alice"]
        [Black "Bob"]
        [Result "1-0"]

        1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0
    """.trimIndent())
    check(basic != null, "basic PGN parses")
    check(basic!!.sanMoves == listOf("e4", "e5", "Nf3", "Nc6", "Bb5", "a6"), "main line SAN extracted")
    check(basic.result == "1-0", "result parsed")
    check(basic.white == "Alice" && basic.black == "Bob", "player headers parsed")
    check(basic.event == "Casual Game", "event header parsed")

    val annotated = PgnParser.parse("""
        [Event "Annotated"]
        [Result "*"]
        1. e4 {best by test} e5 $1 2. Nf3 (2. Bc4 Nf6) Nc6 ; comment
        3. Bb5!? a6 *
    """.trimIndent())
    check(annotated != null, "comments and variations accepted")
    check(annotated!!.sanMoves == listOf("e4", "e5", "Nf3", "Nc6", "Bb5!?", "a6"), "comments and side line removed")
    check(annotated.result == "*", "unfinished result retained")

    val fen = PgnParser.parse("""
        [Event "FEN start"]
        [SetUp "1"]
        [FEN "8/8/8/8/8/8/4k3/4K3 w - - 0 1"]
        [Result "1/2-1/2"]
        1. Kf2 Kf7 1/2-1/2
    """.trimIndent())
    check(fen?.initialFen?.startsWith("8/8/8") == true, "FEN header retained")
    check(fen?.result == "1/2-1/2", "draw result parsed")

    check(PgnParser.parse("") == null, "empty input rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 1-0 0-1") == null, "duplicate results rejected")
    check(PgnParser.parse("[Event \"x\"]\n[Result \"1-0\"]\n1. e4 0-1") == null, "header/movetext result mismatch rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 {") == null, "unclosed brace comment rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 (2. Nf3") == null, "unclosed variation rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 )") == null, "orphan variation close rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 } 1-0") == null, "orphan comment close rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. nonsense 1-0") == null, "invalid SAN token rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 e5")?.sanMoves == listOf("e4", "e5"), "missing result defaults to unfinished")
    check(PgnParser.parse("[Event \"x\"]\n1. O-O O-O-O *")?.sanMoves == listOf("O-O", "O-O-O"), "castling SAN parsed")
    check(PgnParser.parse("[Event \"x\"]\n1. e8=Q+ *")?.sanMoves == listOf("e8=Q+"), "promotion SAN parsed")
    check(PgnParser.parse("[Event \"x\"]\n1. Rxa8# *")?.sanMoves == listOf("Rxa8#"), "capture/checkmate SAN parsed")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 $3 *")?.sanMoves == listOf("e4"), "numeric annotation glyph stripped")
    check(PgnParser.parse("[Event \"x\"]\n1. e4! *")?.sanMoves == listOf("e4!"), "annotation suffix retained")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 1-0 trailing") == null, "tokens after result rejected")
    check(PgnParser.parse("[Event \"x\"]\n[Event \"y\"]\n1. e4 *") == null, "duplicate header rejected")
    check(PgnParser.parse("[Event \"x\"]\n[Result \"invalid\"]\n1. e4") == null, "invalid result header rejected")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 {ok} e5")?.sanMoves?.size == 2, "brace comment boundary handled")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 ; comment\n e5 *")?.sanMoves == listOf("e4", "e5"), "semicolon comment handled")
    check(PgnParser.parse("[Event \"A \\\"quoted\\\" title\"]\n1. e4 *")?.event == "A \"quoted\" title", "escaped quote in tag pair decoded")
    check(PgnParser.parse("[Event \"x\"]\n1. e4 (1... c5 (2. Nf3)) e5 *")?.sanMoves == listOf("e4", "e5"), "nested variations stripped")

    println("PgnParserChecks: $checks checks passed")
}
