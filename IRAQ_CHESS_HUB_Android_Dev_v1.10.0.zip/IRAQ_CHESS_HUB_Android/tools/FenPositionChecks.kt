import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.FenMetadataTracker
import com.iraqchesshub.game.MoveDeltaDetector
import com.iraqchesshub.vision.DetectedPiece

private fun check(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

fun main() {
    val start = listOf(
        "a1" to 'R', "b1" to 'N', "c1" to 'B', "d1" to 'Q', "e1" to 'K', "f1" to 'B', "g1" to 'N', "h1" to 'R',
        "a2" to 'P', "b2" to 'P', "c2" to 'P', "d2" to 'P', "e2" to 'P', "f2" to 'P', "g2" to 'P', "h2" to 'P',
        "a7" to 'p', "b7" to 'p', "c7" to 'p', "d7" to 'p', "e7" to 'p', "f7" to 'p', "g7" to 'p', "h7" to 'p',
        "a8" to 'r', "b8" to 'n', "c8" to 'b', "d8" to 'q', "e8" to 'k', "f8" to 'b', "g8" to 'n', "h8" to 'r'
    ).map { DetectedPiece(it.first, it.second, 0.99f) }
    val metadata = FenMetadata('w', "KQkq")
    val fen = FenPosition.fromPieces(start, metadata)
    check("starting placement compressed correctly", fen?.placement == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR")
    check("full FEN metadata retained", fen?.toFen() == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    check("reject duplicate squares", FenPosition.fromPieces(start + start.first(), metadata) == null)
    check("reject missing white king", FenPosition.fromPieces(start.filterNot { it.symbol == 'K' }, metadata) == null)
    check("reject low confidence", FenPosition.fromPieces(start.map { if (it.square == "e1") it.copy(confidence = 0.79f) else it }, metadata) == null)
    check("reject NaN confidence", FenPosition.fromPieces(start.map { if (it.square == "e1") it.copy(confidence = Float.NaN) else it }, metadata) == null)
    check("reject malformed square", FenPosition.fromPieces(start.map { if (it.square == "e1") it.copy(square = "i9") else it }, metadata) == null)
    check("reject castling right without rook", FenPosition.fromPieces(start.filterNot { it.square == "h1" }, metadata) == null)
    check("reject en-passant without pushed pawn", FenPosition.fromPieces(start, FenMetadata('w', "KQkq", "e6")) == null)
    val epBoard = start.filterNot { it.square == "e7" } + DetectedPiece("e5", 'p', 0.99f)
    check("accept en-passant target with correct pawn", FenPosition.fromPieces(epBoard, FenMetadata('w', "KQkq", "e6")) != null)
    check("reject invalid rank width", !FenPosition.isValidPlacement("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBN"))
    check("reject pawn on back rank", !FenPosition.isValidPlacement("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNP"))
    check("reject ninth pawn", !FenPosition.isValidPlacement("4k3/pppppppp/p7/8/8/8/8/4K3"))
    check("reject duplicate king", !FenPosition.isValidPlacement("4k3/8/8/8/8/8/8/4KK2"))
    check("reject adjacent kings", !FenPosition.isValidPlacement("8/8/8/8/8/4k3/4K3/8"))
    check("reject diagonally adjacent kings", !FenPosition.isValidPlacement("8/8/8/8/8/8/4k3/3K4"))
    val parsedStart = FenPosition.parse("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    check("parse complete six-field FEN", parsedStart?.toFen() == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    check("FEN parser expands all 32 starting pieces", parsedStart?.toPieceMap()?.size == 32)
    check("FEN parse and piece map round-trip", parsedStart?.let { FenPosition.fromPieceMap(it.toPieceMap(), it.metadata) == it } == true)
    check("reject incomplete five-field FEN", FenPosition.parse("4k3/8/8/8/8/8/8/4K3 w - - 0") == null)
    check("reject invalid side-to-move field", FenPosition.parse("4k3/8/8/8/8/8/8/4K3 x - - 0 1") == null)
    check("reject negative FEN counters", FenPosition.parse("4k3/8/8/8/8/8/8/4K3 w - - -1 1") == null)

    val whiteStart = mapOf("e1" to 'K', "a1" to 'R', "h1" to 'R', "e2" to 'P', "g1" to 'N', "e8" to 'k', "a8" to 'r', "h8" to 'r', "e7" to 'p')
    val e4 = MoveDeltaDetector.MoveDelta("e2e4", "e2", "e4")
    val afterE4 = FenMetadataTracker.afterMove(metadata, whiteStart, e4)
    check("white double pawn move flips turn and sets e3", afterE4 == FenMetadata('b', "KQkq", "e3", 0, 1))
    val blackAfterE4 = whiteStart - "e2" + ("e4" to 'P')
    val e5 = MoveDeltaDetector.MoveDelta("e7e5", "e7", "e5")
    val afterE5 = afterE4?.let { FenMetadataTracker.afterMove(it, blackAfterE4, e5) }
    check("black double pawn move sets e6 and increments fullmove", afterE5 == FenMetadata('w', "KQkq", "e6", 0, 2))
    val knightMove = MoveDeltaDetector.MoveDelta("g1f3", "g1", "f3")
    val afterKnight = FenMetadataTracker.afterMove(metadata, whiteStart, knightMove)
    check("quiet piece move increments halfmove clock", afterKnight == FenMetadata('b', "KQkq", "-", 1, 1))
    val kingMove = MoveDeltaDetector.MoveDelta("e1f1", "e1", "f1")
    check("king move clears both white castling rights", FenMetadataTracker.afterMove(metadata, whiteStart, kingMove)?.castling == "kq")
    val rookCapture = MoveDeltaDetector.MoveDelta("a8a1", "a8", "a1", capturedOn = "a1")
    val blackMeta = FenMetadata('b', "KQkq")
    check("captured corner rook clears its castling right", FenMetadataTracker.afterMove(blackMeta, whiteStart, rookCapture)?.castling == "Kk")
    println("27 FEN and metadata checks passed")
}
