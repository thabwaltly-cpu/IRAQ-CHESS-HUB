import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.GameAdjudicator
import com.iraqchesshub.game.GameOutcome

private fun position(fen: String) = requireNotNull(FenPosition.parse(fen)) { "Invalid test FEN: $fen" }
private var checks = 0
private fun expect(expected: GameOutcome, actual: GameOutcome, label: String) {
    check(expected == actual) { "$label: expected $expected, got $actual" }
    checks++
}
private fun expectTrue(value: Boolean, label: String) {
    check(value) { label }
    checks++
}

fun main() {
    val mate = position("7k/6Q1/6K1/8/8/8/8/8 b - - 0 1")
    expect(GameOutcome.WHITE_WINS_BY_CHECKMATE, GameAdjudicator.evaluate(mate), "black checkmated")

    val stalemate = position("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
    expect(GameOutcome.STALEMATE, GameAdjudicator.evaluate(stalemate), "stalemate")

    val bareKings = position("7k/8/8/8/8/8/8/K7 w - - 0 1")
    expectTrue(GameAdjudicator.isInsufficientMaterial(bareKings), "bare kings insufficient")
    expect(GameOutcome.INSUFFICIENT_MATERIAL, GameAdjudicator.evaluate(bareKings), "bare kings outcome")

    val kingBishop = position("7k/8/8/8/8/8/6B1/6K1 w - - 0 1")
    expectTrue(GameAdjudicator.isInsufficientMaterial(kingBishop), "king and bishop vs king")
    val kingKnight = position("7k/8/8/8/8/8/6N1/6K1 w - - 0 1")
    expectTrue(GameAdjudicator.isInsufficientMaterial(kingKnight), "king and knight vs king")

    val sameColorBishops = position("7k/8/5b2/8/8/8/8/K1B5 w - - 0 1")
    expectTrue(GameAdjudicator.isInsufficientMaterial(sameColorBishops), "same-color bishops only")
    val oppositeColorBishops = position("7k/8/8/8/8/5b2/8/K1B5 w - - 0 1")
    expectTrue(!GameAdjudicator.isInsufficientMaterial(oppositeColorBishops), "opposite-color bishops not auto-drawn")

    val seventyFive = position("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 150 76")
    expect(GameOutcome.SEVENTY_FIVE_MOVE_RULE, GameAdjudicator.evaluate(seventyFive), "75-move rule")
    val fifty = position("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 100 51")
    expect(GameOutcome.FIFTY_MOVE_CLAIM_AVAILABLE, GameAdjudicator.evaluate(fifty), "50-move claim")

    val repeat = position("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    expect(GameOutcome.THREEFOLD_REPETITION_CLAIM_AVAILABLE,
        GameAdjudicator.evaluate(repeat, listOf(repeat, repeat, repeat)), "threefold claim")
    expect(GameOutcome.FIVEFOLD_REPETITION,
        GameAdjudicator.evaluate(repeat, List(5) { repeat }), "fivefold automatic draw")

    val normal = position("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    expect(GameOutcome.ONGOING, GameAdjudicator.evaluate(normal), "normal opening")

    println("GameAdjudicator: $checks checks passed")
}
