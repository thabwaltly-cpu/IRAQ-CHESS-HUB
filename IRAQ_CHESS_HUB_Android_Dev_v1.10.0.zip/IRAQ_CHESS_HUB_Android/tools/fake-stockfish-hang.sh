#!/bin/sh
# Test-only UCI process that completes the handshake but never answers a search.
while IFS= read -r cmd; do
  case "$cmd" in
    uci) echo 'id name IRAQ_CHESS_HUB_FakeHang'; echo 'uciok' ;;
    isready) echo 'readyok' ;;
    quit) exit 0 ;;
  esac
done
