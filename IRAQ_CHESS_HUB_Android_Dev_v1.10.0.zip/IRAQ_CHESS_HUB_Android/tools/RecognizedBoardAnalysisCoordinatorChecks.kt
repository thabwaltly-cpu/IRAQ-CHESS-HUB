import com.iraqchesshub.analysis.*
import com.iraqchesshub.engine.EngineResult
import com.iraqchesshub.game.*
import com.iraqchesshub.vision.*

private fun verify(name: String, ok: Boolean) { check(ok) { "FAILED: $name" }; println("PASS: $name") }
private fun observation(board: Map<String, Char>, confidence: Float = 0.99f) = BoardObservation(
    board.map { (square, symbol) -> DetectedPiece(square, symbol, confidence) }, confidence
)

fun main() {
    val before = mapOf("e1" to 'K', "e8" to 'k', "e2" to 'P', "e7" to 'p')
    val after = before - "e2" + ("e4" to 'P')
    var engineCalls = 0
    var engineFen = ""
    val analyzer = PositionAnalyzer { position, depth ->
        engineCalls++; engineFen = position.toFen()
        EngineResult("e7e5", EngineScore(centipawns = 22), depth, listOf("e7e5"))
    }
    val session = LiveChessAnalysisSession(LiveBoardTracker(2), analyzer, 8)
    val coordinator = RecognizedBoardAnalysisCoordinator(session)
    verify("trusted visual seed accepted", coordinator.seed(observation(before), FenMetadata('w')) is RecognizedBoardAnalysisCoordinator.Result.Seeded)
    verify("first changed frame waits for stability", coordinator.process(observation(after)) is RecognizedBoardAnalysisCoordinator.Result.Update)
    val accepted = coordinator.process(observation(after))
    verify("stable recognized move reaches analysis", accepted is RecognizedBoardAnalysisCoordinator.Result.Update && accepted.value is LiveChessAnalysisSession.Update.AnalysisCompleted)
    verify("engine receives FEN derived from vision", engineFen == "4k3/4p3/8/8/4P3/8/8/4K3 b - e3 0 1")
    verify("engine called once for one stable move", engineCalls == 1)
    verify("current position exposed", coordinator.currentPosition()?.metadata?.sideToMove == 'b')
    verify("low-confidence observation rejected", coordinator.process(observation(after, 0.60f)) == RecognizedBoardAnalysisCoordinator.Result.InvalidObservation)
    val unseeded = RecognizedBoardAnalysisCoordinator(LiveChessAnalysisSession(LiveBoardTracker(), analyzer))
    verify("unseeded tracker requests trusted seed", unseeded.process(observation(before)) == RecognizedBoardAnalysisCoordinator.Result.NeedsTrustedSeed)
    val duplicate = BoardObservation(listOf(DetectedPiece("e1", 'K', .99f), DetectedPiece("e1", 'k', .99f)), .99f)
    verify("duplicate square rejected", coordinator.process(duplicate) == RecognizedBoardAnalysisCoordinator.Result.InvalidObservation)
    println("9 coordinator checks passed")
}
