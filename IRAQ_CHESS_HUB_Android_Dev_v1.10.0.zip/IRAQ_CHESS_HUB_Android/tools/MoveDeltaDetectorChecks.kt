import com.iraqchesshub.game.MoveDeltaDetector
import com.iraqchesshub.analysis.EngineScore
import com.iraqchesshub.analysis.UciScoreParser
import com.iraqchesshub.engine.StockfishUciEngine
import java.io.File

private fun verify(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

fun main(args: Array<String>) {
    val e2e4Before = mapOf("e1" to 'K', "e8" to 'k', "e2" to 'P')
    val e2e4After = mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P')
    verify("quiet pawn move e2e4", MoveDeltaDetector.detect(e2e4Before, e2e4After)?.uci == "e2e4")

    val captureBefore = mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P', "d5" to 'p')
    val captureAfter = mapOf("e1" to 'K', "e8" to 'k', "d5" to 'P')
    verify("capture e4d5", MoveDeltaDetector.detect(captureBefore, captureAfter)?.let { it.uci == "e4d5" && it.capturedOn == "d5" } == true)

    val castleBefore = mapOf("e1" to 'K', "h1" to 'R', "e8" to 'k')
    val castleAfter = mapOf("g1" to 'K', "f1" to 'R', "e8" to 'k')
    verify("white kingside castling", MoveDeltaDetector.detect(castleBefore, castleAfter)?.let { it.uci == "e1g1" && it.isCastling } == true)

    val promotionBefore = mapOf("e1" to 'K', "e8" to 'k', "a7" to 'P')
    val promotionAfter = mapOf("e1" to 'K', "e8" to 'k', "a8" to 'Q')
    verify("promotion a7a8q", MoveDeltaDetector.detect(promotionBefore, promotionAfter)?.uci == "a7a8q")

    val epBefore = mapOf("e1" to 'K', "e8" to 'k', "e5" to 'P', "d5" to 'p')
    val epAfter = mapOf("e1" to 'K', "e8" to 'k', "d6" to 'P')
    verify("en passant e5d6", MoveDeltaDetector.detect(epBefore, epAfter)?.let { it.uci == "e5d6" && it.capturedOn == "d5" } == true)

    val noisyAfter = mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P', "a3" to 'N')
    verify("reject ambiguous multi-square delta", MoveDeltaDetector.detect(e2e4Before, noisyAfter) == null)
    verify("reject malformed square", MoveDeltaDetector.detect(mapOf("z9" to 'P'), mapOf("z8" to 'P')) == null)
    verify("reject overwrite of own piece", MoveDeltaDetector.detect(
        mapOf("e1" to 'K', "e8" to 'k', "e4" to 'P', "d5" to 'N'),
        mapOf("e1" to 'K', "e8" to 'k', "d5" to 'P')
    ) == null)

    verify("parse centipawn score", UciScoreParser.parse("info depth 15 score cp 34 nodes 1200") == EngineScore(centipawns = 34))
    verify("parse mate score", UciScoreParser.parse("info depth 20 score mate -3 pv e2e4") == EngineScore(mateIn = -3))
    verify("ignore UCI info without score", UciScoreParser.parse("info depth 2 nodes 10") == null)

    if (args.isNotEmpty()) {
        StockfishUciEngine(File(args[0])).use { engine ->
            engine.start()
            val result = engine.analyze("8/8/8/8/8/8/4P3/4K2k w - - 0 1", depth = 5)
            verify("UCI process handshake and bestmove", result.bestMoveUci == "e2e4")
            verify("UCI engine identity is captured", engine.engineName == "IRAQ_CHESS_HUB_FakeEngine")
            engine.configure(threads = 2, hashMb = 64)
            verify("UCI mobile resource settings handshake", engine.isRunning())
            verify("UCI process depth and PV", result.depth == 5 && result.principalVariationUci == listOf("e2e4", "e7e5"))
            verify("UCI process score", result.score == EngineScore(centipawns = 23))
            verify("UCI engine reports running after successful search", engine.isRunning())
            val invalidFenRejected = runCatching { engine.analyze("not-a-fen", depth = 5) }.isFailure
            verify("UCI rejects malformed FEN before sending it to engine", invalidFenRejected && engine.isRunning())
        }
    }

    if (args.size > 1) {
        val engine = StockfishUciEngine(File(args[1]))
        engine.start()
        val timedOut = runCatching {
            engine.analyze("8/8/8/8/8/8/4P3/4K2k w - - 0 1", depth = 5, timeoutSeconds = 1)
        }.isFailure
        verify("UCI search timeout is surfaced", timedOut)
        verify("timed-out UCI process is discarded to prevent stale bestmove reuse", !engine.isRunning())
        verify("timed-out UCI engine cannot accept another search", runCatching {
            engine.analyze("8/8/8/8/8/8/4P3/4K2k w - - 0 1", depth = 5)
        }.isFailure)
        engine.close()
    }
}
