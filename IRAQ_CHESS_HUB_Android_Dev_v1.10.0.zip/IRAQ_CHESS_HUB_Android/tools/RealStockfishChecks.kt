import com.iraqchesshub.engine.StockfishUciEngine
import java.io.File

private fun checkResult(name: String, condition: Boolean) {
    check(condition) { "FAILED: $name" }
    println("PASS: $name")
}

fun main(args: Array<String>) {
    require(args.size == 1) { "Usage: RealStockfishChecksKt <stockfish-executable>" }
    val binary = File(args[0])
    checkResult("real Stockfish binary exists", binary.isFile && binary.canExecute())
    StockfishUciEngine(binary).use { engine ->
        engine.start()
        checkResult("UCI identifies the real Stockfish engine", engine.engineName?.contains("Stockfish", ignoreCase = true) == true)
        engine.configure(threads = 2, hashMb = 128)
        checkResult("real engine accepts mobile thread and hash settings", engine.isRunning())
        val startFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        val result = engine.analyze(startFen, depth = 8, timeoutSeconds = 45)
        checkResult("real engine returns a syntactically valid best move", Regex("^[a-h][1-8][a-h][1-8][qrbn]?$", RegexOption.IGNORE_CASE).matches(result.bestMoveUci))
        checkResult("real engine reports a completed search depth", result.depth >= 8)
        checkResult("real engine reports a score and principal variation", result.score != null && result.principalVariationUci.firstOrNull() == result.bestMoveUci)
    }
}
