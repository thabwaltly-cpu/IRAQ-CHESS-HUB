# Stockfish integration — v1.10.0

## Engine source and version

The Android engine packaged by CI is compiled from the official Stockfish 19 stable source tag `sf_19` in `official-stockfish/Stockfish`. CI checks out that tag, records the resolved commit SHA, builds the default NNUE network, and cross-compiles `ARCH=armv8 COMP=ndk COMPCXX=aarch64-linux-android26-clang++` with Android NDK r27c. The exact commit and resulting executable SHA-256 are written into the APK at `assets/licenses/STOCKFISH_BUILD_INFO.txt`.

Source: https://github.com/official-stockfish/Stockfish/tree/sf_19

## Android packaging

At first use the app requires a Stockfish UCI identity handshake, then configures two search threads and a 128 MB hash. The ARM64 PIE executable is packaged as `lib/arm64-v8a/libstockfish.so`. Legacy JNI packaging is enabled so Android extracts it into the app's `nativeLibraryDir`. `ScreenCaptureService` starts this executable through the existing UCI process adapter. The engine is explicitly cross-compiled against Android API 26, matching the app's `minSdk`.

This build currently packages ARM64 only. A device must expose `arm64-v8a` in `Build.SUPPORTED_ABIS`. Other ABIs can still install the application, but engine analysis will be unavailable.

## Validation

CI installs a pinned Kotlin compiler, runs the existing pure Kotlin regression suite, compiles a host-native Stockfish 19 build and exercises the actual UCI adapter against it (binary presence, engine identity, mobile options, best move, score, depth, and principal variation), checks the Android binary ELF machine is AArch64, builds the APK, and verifies that the APK contains the engine. The host smoke test does not replace a real Android-device launch test.

## GPL-3.0 compliance

Stockfish is GPL-3.0. The APK includes the upstream `COPYING` license text and a build-info pointer. CI also publishes a separate `stockfish-19-corresponding-source.tar.gz` artifact containing the checked-out source tree plus the downloaded NNUE network material used for this build. When redistributing the APK, distribute that corresponding-source artifact and license with it. Review the exact upstream license and notices before wider distribution.

## Build command used by CI

```bash
make -C .stockfish/src -j2 net
make -C .stockfish/src -j2 build ARCH=armv8 COMP=ndk COMPCXX=aarch64-linux-android26-clang++
make -C .stockfish/src strip ARCH=armv8 COMP=ndk COMPCXX=aarch64-linux-android26-clang++
```

The Android engine binary is created during GitHub Actions; it is intentionally not fabricated or represented as locally built in the source ZIP.
