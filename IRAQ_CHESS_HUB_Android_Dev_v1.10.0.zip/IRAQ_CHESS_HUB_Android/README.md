# IRAQ CHESS HUB – Android development project (v1.10.0)

Android/Kotlin starter for opt-in screen capture, a transparent arrow overlay, calibrated board processing, professional chess analysis and post-game/training review.

## Added in v0.5.0
- Added a calibrated 8x8 board locator using a normalized board rectangle.
- Added a theme-specific PNG template classifier for empty squares and all 12 chess piece types, with confidence and ambiguity rejection.
- Added orientation-aware square mapping for white-at-bottom and black-at-bottom boards.
- Added a complete FEN model that validates piece placement, exactly one king per side, side to move, castling rights, en-passant target and move counters. It deliberately does not guess metadata that cannot be read from a screenshot.
- Added a stability gate that waits for repeated identical board placements before accepting a frame, reducing false reads during piece animations.
- Added a documented asset-pack format and factory for creating a calibrated recognition pipeline.

## Added in v0.4.0
- UCI move-to-overlay mapping for normalized board coordinates.
- Board calibration data model.

## Added in v0.3.0
- UCI centipawn/mate score parsing and move-review estimates.

## Existing foundations
- Arabic black/red Jetpack Compose app shell.
- User-approved MediaProjection foreground capture service. Frames are processed in memory and not saved.
- Transparent overlay service with demo arrow and UCI move arrow support.
- Stockfish UCI process adapter (requires a compatible Android engine executable).

## Stockfish 19 Android integration (v1.10.0)
- GitHub Actions checks out the official stable Stockfish 19 source tag `sf_19` and compiles a real Android ARM64 engine using NDK r27c and Android API 26 (`ARCH=armv8 COMP=ndk COMPCXX=aarch64-linux-android26-clang++`).
- The generated executable is packaged as `lib/arm64-v8a/libstockfish.so` and launched by the existing UCI adapter from Android's extracted `nativeLibraryDir`.
- CI separately builds Stockfish for the Linux host and runs a real UCI smoke test against the production adapter. It also checks the Android executable is ELF AArch64 and verifies it is present in the APK.
- The APK includes the GPL-3.0 license and an engine build record. CI publishes the exact corresponding-source bundle (including the NNUE network used) separately; redistribute it with the APK.
- Engine packaging is ARM64-only. The app minimum SDK is API 26; the NDK cross-compile explicitly targets Android API 26 to match it.
- The binary is created during CI; the source ZIP itself does not claim to contain a prebuilt executable.

## Important limitations – read before testing
- The v0.5.0 classifier is a baseline template matcher, **not a universal AI vision model**. It requires 26 square-crop PNG templates for each exact app/theme/piece set. Instructions are in `app/src/main/assets/piece_templates/README/TEMPLATE_GUIDE.md`.
- Chess.com and Lichess can use different themes, piece sets, board sizes, animations and coordinates. Separate template packs/calibrations may be needed. Compatibility with every app is not guaranteed.
- A screenshot cannot reliably reveal side-to-move, castling rights, en-passant target or move counters. Supply those from a known game state or a move history; do not infer them from piece placement alone.
- The capture service now loads the saved calibration/theme pipeline, checks a user-provided six-field FEN against three stable screenshots, and routes later stable board changes through the recognition coordinator. This remains dependent on an exact 26-image template pack.
- The Stockfish 19 ARM64 binary is produced and bundled by the updated GitHub Actions workflow. A source-only local build without the CI-generated `jniLibs/arm64-v8a/libstockfish.so` will show the engine as unavailable.
- No APK has been built in this ChatGPT execution environment or tested on HONOR MagicOS 9, Chess.com or Lichess. The GitHub Actions workflow must run successfully before an APK artifact exists.

## Build
Open this folder in Android Studio with Android Gradle Plugin 8.7.3 support, sync Gradle, then build the `app` module. Compile/target SDK 35 and Java 17 are configured. The current execution environment used for this handoff did not have Gradle or Android SDK installed, so APK compilation was not verified.

## Recognition setup
1. Crop one complete square for each of the 26 template filenames documented in `TEMPLATE_GUIDE.md`.
2. Keep templates specific to one app/theme/piece set.
3. Either store them under `app/src/main/assets/piece_templates/<theme>/` or package the 26 files into a ZIP at the root/one common folder and import it from the app's calibration panel.
4. Keep each ZIP within the importer's image and size constraints documented in `TEMPLATE_GUIDE.md`.
5. Create `BoardCalibration(left, top, size, whiteAtBottom)` from normalized display coordinates.
6. Supply a complete, trusted six-field FEN matching the visible board before capture starts.
7. Only accept stable, high-confidence observations; the service sends verified visual deltas to the analyzer only in training/review mode.

## Scope and fair play
Designed for personal training, analysis of one's own games, spectating and post-game review. Do not use engine recommendations to gain an unfair advantage in rated/competitive games. Respect each chess app's rules and screen-capture restrictions.

## Licensing
Stockfish is GPL-3.0. If distributing the app with Stockfish, include the applicable license and comply with corresponding-source requirements for the exact engine build shipped.


## v0.6.0 — visual move delta + UCI hardening

This iteration adds a conservative visual move-delta detector that compares two recognized piece maps and emits UCI moves for: ordinary moves, captures, castling, promotions, and en passant. Ambiguous or multi-square changes are rejected rather than guessed. `BoardObservation.toPieceMap()` provides a confidence-checked bridge from vision observations to the detector.

The Stockfish UCI adapter now reads process output on a dedicated thread and uses queue-based deadlines for startup and analysis, so a blocked `readLine()` cannot silently defeat the configured timeout. The UCI adapter remains dependent on an Android-compatible Stockfish executable being supplied separately.

### Core checks

Run the pure Kotlin checks on a machine with Kotlin/JVM installed:

```bash
kotlinc \
  app/src/main/java/com/iraqchesshub/game/MoveDeltaDetector.kt \
  app/src/main/java/com/iraqchesshub/analysis/ProfessionalAnalysis.kt \
  app/src/main/java/com/iraqchesshub/engine/StockfishUciEngine.kt \
  tools/MoveDeltaDetectorChecks.kt \
  -include-runtime -d tools/core-checks.jar
java -jar tools/core-checks.jar tools/fake-stockfish.sh
```

The fake executable verifies UCI protocol handling only; it is not Stockfish and does not validate chess strength or Android native execution.

### Still not complete / not verified

- The board classifier still needs real labeled 26-image template packs per board theme and piece set.
- Capture frames are now routed through the calibrated pipeline and trusted-seed runtime into the move tracker/coordinator; a real template pack is still required to produce observations.
- No real Stockfish Android/ARM64 binary is bundled or tested.
- No Android APK build or device test on HONOR MagicOS 9 has been performed.
- Chess.com/Lichess and universal-app compatibility have not been tested.


## v0.7.0 — validated FEN bridge + move-history metadata

- `BoardObservation.toFenPosition(metadata)` now provides the explicit bridge from a stable recognized board to a typed `FenPosition`; side-to-move, castling rights, en-passant target and counters must be supplied by a trusted game state and are never guessed from a screenshot.
- FEN placement validation checks eight complete ranks, legal piece symbols, exactly one king per side, no more than eight pawns per side, no pawns on the back rank, and a maximum of 32 pieces.
- Per-piece confidence must be finite and within the accepted range; NaN confidence can no longer slip through the vision-to-position checks.
- Castling metadata must be canonical and consistent with the king/rook squares. En-passant metadata must match the side to move and the pawn that just advanced two squares.
- `FenMetadataTracker.afterMove(...)` advances side-to-move, castling rights, en-passant target, halfmove clock and fullmove number from a detected move plus the pre-move piece map.
- `StockfishUciEngine` now has a typed `analyze(FenPosition, ...)` overload to reduce accidental submission of incomplete FEN strings.

### v0.7.0 core checks

```bash
kotlinc \
  tools/test-stubs/com/iraqchesshub/vision/DetectedPiece.kt \
  app/src/main/java/com/iraqchesshub/game/MoveDeltaDetector.kt \
  app/src/main/java/com/iraqchesshub/game/FenPosition.kt \
  tools/FenPositionChecks.kt \
  -include-runtime -d tools/fen-position-checks.jar
java -jar tools/fen-position-checks.jar
```

The FEN and metadata suite passes 19 checks. The earlier move-delta/UCI suite passes 14 checks, including fake-process UCI handshake and result parsing. These are JVM core checks, not Android instrumentation or device tests.

### Still not complete / not verified in v0.7.0

- The Android `BoardRecognitionPipeline` bridge and Compose/service integration have not been built with Gradle in this environment.
- A valid initial FEN or game-history source is still required to know side-to-move and historic castling/en-passant state; a screenshot alone cannot supply these facts.
- The tracker updates metadata from recognized deltas but does not independently prove chess move legality. A legal-move validator or trusted PGN/game-state feed is still needed before unattended analysis.
- No real Stockfish Android/ARM64 binary, template pack, APK build, HONOR MagicOS 9 device test, or live Chess.com/Lichess compatibility test is included.


## v0.8.0 — stable live-board tracking + analysis session

- Added `LiveBoardTracker`: requires repeated identical high-confidence piece maps before accepting a position change, seeds from a caller-supplied trusted FEN/PGN state, detects one visual move, advances metadata, and emits a typed FEN once per accepted move.
- The tracker replays each detected move against the previous map and requires an exact match with the newly observed map. It rejects ambiguous deltas, wrong-side moves, invalid confidence, invalid FEN metadata, and blocked castling paths without changing the stored game state.
- Added `FenPosition.fromPieceMap(...)` for creating a validated typed FEN from a board snapshot.
- Added `LiveChessAnalysisSession`: sends only accepted moves to a `PositionAnalyzer`, reports the Stockfish `bestmove`, score/depth/PV result, avoids re-analysis on duplicate frames, and keeps failed engine requests retryable.
- Added pure-JVM checks for stability, capture, castling, promotion, en-passant, trusted seeding, engine call gating, and retry behavior.

### v0.8.0 core checks

The JVM check set can be run together from this project root (Kotlin/JVM required):

```bash
kotlinc \
  tools/test-stubs/com/iraqchesshub/vision/DetectedPiece.kt \
  app/src/main/java/com/iraqchesshub/game/MoveDeltaDetector.kt \
  app/src/main/java/com/iraqchesshub/game/FenPosition.kt \
  app/src/main/java/com/iraqchesshub/game/PositionStabilityGate.kt \
  app/src/main/java/com/iraqchesshub/game/LiveBoardTracker.kt \
  app/src/main/java/com/iraqchesshub/analysis/ProfessionalAnalysis.kt \
  app/src/main/java/com/iraqchesshub/analysis/LiveChessAnalysisSession.kt \
  app/src/main/java/com/iraqchesshub/engine/StockfishUciEngine.kt \
  tools/FenPositionChecks.kt tools/MoveDeltaDetectorChecks.kt \
  tools/LiveBoardTrackerChecks.kt tools/LiveChessAnalysisSessionChecks.kt \
  -include-runtime -d tools/all-core-checks.jar

java -cp tools/all-core-checks.jar FenPositionChecksKt
java -cp tools/all-core-checks.jar LiveBoardTrackerChecksKt
java -cp tools/all-core-checks.jar LiveChessAnalysisSessionChecksKt
java -cp tools/all-core-checks.jar MoveDeltaDetectorChecksKt tools/fake-stockfish.sh
```

At the time of the v0.8.0 release, the then-current core check totals were 19 FEN/metadata, 18 live-board tracking, 18 live analysis-session, and 14 move-delta/UCI checks (69 total). Later releases added further checks. The fake executable tests the UCI protocol only. The `LiveChessAnalysisSession` tests use an injected fake analyzer; they do not test Stockfish strength or native Android execution.

### Still not complete / not verified in v0.8.0

- `ScreenCaptureService` still uses the safe placeholder `BoardRecognitionPipeline()` by default. There is no settings UI yet to load a saved board calibration and exact theme-specific template pack into that service.
- The new tracker/session are tested as JVM core components, but they are not yet connected to `MediaProjection` frames, a real visual classifier, the Android Stockfish process, or `ArrowOverlayService` in one runtime flow.
- No real Stockfish Android/ARM64 binary is bundled. Add a compatible build and meet Stockfish GPL-3.0 distribution obligations before shipping.
- No actual 26-image template packs are included for Chess.com/Lichess themes. Compatibility with all chess apps is not established.
- Android Gradle build, APK creation, HONOR MagicOS 9 device testing, and live Chess.com/Lichess testing remain unverified.
- The move tracker validates board deltas and basic metadata consistency but is not a complete chess rules/legal-move validator. Prefer a trusted PGN/game-state feed or add full legality validation before unattended game tracking.


## v1.0.0 — saved calibration and configured capture pipeline

- Added `BoardCalibrationStore` to persist user-confirmed normalized board bounds, board orientation, and a validated theme identifier using app-private preferences.
- Added a Compose calibration panel with horizontal/vertical offsets, board size, orientation, and theme name. Editing any setting invalidates the saved state until the user saves again.
- `ScreenCaptureService` now loads saved settings and attempts to initialize `BoardRecognitionPipeline.calibrated(...)`; it no longer silently runs the placeholder detector.
- Recognition is deliberately inactive when calibration is missing/invalid or the selected theme does not contain all 26 required PNG templates.
- App version bumped to 1.0.0 (versionCode 10).

At the v1.0.0 release, calibration was manual, the repository had no complete theme pack, and captured observations had not yet been connected to the coordinator. v1.1.0 below adds the runtime bridge, trusted FEN seed, live status, and template ZIP import.

### v1.0.0 verification (historical)

- The v1.0.0 handoff reported 77 pure-JVM checks. The current expanded test runner reports the exact latest suite counts in v1.1.0 below.
- These JVM checks do not compile the Android/Compose layer and do not prove MediaProjection, template recognition, Stockfish Android, or device compatibility.

## v0.9.0 — vision-to-analysis coordinator

- Added `RecognizedBoardAnalysisCoordinator`, a tested adapter between `BoardObservation` and `LiveChessAnalysisSession`.
- Requires a trusted initial `FenMetadata` seed; observations with low aggregate confidence, duplicate squares, malformed squares, invalid symbols, or low per-piece confidence are rejected before entering move tracking.
- Stable visual changes now have a single explicit application-level path into the injected position analyzer. The coordinator exposes the accepted FEN position and pending-analysis retry operation.
- Added JVM coordinator checks for trusted seeding, stability gating, FEN delivery to the analyzer, exactly-once analysis, low-confidence rejection, missing seed and duplicate-square rejection.

This is a core integration adapter only. It is not yet connected to `ScreenCaptureService`, a configured real board classifier, Stockfish Android binary, or the overlay at runtime.


## v1.1.0 — capture-to-analysis runtime bridge

- Added complete six-field FEN parsing and conversion to a square map. The parser rejects missing fields, invalid counters, invalid side-to-move, and metadata that conflicts with the board.
- Added `FenSeedStore` for an app-private, user-supplied FEN seed. The UI allows the standard start position or a pasted current FEN and requires explicit validation/save before capture.
- Added `RecognizedBoardCaptureRuntime`: it compares the observed piece placement against the exact saved FEN placement and requires three consecutive matching frames before seeding. A mismatch resets the stability gate and does not change game state.
- Connected `ScreenCaptureService` frame observations to the runtime, `RecognizedBoardAnalysisCoordinator`, `LiveBoardTracker`, and `LiveChessAnalysisSession`. Accepted moves are sent to the injected analyzer on the capture worker thread.
- Added a lazy Stockfish lookup at the app-private path `filesDir/stockfish/stockfish`. No engine is bundled; missing/startup errors are surfaced while the verified move/FEN remains available for later analysis recovery.
- Added live status/FEN reporting from the foreground service to the Compose screen, plus notification updates.
- Engine best moves are sent to the transparent arrow overlay only when the user explicitly enables training/review mode and has overlay permission. The service rejects capture requests without that mode flag.
- Updated arrow mapping to use independent normalized board width and height, which preserves board-square geometry on portrait and landscape displays.
- Added ZIP import for complete 26-image theme packs into app-private storage. The importer checks safe paths, duplicates, missing/unknown entries, PNG signatures, image dimensions/aspect ratio, and per-file/total size limits. Packs can be replaced without rebuilding the APK.
- Added pure tests for template-pack filenames and ZIP path validation. `tools/run-core-checks.sh` now runs all suites.
- App version bumped to 1.1.0 (versionCode 11).

### v1.1.0 verification

- **106 pure-JVM checks passed**: 25 FEN/metadata, 18 live-board tracking, 19 live-analysis session, 9 recognition coordinator, 9 capture-runtime, 12 template-pack rules, and 14 move-delta/UCI fake-process checks.
- Run with `./tools/run-core-checks.sh` from the project root. The fake UCI executable tests protocol behavior only; it is not Stockfish.
- Android/Compose compilation and APK packaging were not run because Gradle and Android SDK are unavailable in this execution environment.

### Remaining blockers

- No real 26-image template pack is included. Without a matching pack, `BoardRecognitionPipeline` will not initialize a classifier and no real screenshot recognition occurs.
- No real Android ARM64 Stockfish binary is included. The service looks for an executable at the app-private `filesDir/stockfish/stockfish` path.
- The tracker verifies visual deltas and metadata consistency, not complete chess legality. The seed must correspond exactly to the visible starting board.
- No end-to-end device test, HONOR MagicOS 9 test, Chess.com/Lichess test, or APK build has been performed.


## v1.2.0 — startup safety and FEN king validation

- Added a basic FEN legality guard rejecting adjacent kings (including diagonal adjacency). This is not a full legal-position validator.
- Capture startup now stops cleanly when calibration or the 26-image theme pack is unavailable; it no longer leaves a foreground capture session running with no recognition pipeline.
- The UI disables capture start until the selected theme pack is available.
- Added a GitHub Actions workflow at `.github/workflows/android-apk.yml` to provision JDK 17, Gradle 8.9 and Android SDK 35, build `app-debug.apk`, and publish it as a workflow artifact. Core JVM checks were run locally with `./tools/run-core-checks.sh`.
- App version bumped to 1.2.0 (versionCode 12).

### v1.2.0 verification and build status

- **108 pure-JVM checks passed**: 27 FEN/metadata, 18 live-board tracking, 19 live-analysis session, 9 recognition coordinator, 9 capture-runtime, 12 template-pack rules, and 14 move-delta/UCI fake-process checks.
- The Android app itself has **not** been compiled in this environment: Gradle and Android SDK are not installed here. The GitHub Actions workflow is included to build it in a configured CI runner after the project is pushed to GitHub. The workflow has not yet been executed, so no APK is claimed.


## v1.3.0 — display-aspect calibration fix

- Calibration now treats horizontal/vertical offsets as fractions of display width/height, and board size as a fraction of the shorter display dimension.
- Pixel bounds are computed against each actual captured frame, so portrait and landscape layouts are handled consistently and off-screen boards are rejected.
- Calibration sliders no longer couple board size to the offset values using incompatible units.
- Added 9 calibration geometry checks; total local pure-JVM checks: 117.
- GitHub Actions runs `tools/run-core-checks.sh` before building and uploads `IRAQ-CHESS-HUB-debug-v1.3.0`.
- APK has not yet been built or device-tested.


## v1.4.0 — standard chess move legality gate

- Added `ChessMoveLegality`, which validates piece movement geometry and paths for pawns, knights, bishops, rooks, queens and kings.
- Validates ordinary captures, turn ownership, promotion and underpromotion, en-passant against trusted FEN metadata, and kingside/queenside castling rights and transit squares.
- Simulates each candidate move and rejects moves that leave the moving side's king attacked, including pinned-piece moves and unsafe king moves.
- `LiveBoardTracker` now rejects a visually matched but illegal move with `Rejection.ILLEGAL_MOVE` before committing the new board/FEN or forwarding it to analysis. Rejected observations do not mutate the saved game state.
- Added 32 rules-level test cases. The full current suite reports **151 pure-JVM checks passed**.
- App version bumped to 1.4.0 (versionCode 14). GitHub Actions artifact name updated to `IRAQ-CHESS-HUB-debug-v1.4.0`.

### v1.4.0 scope and limitations

- This is a single-move legality gate against a trusted, user-supplied FEN. It does not prove that every arbitrary imported FEN is historically reachable, and it is not a complete game-state adjudicator for checkmate, stalemate, repetition, fifty-move claims, or draw rules.
- Accuracy still depends on a correct board recognition result and correct FEN history metadata. If visual recognition misses a piece, the tracker rejects ambiguous updates rather than guessing.
- Android/Compose compilation, APK generation, real Stockfish execution, template-pack recognition, HONOR MagicOS 9 operation and live Chess.com/Lichess behavior remain unverified in this environment.


## v1.5.0 — UCI engine reliability and FEN input validation

- `StockfishUciEngine` now validates the complete six-field FEN using the project's parser before sending a position command to the engine.
- Startup handshake failures clean up the child process instead of leaving a partially initialized engine instance.
- A search timeout or protocol failure now terminates and discards the UCI process. UCI has no request identifiers, so keeping a timed-out process could allow a late `bestmove` from an old search to be mistaken for a later result.
- Added an `isRunning()` state query and explicit cleanup of the child process, writer, reader thread and queued output.
- Added a hanging fake UCI process to verify timeout handling, process disposal and rejection of subsequent searches on a failed instance.
- Added tests proving malformed FEN is rejected before it reaches the engine while a healthy process remains usable.
- App version bumped to 1.5.0 (versionCode 15); GitHub Actions artifact name updated to `IRAQ-CHESS-HUB-debug-v1.5.0`.

### v1.5.0 verification and limitations

- **156 pure-JVM checks passed** with `./tools/run-core-checks.sh`, including UCI handshake, search output, FEN validation and timeout recovery behavior using test-only fake processes.
- The fake executables are protocol test fixtures, not Stockfish. No real Stockfish binary is bundled or tested.
- Android/Compose compilation, APK packaging, device installation, screen capture, image recognition and HONOR/Chess.com/Lichess compatibility remain unverified.


## v1.6.0 — game outcome adjudication

- Added `GameAdjudicator` to classify checkmate, stalemate, insufficient material, the automatic 75-move rule, fivefold repetition, and claimable 50-move/threefold-repetition draws.
- Added legal-move enumeration using the existing move legality gate; checkmate/stalemate classification is based on whether the side to move has any legal move and whether its king is attacked.
- Added insufficient-material checks for bare kings, king plus a single bishop/knight versus king, and bishop-only positions where all bishops occupy the same square color.
- `LiveBoardTracker` now retains the accepted FEN history since its trusted seed, exposes `currentOutcome()`, and rejects further move updates after a terminal result. Claimable draw states remain non-terminal.
- Added 13 adjudication checks and tracker integration checks.
- App version bumped to 1.6.0 (versionCode 16); GitHub Actions artifact name updated to `IRAQ-CHESS-HUB-debug-v1.6.0`.

### v1.6.0 verification and limitations

- **172 pure-JVM checks passed** with `./tools/run-core-checks.sh`.
- Repetition evaluation depends on complete, correctly seeded position history. The current repetition key includes the FEN en-passant target conservatively; positions with an uncapturable en-passant target may therefore be distinguished even where strict FIDE repetition identity could treat them as equivalent.
- The adjudicator covers the listed common automatic/claimable outcomes, not every tournament procedure or variant rule.
- Real Stockfish, Android APK build, phone installation, screen-capture behavior, image templates and HONOR/Chess.com/Lichess compatibility remain unverified.

## v1.7.0 — PGN import foundation

- Added a conservative PGN parser for standard tag pairs, SAN main-line tokens, game results, and optional `FEN` setup headers.
- Brace comments, semicolon comments, numeric annotation glyphs and nested side variations are removed from the main line; malformed comments/variations, duplicate headers/results, invalid result tokens and obvious non-SAN tokens are rejected.
- SAN is preserved as text. This parser does **not** replay SAN, validate every SAN token against a board, or convert the PGN into trusted live position history. A proper SAN-to-position replay layer remains necessary before PGN can seed unattended live tracking.
- App version bumped to 1.7.0 (versionCode 17); GitHub Actions artifact name updated to `IRAQ-CHESS-HUB-debug-v1.7.0`.

### v1.7.0 verification and limitations

- Pure-JVM checks include parser headers, SAN extraction, comments, nested variations, castling, promotions, annotations, FEN header retention and malformed input rejection. **203 pure-JVM checks passed** with `./tools/run-core-checks.sh`, including 31 PGN parser checks.
- This remains a source project. Real Stockfish ARM64, a complete template pack, Android APK build, device installation, screen-capture and HONOR/Chess.com/Lichess compatibility remain unverified.


## v1.8.0 — Legal PGN replay and position history

- Added `PgnReplay`: converts a parsed PGN main line into a sequence of validated six-field FEN positions (initial position plus one position per ply).
- SAN replay resolves piece type, destination, capture, file/rank disambiguation, promotion and castling by enumerating candidate moves and passing them through `ChessMoveLegality`. Ambiguous or illegal SAN stops replay at the exact ply without mutating prior history.
- Applies captures, en-passant removal, promotions, castling rook relocation, castling-right updates, en-passant targets and move clocks.
- FEN setup requires `[SetUp "1"]` when a `[FEN "..."]` tag is supplied.
- Added 14 replay checks covering a Ruy Lopez sequence, castling, capture, illegal SAN rejection and setup metadata. Total: 217 pure-JVM checks passed.
- App version bumped to 1.8.0 (versionCode 18); CI artifact name updated.

### v1.8.0 limitations

- PGN replay is a tested core engine but is not yet connected to a PGN import/review screen.
- Check/mate suffixes in SAN are currently treated as annotations; replay validates the move itself but does not yet verify that the suffix accurately describes check or mate.
- **No real Stockfish executable is bundled or connected yet.** The UCI adapter expects an Android-compatible executable at `filesDir/stockfish/stockfish`; fake UCI scripts are test fixtures only.
- No APK build or physical-device test has been completed.


## v1.9.0 — in-app PGN review

- Added a system document picker for PGN import in the Android UI.
- Parses the selected PGN with a 2 MB input limit and replays the main line through the legality-checked PGN replay layer.
- Added move-by-move previous/next/start navigation and displays the validated FEN for the selected ply.
- If replay encounters an illegal or ambiguous SAN token, the UI retains and exposes the last valid position and reports the failing ply rather than presenting later positions.
- App version bumped to 1.9.0 (versionCode 19).

### v1.9.0 verification status

- Core JVM suites should be run with `./tools/run-core-checks.sh`; the UI import flow is Android/Compose code and is not covered by those pure-JVM checks.
- No real Stockfish Android/ARM64 binary is bundled in this release. The UCI adapter remains an integration point only.
- Android APK packaging and HONOR device testing remain unverified in this environment.

The v1.9.0 core verification run completed successfully with **216 pure-JVM checks** across FEN/metadata, move legality, game adjudication, PGN parsing/replay, board tracking, analysis session/coordinator, capture runtime, template-pack validation, calibration, and fake-UCI process behavior. The fake UCI scripts are protocol test doubles, not Stockfish.


## v1.10.0 — real Stockfish build integration

- CI checks out official Stockfish 19 (`sf_19`) and builds a genuine Android ARM64 executable with NDK r27c.
- The executable is packaged under `jniLibs/arm64-v8a` and launched from `nativeLibraryDir`; the previous `filesDir/stockfish/stockfish` placeholder path is removed.
- UCI adapter now captures the engine `id name` response and configures mobile defaults (two threads, 128 MB hash) after checking that the executable identifies itself as Stockfish.
- Added a real-engine smoke-test entry point for CI; it verifies Stockfish identity, best-move syntax, search depth, score and principal variation against a host-native Stockfish build. The workflow installs pinned Kotlin compiler 2.0.21 for reproducible JVM checks.
- CI publishes the corresponding Stockfish source + NNUE network bundle and GPL-3.0 license alongside the APK artifact.
- Local regression result: **219 pure-JVM checks passed**. CI adds six checks against a real host-native Stockfish build; this CI run has not happened yet.
- App version: 1.10.0 / versionCode 20; minSdk 26 (Android 8.0).
