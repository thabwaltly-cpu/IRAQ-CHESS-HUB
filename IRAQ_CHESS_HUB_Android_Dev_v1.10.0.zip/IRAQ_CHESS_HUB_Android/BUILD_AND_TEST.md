# Build IRAQ CHESS HUB v1.10.0 and package real Stockfish

## What the workflow builds

The GitHub Actions workflow `.github/workflows/android-apk.yml` builds the app and a real Stockfish 19 ARM64 executable from the official `sf_19` source tag. It uses Android NDK r27c and targets Android API 26 to match the app's `minSdk = 26`.

The workflow runs the pure Kotlin regression suite, builds a host-native Stockfish copy and checks the actual Kotlin UCI adapter against it, cross-compiles the Android engine, then builds and inspects the APK. On success it publishes two artifacts:

- `IRAQ-CHESS-HUB-debug-v1.10.0` — `app-debug.apk` with the ARM64 engine included.
- `IRAQ-CHESS-HUB-Stockfish-19-GPL-source` — the corresponding Stockfish source and NNUE network bundle, license, and build metadata.

## Run the build

1. Create a GitHub repository for this project. Choose public or private according to your preference and access needs.
2. Upload the *contents* of this project folder to the repository's default branch. Keep `.github/workflows/android-apk.yml` in that exact path.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK + Stockfish**, then choose **Run workflow**. A push to `main` or `master` also starts the workflow.
5. Open the completed workflow run and download both artifacts. Keep the source/license artifact with any redistributed APK.

## Local checks

With Kotlin/JVM installed:

```bash
bash tools/run-core-checks.sh
```

The six real-engine UCI smoke checks are run by CI after it compiles the host-native Stockfish engine. They can also be invoked locally by setting `REAL_STOCKFISH_BINARY` to a built, executable Stockfish binary.

## Current limitations

- This source archive does not contain a prebuilt Stockfish executable or an APK. The workflow creates both during its run.
- The workflow has not yet run in the project's GitHub repository; the CI build is therefore pending and unverified.
- The Android ARM64 engine has not yet been launched on a physical Android device. No HONOR MagicOS 9 test has been performed.
- The app's board classifier still requires a theme-specific 26-image template pack. Chess.com/Lichess compatibility and all-app support are not guaranteed.
- The project is intended for training, spectating and post-game review, not engine assistance during rated games.
