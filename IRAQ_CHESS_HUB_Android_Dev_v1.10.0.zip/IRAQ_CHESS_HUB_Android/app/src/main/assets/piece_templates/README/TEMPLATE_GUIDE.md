# Board piece template packs

The v0.5.0 prototype includes a simple per-theme image-template classifier. It is not a
universal chess-piece AI model. To enable it, create a folder under
`app/src/main/assets/piece_templates/<theme>/` and place these 26 PNG square crops in it:

- `empty_light.png`, `empty_dark.png`
- `P_light.png`, `P_dark.png`, `N_light.png`, `N_dark.png`, `B_light.png`, `B_dark.png`,
  `R_light.png`, `R_dark.png`, `Q_light.png`, `Q_dark.png`, `K_light.png`, `K_dark.png`
- `p_light.png`, `p_dark.png`, `n_light.png`, `n_dark.png`, `b_light.png`, `b_dark.png`,
  `r_light.png`, `r_dark.png`, `q_light.png`, `q_dark.png`, `k_light.png`, `k_dark.png`

Each PNG must be a crop of exactly one board square, including its background, taken from the
same app, board theme, piece set, zoom level and visual state. Use equal square dimensions.
The `light`/`dark` suffix refers to the square background, not the piece color. Do not mix
Chess.com and Lichess templates or different piece sets in one theme folder.

For in-app import, place exactly these 26 PNGs at the ZIP root or inside one common top-level
folder, then use **Import template pack ZIP** in the calibration panel. The importer rejects
unknown/duplicate files, unsafe paths, files larger than 2 MB, total packs larger than 32 MB,
non-PNG data, and images outside 32–512 pixels or more than 15% away from square. It installs
the pack into app-private storage for the selected theme without rebuilding the APK.

Calibration must tightly cover the 8x8 board only (exclude coordinates, clocks, borders and
buttons). A screenshot can be used to prepare templates only when permitted by the app and
its rules. If the board theme changes, select a matching template pack or recalibrate it.

The matcher rejects low-confidence or ambiguous squares instead of guessing. This is expected:
real deployments should replace this baseline with a trained on-device model and validate it
against a diverse labeled dataset before claiming general app compatibility.
