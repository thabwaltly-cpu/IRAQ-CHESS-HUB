package com.iraqchesshub.analysis

import com.iraqchesshub.engine.EngineResult
import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.LiveBoardTracker
import com.iraqchesshub.game.MoveDeltaDetector

/** Small adapter boundary so the live session can be tested without a native Stockfish binary. */
fun interface PositionAnalyzer {
    fun analyze(position: FenPosition, depth: Int): EngineResult
}

/**
 * Training/review pipeline: stable recognized board -> verified move -> typed FEN -> UCI analysis.
 * Call on a worker thread; Stockfish analysis is synchronous and can take several seconds.
 */
class LiveChessAnalysisSession(
    private val tracker: LiveBoardTracker,
    private val analyzer: PositionAnalyzer,
    private val depth: Int = 14
) {
    private data class Pending(val move: MoveDeltaDetector.MoveDelta, val position: FenPosition)
    private var pending: Pending? = null

    init { require(depth in 1..30) }

    sealed class Update {
        data class Tracking(val update: LiveBoardTracker.Update) : Update()
        data class AnalysisCompleted(
            val move: MoveDeltaDetector.MoveDelta,
            val position: FenPosition,
            val result: EngineResult
        ) : Update()
        data class AnalysisFailed(
            val move: MoveDeltaDetector.MoveDelta,
            val position: FenPosition,
            val reason: String
        ) : Update()
        data object NoPendingAnalysis : Update()
    }

    fun seed(board: Map<String, Char>, trustedMetadata: FenMetadata): FenPosition? =
        tracker.seed(board, trustedMetadata)

    @Synchronized
    fun accept(board: Map<String, Char>, confidence: Float): Update {
        when (val tracked = tracker.accept(board, confidence)) {
            is LiveBoardTracker.Update.MoveAccepted -> {
                pending = Pending(tracked.move, tracked.position)
                return analyzePending()
            }
            else -> return Update.Tracking(tracked)
        }
    }

    /** Retry after an engine startup/timeout failure without requiring another visual move. */
    @Synchronized
    fun retryPendingAnalysis(): Update = analyzePending()

    @Synchronized
    fun pendingPosition(): FenPosition? = pending?.position

    @Synchronized
    fun currentPosition(): FenPosition? = tracker.currentPosition()

    private fun analyzePending(): Update {
        val item = pending ?: return Update.NoPendingAnalysis
        return try {
            val result = analyzer.analyze(item.position, depth)
            pending = null
            Update.AnalysisCompleted(item.move, item.position, result)
        } catch (failure: Exception) {
            Update.AnalysisFailed(
                item.move,
                item.position,
                failure.message?.takeIf { it.isNotBlank() } ?: failure.javaClass.simpleName
            )
        }
    }
}
