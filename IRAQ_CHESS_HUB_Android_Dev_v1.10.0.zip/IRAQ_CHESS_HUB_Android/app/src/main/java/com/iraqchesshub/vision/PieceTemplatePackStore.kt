package com.iraqchesshub.vision

import android.content.ContentResolver
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/** Safely imports a 26-PNG theme pack into app-private storage without rebuilding the APK. */
class PieceTemplatePackStore(
    private val rootDirectory: File,
    private val contentResolver: ContentResolver
) {
    constructor(context: android.content.Context) : this(
        File(context.applicationContext.filesDir, "piece_templates"),
        context.applicationContext.contentResolver
    )

    fun hasPack(theme: String): Boolean {
        if (!PieceTemplatePackSpec.isValidTheme(theme)) return false
        val directory = File(rootDirectory, theme)
        return PieceTemplatePackSpec.requiredFiles.all { name ->
            val file = File(directory, name)
            file.isFile && file.length() in 1..MAX_TEMPLATE_BYTES && isValidImage(file)
        }
    }

    fun packDirectory(theme: String): File? =
        File(rootDirectory, theme).takeIf { hasPack(theme) }

    /**
     * ZIP may contain the 26 files at its root or under one common top-level folder.
     * Arbitrary paths, duplicate names, excess files, large entries, and non-square images fail.
     */
    fun installZip(uri: Uri, theme: String): File {
        require(PieceTemplatePackSpec.isValidTheme(theme)) { "Invalid theme name" }
        if (!rootDirectory.exists()) check(rootDirectory.mkdirs()) { "Cannot create template directory" }
        val temporary = File(rootDirectory, ".${theme}.importing")
        val destination = File(rootDirectory, theme)
        val backup = File(rootDirectory, ".${theme}.backup")
        temporary.deleteRecursively()
        backup.deleteRecursively()
        check(temporary.mkdirs()) { "Cannot create temporary template directory" }

        try {
            val found = LinkedHashSet<String>()
            var totalBytes = 0L
            val input = contentResolver.openInputStream(uri) ?: error("Cannot read selected ZIP file")
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory) {
                        val name = PieceTemplatePackSpec.safeEntryFileName(entry.name)
                            ?: error("Unsafe ZIP path: ${entry.name.take(80)}")
                        require(name in PieceTemplatePackSpec.requiredFiles) { "Unexpected file in template ZIP: $name" }
                        require(found.add(name)) { "Duplicate template file: $name" }
                        val target = File(temporary, name)
                        var entryBytes = 0L
                        BufferedOutputStream(FileOutputStream(target)).use { output ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            while (true) {
                                val read = zip.read(buffer)
                                if (read < 0) break
                                entryBytes += read
                                totalBytes += read
                                require(entryBytes <= MAX_TEMPLATE_BYTES) { "Template file too large: $name" }
                                require(totalBytes <= MAX_TOTAL_BYTES) { "Template pack exceeds size limit" }
                                output.write(buffer, 0, read)
                            }
                        }
                        require(isValidImage(target)) { "Invalid PNG template or non-square image: $name" }
                    }
                    zip.closeEntry()
                }
            }
            val missing = PieceTemplatePackSpec.requiredFiles - found
            require(missing.isEmpty()) { "Template pack incomplete: ${missing.size} files missing" }

            if (destination.exists()) check(destination.renameTo(backup)) { "Cannot preserve previous template pack" }
            if (!temporary.renameTo(destination)) {
                if (backup.exists()) backup.renameTo(destination)
                error("Cannot activate imported template pack")
            }
            backup.deleteRecursively()
            return destination
        } catch (failure: Exception) {
            temporary.deleteRecursively()
            if (!destination.exists() && backup.exists()) backup.renameTo(destination)
            throw failure
        }
    }

    private fun isValidImage(file: File): Boolean {
        val pngSignature = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        val signatureMatches = runCatching {
            file.inputStream().use { input -> ByteArray(pngSignature.size).also { bytes ->
                var offset = 0
                while (offset < bytes.size) {
                    val read = input.read(bytes, offset, bytes.size - offset)
                    if (read < 0) return@use false
                    offset += read
                }
            }.contentEquals(pngSignature) }
        }.getOrDefault(false)
        if (!signatureMatches) return false
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        val width = bounds.outWidth
        val height = bounds.outHeight
        if (width !in MIN_DIMENSION..MAX_DIMENSION || height !in MIN_DIMENSION..MAX_DIMENSION) return false
        return kotlin.math.abs(width - height) <= maxOf(width, height) * 0.15f
    }

    companion object {
        private const val MIN_DIMENSION = 32
        private const val MAX_DIMENSION = 512
        private const val MAX_TEMPLATE_BYTES = 2L * 1024L * 1024L
        private const val MAX_TOTAL_BYTES = 32L * 1024L * 1024L
    }
}

