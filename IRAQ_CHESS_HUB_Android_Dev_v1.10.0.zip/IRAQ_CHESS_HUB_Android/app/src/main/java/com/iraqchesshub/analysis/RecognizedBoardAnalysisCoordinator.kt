package com.iraqchesshub.analysis

import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.LiveBoardTracker
import com.iraqchesshub.vision.BoardObservation

/**
 * Connects the vision output to move tracking and analysis.
 * The initial side-to-move and historic FEN metadata must come from a trusted user/game seed;
 * they are never inferred from pixels. Call process() on a worker thread.
 */
class RecognizedBoardAnalysisCoordinator(
    private val session: LiveChessAnalysisSession
) {
    sealed class Result {
        data class Seeded(val position: FenPosition) : Result()
        data class Update(val value: LiveChessAnalysisSession.Update) : Result()
        data object InvalidObservation : Result()
        data object NeedsTrustedSeed : Result()
    }

    fun seed(observation: BoardObservation, metadata: FenMetadata): Result {
        val board = trustedBoard(observation) ?: return Result.InvalidObservation
        val position = session.seed(board, metadata) ?: return Result.InvalidObservation
        return Result.Seeded(position)
    }

    fun process(observation: BoardObservation): Result {
        val board = trustedBoard(observation) ?: return Result.InvalidObservation
        if (sessionPositionMissing()) return Result.NeedsTrustedSeed
        return Result.Update(session.accept(board, observation.confidence))
    }

    fun retryAnalysis(): LiveChessAnalysisSession.Update = session.retryPendingAnalysis()

    fun currentPosition(): FenPosition? = sessionPosition()

    private fun trustedBoard(observation: BoardObservation): Map<String, Char>? {
        if (!observation.confidence.isFinite() || observation.confidence < MINIMUM_CONFIDENCE) return null
        return observation.toPieceMap()
    }

    // Keep the coordinator independent of tracker internals while exposing safe session state.
    private fun sessionPosition(): FenPosition? = session.currentPosition()
    private fun sessionPositionMissing(): Boolean = sessionPosition() == null

    companion object { private const val MINIMUM_CONFIDENCE = 0.80f }
}
