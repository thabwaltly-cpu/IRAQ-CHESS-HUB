package com.iraqchesshub.game

/** A parsed PGN main line. SAN is preserved as written; this parser does not replay moves. */
data class PgnGame(
    val headers: Map<String, String>,
    val sanMoves: List<String>,
    val result: String
) {
    val event: String get() = headers["Event"].orEmpty()
    val white: String get() = headers["White"].orEmpty()
    val black: String get() = headers["Black"].orEmpty()
    val initialFen: String? get() = headers["FEN"]
}

/** Conservative PGN main-line parser: strips comments/variations and rejects malformed structure. */
object PgnParser {
    private val resultTokens = setOf("1-0", "0-1", "1/2-1/2", "*")
    private val sanPattern = Regex("(?:O-O-O|O-O|0-0-0|0-0)|(?:[KQRBN])?(?:[a-h]?[1-8]?x)?[a-h][1-8](?:=[QRBN])?[+#]?[!?]{0,2}|(?:[KQRBN])?[a-h]?[1-8]?x?[a-h][1-8][+#]?[!?]{0,2}")

    fun parse(text: String): PgnGame? {
        if (text.isBlank() || text.length > 2_000_000) return null
        val headers = linkedMapOf<String, String>()
        val movetext = StringBuilder()
        var inHeaders = true
        val lines = text.lineSequence().toList()
        for (line in lines) {
            val trimmed = line.trim()
            if (inHeaders && trimmed.startsWith("[")) {
                val match = Regex("^\\[([A-Za-z0-9_]+)\\s+\"((?:\\\\.|[^\"\\\\])*)\"\\s*]$").matchEntire(trimmed) ?: return null
                val key = match.groupValues[1]
                if (key in headers) return null
                val value = match.groupValues[2].replace(Regex("\\\\([\\\\\"])") , "$1")
                headers[key] = value
            } else {
                if (trimmed.isNotEmpty()) inHeaders = false
                movetext.append(line).append('\n')
            }
        }
        if (headers.isEmpty()) return null
        val declaredResult = headers["Result"]
        if (declaredResult != null && declaredResult !in resultTokens) return null
        val cleaned = stripCommentsAndVariations(movetext.toString()) ?: return null
        val tokens = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
        val moves = mutableListOf<String>()
        var result: String? = null
        for (raw in tokens) {
            var token = raw
            if (token.matches(Regex("\\d+\\.{1,3}"))) continue
            token = token.replace(Regex("^\\d+\\.(?:\\.\\.)?"), "")
            if (token.isEmpty()) continue
            if (token in resultTokens) {
                if (result != null) return null
                result = token
                continue
            }
            if (token.matches(Regex("\\$\\d+"))) continue
            if (result != null) return null
            token = token.replace(Regex("\\$\\d+$"), "")
            if (token.isEmpty() || !sanPattern.matches(token)) return null
            moves += token
        }
        val finalResult = result ?: declaredResult ?: "*"
        if (declaredResult != null && result != null && declaredResult != result) return null
        if (moves.isEmpty() && finalResult == "*") return null
        return PgnGame(headers.toMap(), moves.toList(), finalResult)
    }

    private fun stripCommentsAndVariations(source: String): String? {
        val out = StringBuilder()
        var brace = false
        var variationDepth = 0
        var lineComment = false
        for (ch in source) {
            if (lineComment) {
                if (ch == '\n') { lineComment = false; if (variationDepth == 0 && !brace) out.append(' ') }
                continue
            }
            if (brace) {
                if (ch == '}') brace = false
                continue
            }
            if (variationDepth > 0) {
                when (ch) { '(' -> variationDepth++; ')' -> variationDepth-- }
                continue
            }
            when (ch) {
                '{' -> brace = true
                '}' -> return null
                ';' -> lineComment = true
                '(' -> variationDepth = 1
                ')' -> return null
                else -> out.append(ch)
            }
        }
        if (brace || variationDepth != 0) return null
        return out.toString()
    }
}
