package com.iraqchesshub.capture

import android.content.Context
import android.content.Intent

/** Small app-private status channel shared by the foreground capture service and Compose UI. */
class CaptureRuntimeStatusStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): Status = Status(
        message = prefs.getString(KEY_MESSAGE, "لم يبدأ الالتقاط بعد.") ?: "لم يبدأ الالتقاط بعد.",
        fen = prefs.getString(KEY_FEN, null),
        active = prefs.getBoolean(KEY_ACTIVE, false)
    )

    fun update(message: String, fen: String? = null, active: Boolean = true) {
        prefs.edit()
            .putString(KEY_MESSAGE, message.take(1200))
            .putString(KEY_FEN, fen?.take(180))
            .putBoolean(KEY_ACTIVE, active)
            .apply()
        appContext.sendBroadcast(Intent(ACTION_UPDATED).setPackage(appContext.packageName))
    }

    data class Status(val message: String, val fen: String?, val active: Boolean)

    companion object {
        const val ACTION_UPDATED = "com.iraqchesshub.capture.RUNTIME_STATUS_UPDATED"
        private const val PREFS = "iraq_chess_capture_status"
        private const val KEY_MESSAGE = "message"
        private const val KEY_FEN = "fen"
        private const val KEY_ACTIVE = "active"
    }
}
