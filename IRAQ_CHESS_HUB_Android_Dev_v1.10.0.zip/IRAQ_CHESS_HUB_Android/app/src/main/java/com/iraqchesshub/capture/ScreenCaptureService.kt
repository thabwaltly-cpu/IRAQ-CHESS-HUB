package com.iraqchesshub.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.iraqchesshub.analysis.LiveChessAnalysisSession
import com.iraqchesshub.analysis.PositionAnalyzer
import com.iraqchesshub.analysis.RecognizedBoardAnalysisCoordinator
import com.iraqchesshub.analysis.RecognizedBoardCaptureRuntime
import com.iraqchesshub.engine.StockfishUciEngine
import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.FenSeedStore
import com.iraqchesshub.game.LiveBoardTracker
import com.iraqchesshub.overlay.ArrowOverlayService
import com.iraqchesshub.vision.BoardCalibrationStore
import com.iraqchesshub.vision.BoardObservation
import com.iraqchesshub.vision.BoardRecognitionPipeline
import com.iraqchesshub.vision.PieceTemplatePackStore
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale

/** User-approved screen capture and training/review-only visual analysis service. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var lastFrameAt = 0L
    private var lastNoDetectionStatusAt = 0L
    private var pipeline: BoardRecognitionPipeline? = null
    private var runtime: RecognizedBoardCaptureRuntime? = null
    private var calibration: com.iraqchesshub.vision.BoardCalibration? = null
    private var engine: StockfishUciEngine? = null
    private var trustedSeed: FenPosition? = null
    private var trainingReviewMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForegroundCompat(buildNotification("تهيئة الالتقاط بموافقتك"))

        trainingReviewMode = intent?.getBooleanExtra(EXTRA_TRAINING_REVIEW_MODE, false) == true
        if (!trainingReviewMode) {
            publishStatus("تم إيقاف الطلب: التحليل البصري مخصص للتدريب والمراجعة فقط.", active = false)
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode == 0 || resultData == null) {
            publishStatus("لم تصل موافقة التقاط الشاشة من النظام.", active = false)
            stopSelf()
            return START_NOT_STICKY
        }
        startProjection(resultCode, resultData)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        releaseProjection()
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        val settings = BoardCalibrationStore(this).load()
        calibration = settings?.calibration
        trustedSeed = FenSeedStore(this).load()
        pipeline = if (settings == null) {
            publishStatus("لم أجد معايرة محفوظة وصالحة؛ افتح التطبيق واحفظ حدود الرقعة أولاً.")
            null
        } else {
            runCatching {
                val packDirectory = PieceTemplatePackStore(this).packDirectory(settings.theme)
                BoardRecognitionPipeline.calibrated(this, settings.calibration, settings.theme, packDirectory)
            }
                .onFailure { publishStatus("تعذر تهيئة قوالب الرؤية: ${it.message}") }
                .getOrNull()
        }

        if (pipeline == null) {
            publishStatus(
                "تعذر بدء التعرف: لم تتوفر معايرة صالحة أو حزمة قوالب كاملة لهذا الثيم. استورد 26 صورة PNG ثم احفظ الإعدادات.",
                active = false
            )
            releaseProjection()
            stopSelf()
            return
        }

        runtime = createRuntime(trustedSeed)
        val enginePath = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        val engineNote = when {
            "arm64-v8a" !in Build.SUPPORTED_ABIS -> "محرك Stockfish المضمّن متاح حالياً لمعمارية ARM64 فقط؛ معمارية الجهاز الحالية غير مدعومة."
            enginePath.isFile && enginePath.canExecute() -> "Stockfish 19 ARM64 مضمّن في التطبيق؛ سيبدأ التحليل عند أول نقلة مستقرة."
            enginePath.isFile -> "ملف Stockfish موجود لكن النظام لا يسمح بتشغيله من مجلد المكتبات: ${enginePath.absolutePath}."
            else -> "نسخة Stockfish غير موجودة داخل هذا البناء. أعد بناء APK عبر GitHub Actions لتضمين المحرك الحقيقي."
        }
        val seedNote = if (trustedSeed == null) "لا يوجد FEN موثوق محفوظ." else "تم تحميل FEN موثوق؛ بانتظار مطابقة الرقعة بصرياً لثلاث لقطات متتالية."
        publishStatus("التقاط الشاشة نشط في وضع التدريب/المراجعة. $seedNote $engineNote")

        worker = HandlerThread("IraqChessCapture").also { it.start() }
        workerHandler = Handler(worker!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < FRAME_INTERVAL_MS) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastFrameAt = now
            reader.acquireLatestImage()?.use { image ->
                val bitmap = image.toBitmapOrNull()
                if (bitmap != null) {
                    try { processFrame(bitmap) } finally { bitmap.recycle() }
                }
            }
        }, workerHandler)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                publishStatus("أوقف النظام جلسة التقاط الشاشة.", active = false)
                stopSelf()
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "IRAQ_CHESS_HUB_CAPTURE", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, workerHandler
        )
    }

    private fun createRuntime(seed: FenPosition?): RecognizedBoardCaptureRuntime {
        val tracker = LiveBoardTracker()
        val analyzer = PositionAnalyzer { position, depth ->
            val executable = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
            val activeEngine = engine ?: run {
                val candidate = StockfishUciEngine(executable)
                try {
                    candidate.start()
                    check(candidate.engineName?.contains("Stockfish", ignoreCase = true) == true) {
                        "المحرك الموجود لا يعرّف نفسه كـ Stockfish؛ تم رفض تشغيله."
                    }
                    candidate.configure(threads = 2, hashMb = 128)
                    engine = candidate
                    candidate
                } catch (failure: Exception) {
                    candidate.close()
                    throw failure
                }
            }
            activeEngine.analyze(position, depth)
        }
        val session = LiveChessAnalysisSession(tracker, analyzer, depth = 14)
        return RecognizedBoardCaptureRuntime(seed, RecognizedBoardAnalysisCoordinator(session))
    }

    private fun processFrame(bitmap: Bitmap) {
        val activePipeline = pipeline ?: return
        val activeRuntime = runtime ?: return
        val observation = runCatching { activePipeline.process(bitmap) }.getOrNull()
        if (observation == null) {
            val now = System.currentTimeMillis()
            if (now - lastNoDetectionStatusAt >= NO_DETECTION_STATUS_INTERVAL_MS) {
                lastNoDetectionStatusAt = now
                publishStatus("الالتقاط يعمل، لكن لم تُعتمد قراءة رقعة واضحة. راجع حدود المعايرة ومجموعة القطع؛ لا يتم تخمين وضعية.")
            }
            return
        }

        when (val result = activeRuntime.process(observation)) {
            is RecognizedBoardCaptureRuntime.Result.WaitingForSeedStability -> Unit
            is RecognizedBoardCaptureRuntime.Result.Seeded -> publishStatus(
                "تمت مطابقة الرقعة مع FEN المحفوظ بعد ثبات ثلاث لقطات. متابعة وضع التدريب/المراجعة.",
                result.position.toFen()
            )
            is RecognizedBoardCaptureRuntime.Result.SeedPlacementMismatch -> publishStatus(
                "الرقعة الظاهرة لا تطابق FEN المحفوظ. تأكد أن FEN يعود إلى نفس وضعية المباراة، ثم حدّثه.")
            is RecognizedBoardCaptureRuntime.Result.NeedsTrustedSeed -> publishStatus(
                "تمت قراءة شكل القطع، لكن يلزم FEN كامل موثوق لتحديد دور اللعب وحقوق التبييت."
            )
            RecognizedBoardCaptureRuntime.Result.InvalidObservation -> publishStatus(
                "تم رفض لقطة غير موثوقة أو غير مكتملة؛ لم تتغير حالة المباراة."
            )
            is RecognizedBoardCaptureRuntime.Result.Update -> handleUpdate(result.value, observation, bitmap)
        }
    }

    private fun handleUpdate(
        result: RecognizedBoardAnalysisCoordinator.Result,
        observation: BoardObservation,
        bitmap: Bitmap
    ) {
        when (result) {
            is RecognizedBoardAnalysisCoordinator.Result.Update -> when (val update = result.value) {
                is LiveChessAnalysisSession.Update.Tracking -> when (val tracked = update.update) {
                    LiveBoardTracker.Update.WaitingForStability -> Unit
                    is LiveBoardTracker.Update.Unchanged -> Unit
                    is LiveBoardTracker.Update.Rejected -> publishStatus(
                        "رُفض تغير غير مؤكد (${tracked.reason}); تم الاحتفاظ بآخر وضعية صحيحة.", trackedPositionFen()
                    )
                    LiveBoardTracker.Update.NeedsTrustedSeed -> publishStatus("يلزم FEN موثوق قبل تتبع النقلات.")
                    is LiveBoardTracker.Update.MoveAccepted -> Unit
                }
                is LiveChessAnalysisSession.Update.AnalysisCompleted -> {
                    val score = update.result.score?.let { parsed ->
                        when {
                            parsed.mateIn != null -> "مات ${parsed.mateIn} للاعب صاحب الدور"
                            parsed.centipawns != null -> String.format(Locale.US, "%+.2f بيدق", parsed.centipawns / 100.0)
                            else -> "غير متاح"
                        }
                    } ?: "غير متاح"
                    val pv = update.result.principalVariationUci.take(8).joinToString(" ")
                    publishStatus(
                        "تحليل مكتمل: ${update.move.uci} · التقييم $score · العمق ${update.result.depth} · أفضل نقلة ${update.result.bestMoveUci} · PV $pv",
                        update.position.toFen()
                    )
                    showTrainingArrow(update.result.bestMoveUci, observation, bitmap)
                }
                is LiveChessAnalysisSession.Update.AnalysisFailed -> publishStatus(
                    "تم تثبيت النقلة ${update.move.uci}، لكن التحليل تعذر: ${update.reason}. يمكن إعادة المحاولة بعد تثبيت المحرك.",
                    update.position.toFen()
                )
                LiveChessAnalysisSession.Update.NoPendingAnalysis -> Unit
            }
            RecognizedBoardAnalysisCoordinator.Result.InvalidObservation -> publishStatus(
                "ملاحظة الرؤية غير صالحة؛ تم تجاهلها دون تعديل وضعية المباراة."
            )
            RecognizedBoardAnalysisCoordinator.Result.NeedsTrustedSeed -> publishStatus(
                "لا يوجد FEN بداية موثوق. احفظ FEN الوضعية الحالية أولاً."
            )
            is RecognizedBoardAnalysisCoordinator.Result.Seeded -> publishStatus(
                "تم تجهيز وضعية البداية.", result.position.toFen()
            )
        }
    }

    private fun showTrainingArrow(uci: String, observation: BoardObservation, bitmap: Bitmap) {
        if (!trainingReviewMode || !android.provider.Settings.canDrawOverlays(this)) return
        val intent = Intent(this, ArrowOverlayService::class.java).apply {
            action = ArrowOverlayService.ACTION_SHOW_MOVE
            putExtra(ArrowOverlayService.EXTRA_UCI_MOVE, uci)
            putExtra(ArrowOverlayService.EXTRA_BOARD_LEFT, observation.bounds.left.toFloat() / bitmap.width)
            putExtra(ArrowOverlayService.EXTRA_BOARD_TOP, observation.bounds.top.toFloat() / bitmap.height)
            putExtra(ArrowOverlayService.EXTRA_BOARD_WIDTH, observation.bounds.width.toFloat() / bitmap.width)
            putExtra(ArrowOverlayService.EXTRA_BOARD_HEIGHT, observation.bounds.height.toFloat() / bitmap.height)
            putExtra(ArrowOverlayService.EXTRA_WHITE_AT_BOTTOM, calibration?.whiteAtBottom ?: true)
        }
        runCatching { startService(intent) }
    }

    private fun trackedPositionFen(): String? = runtime?.currentPosition()?.toFen()

    private fun publishStatus(message: String, fen: String? = trackedPositionFen(), active: Boolean = true) {
        CaptureRuntimeStatusStore(this).update(message, fen, active)
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun buildNotification(message: String): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("IRAQ CHESS HUB · تدريب ومراجعة")
        .setContentText(message.take(120))
        .setSmallIcon(android.R.drawable.ic_menu_camera)
        .setOngoing(true)
        .build()

    private fun Image.toBitmapOrNull(): Bitmap? {
        val plane = planes.firstOrNull() ?: return null
        val source: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride != 4 || rowStride < width * pixelStride) return null
        val rowBytes = width * pixelStride
        val base = source.position()
        val requiredEnd = base.toLong() + (height - 1L) * rowStride + rowBytes
        if (requiredEnd > source.limit()) return null

        // Copy only visible pixels from each row. Image plane buffers often omit padding
        // after the final row, so copying the padded buffer wholesale can underflow.
        val compact = ByteBuffer.allocate(rowBytes * height)
        val rowView = source.duplicate()
        for (row in 0 until height) {
            val rowStart = base + row * rowStride
            rowView.position(rowStart)
            rowView.limit(rowStart + rowBytes)
            compact.put(rowView)
        }
        compact.flip()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        return try {
            bitmap.copyPixelsFromBuffer(compact)
            bitmap
        } catch (failure: Exception) {
            bitmap.recycle()
            null
        }
    }

    private fun releaseProjection() {
        virtualDisplay?.release(); virtualDisplay = null
        pipeline?.close(); pipeline = null
        runtime = null
        calibration = null
        trustedSeed = null
        engine?.close(); engine = null
        imageReader?.close(); imageReader = null
        val activeProjection = projection
        projection = null
        runCatching { activeProjection?.stop() }
        worker?.quitSafely(); worker = null
        workerHandler = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        releaseProjection()
        CaptureRuntimeStatusStore(this).update("تم إيقاف التقاط الشاشة وخدمة التعرف.", active = false)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_TRAINING_REVIEW_MODE = "training_review_mode"
        private const val CHANNEL_ID = "iraq_chess_capture"
        private const val NOTIFICATION_ID = 2101
        private const val FRAME_INTERVAL_MS = 500L
        private const val NO_DETECTION_STATUS_INTERVAL_MS = 7000L
    }
}
