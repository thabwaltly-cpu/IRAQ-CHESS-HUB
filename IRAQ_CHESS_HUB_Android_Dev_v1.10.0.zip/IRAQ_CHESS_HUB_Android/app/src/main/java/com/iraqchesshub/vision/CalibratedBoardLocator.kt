package com.iraqchesshub.vision

import android.graphics.Bitmap

/** Locates the board using a normalized user calibration rectangle. */
class CalibratedBoardLocator(private val calibration: BoardCalibration) : ChessBoardLocator {
    override fun locate(frame: Bitmap): BoardBounds? =
        calibration.pixelBounds(frame.width, frame.height)
}
