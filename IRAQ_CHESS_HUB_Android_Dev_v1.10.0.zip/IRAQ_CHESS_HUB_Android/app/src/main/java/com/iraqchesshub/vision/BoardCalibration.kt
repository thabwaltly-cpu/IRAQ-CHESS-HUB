package com.iraqchesshub.vision

/**
 * Normalized board rectangle from a one-time user calibration.
 * Coordinates are relative to the full captured display (0.0..1.0).
 */
data class BoardCalibration(
    val left: Float,
    val top: Float,
    val size: Float,
    val whiteAtBottom: Boolean = true
) {
    init {
        require(left in 0f..1f && top in 0f..1f && size in 0.01f..1f)
    }

    /**
     * The board size is a fraction of the shorter display dimension, while left/top
     * are fractions of their respective display axes. These units differ on a
     * portrait or landscape screen, so bounds must be checked with real frame sizes.
     */
    fun pixelBounds(frameWidth: Int, frameHeight: Int): BoardBounds? {
        if (frameWidth <= 0 || frameHeight <= 0) return null
        val pixelLeft = (left * frameWidth).toInt()
        val pixelTop = (top * frameHeight).toInt()
        val pixelSize = (size * minOf(frameWidth, frameHeight)).toInt()
        if (pixelSize < 160 || pixelLeft < 0 || pixelTop < 0 ||
            pixelLeft + pixelSize > frameWidth || pixelTop + pixelSize > frameHeight) return null
        return BoardBounds(pixelLeft, pixelTop, pixelSize, pixelSize)
    }

    fun squareCenter(square: String): Pair<Float, Float>? {
        if (square.length != 2 || square[0] !in 'a'..'h' || square[1] !in '1'..'8') return null
        val file = square[0] - 'a'
        val rank = square[1] - '1'
        val col = if (whiteAtBottom) file else 7 - file
        val row = if (whiteAtBottom) 7 - rank else rank
        val cell = size / 8f
        return (left + (col + 0.5f) * cell) to (top + (row + 0.5f) * cell)
    }
}
