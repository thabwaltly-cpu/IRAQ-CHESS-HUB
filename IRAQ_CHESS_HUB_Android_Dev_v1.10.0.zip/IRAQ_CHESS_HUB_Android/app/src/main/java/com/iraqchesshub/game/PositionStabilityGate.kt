package com.iraqchesshub.game

/** Prevents running analysis on transient animation frames: require repeated identical positions. */
class PositionStabilityGate(private val requiredMatches: Int = 3) {
    init { require(requiredMatches >= 2) }
    private var last: String? = null
    private var matches = 0

    @Synchronized fun accept(fenPlacement: String): Boolean {
        if (fenPlacement == last) matches++ else {
            last = fenPlacement
            matches = 1
        }
        return matches >= requiredMatches
    }

    @Synchronized fun reset() { last = null; matches = 0 }
}
