package com.iraqchesshub.game

import com.iraqchesshub.vision.DetectedPiece

/** Complete FEN metadata. Screenshot recognition must never guess turn or historic rights. */
data class FenMetadata(
    val sideToMove: Char,
    val castling: String = "-",
    val enPassant: String = "-",
    val halfmoveClock: Int = 0,
    val fullmoveNumber: Int = 1
) {
    init {
        require(sideToMove == 'w' || sideToMove == 'b')
        require(castling == "-" || (castling.all { it in "KQkq" } &&
            castling.toSet().size == castling.length && castling == "KQkq".filter { it in castling }))
        require(enPassant == "-" || enPassant.matches(Regex("[a-h]${if (sideToMove == 'w') "6" else "3"}")))
        require(halfmoveClock >= 0 && fullmoveNumber >= 1)
    }
}

data class FenPosition(val placement: String, val metadata: FenMetadata) {
    init {
        require(isValidPlacement(placement)) { "Invalid FEN piece placement" }
        require(metadataMatchesBoard(placement, metadata)) { "FEN metadata conflicts with piece placement" }
    }

    fun toFen(): String = "$placement ${metadata.sideToMove} ${metadata.castling} ${metadata.enPassant} ${metadata.halfmoveClock} ${metadata.fullmoveNumber}"

    /** Expands this validated placement into an immutable square-to-piece map. */
    fun toPieceMap(): Map<String, Char> {
        val result = LinkedHashMap<String, Char>()
        val ranks = placement.split('/')
        for ((row, rankText) in ranks.withIndex()) {
            var file = 0
            for (token in rankText) {
                if (token in '1'..'8') {
                    file += token - '0'
                } else {
                    result["${'a' + file}${8 - row}"] = token
                    file++
                }
            }
        }
        return result.toMap()
    }

    companion object {
        /** Parses all six FEN fields and rejects incomplete or inconsistent game metadata. */
        fun parse(fen: String): FenPosition? {
            val fields = fen.trim().split(Regex("\\s+"))
            if (fields.size != 6) return null
            val halfmove = fields[4].toIntOrNull() ?: return null
            val fullmove = fields[5].toIntOrNull() ?: return null
            val metadata = runCatching {
                FenMetadata(fields[1].singleOrNull() ?: return null, fields[2], fields[3], halfmove, fullmove)
            }.getOrNull() ?: return null
            return runCatching { FenPosition(fields[0], metadata) }.getOrNull()
        }

        /** Builds a typed FEN directly from an immutable board snapshot. */
        fun fromPieceMap(pieces: Map<String, Char>, metadata: FenMetadata): FenPosition? {
            if (pieces.size !in 2..32) return null
            val detected = pieces.map { (square, symbol) -> DetectedPiece(square, symbol, 1.0f) }
            return fromPieces(detected, metadata)
        }

        /** Converts a complete, confidently recognized board; returns null rather than guessing. */
        fun fromPieces(pieces: List<DetectedPiece>, metadata: FenMetadata): FenPosition? {
            if (pieces.size !in 2..32 || pieces.map { it.square }.toSet().size != pieces.size) return null
            if (pieces.any {
                    it.symbol !in "pnbrqkPNBRQK" || !it.confidence.isFinite() ||
                        it.confidence !in 0.80f..1.0f || !it.square.matches(Regex("[a-h][1-8]"))
                }) return null
            if (pieces.count { it.symbol == 'K' } != 1 || pieces.count { it.symbol == 'k' } != 1) return null

            val board = Array(8) { CharArray(8) { '.' } }
            for (piece in pieces) {
                val file = piece.square[0] - 'a'
                val rank = piece.square[1] - '1'
                board[7 - rank][file] = piece.symbol
            }
            val placement = board.joinToString("/") { row ->
                val out = StringBuilder(); var empty = 0
                for (cell in row) {
                    if (cell == '.') empty++ else {
                        if (empty > 0) { out.append(empty); empty = 0 }
                        out.append(cell)
                    }
                }
                if (empty > 0) out.append(empty)
                out.toString()
            }
            if (!isValidPlacement(placement)) return null
            if (!metadataMatchesBoard(placement, metadata)) return null
            return FenPosition(placement, metadata)
        }

        /** Validates the eight FEN ranks and basic material invariants, not full chess legality. */
        fun isValidPlacement(placement: String): Boolean {
            val ranks = placement.split('/')
            if (ranks.size != 8) return false
            val board = Array(8) { CharArray(8) { '.' } }
            for ((rowIndex, rankText) in ranks.withIndex()) {
                var file = 0
                for (token in rankText) {
                    when {
                        token in '1'..'8' -> file += token - '0'
                        token in "pnbrqkPNBRQK" -> {
                            if (file >= 8) return false
                            board[rowIndex][file++] = token
                        }
                        else -> return false
                    }
                    if (file > 8) return false
                }
                if (file != 8) return false
            }
            val pieces = board.flatMap { it.asIterable() }.filter { it != '.' }
            if (pieces.size !in 2..32 || pieces.count { it == 'K' } != 1 || pieces.count { it == 'k' } != 1) return false
            if (pieces.count { it == 'P' } > 8 || pieces.count { it == 'p' } > 8) return false
            if ((0..7).any { board[0][it] in "Pp" || board[7][it] in "Pp" }) return false
            val whiteKing = locateKing(board, 'K') ?: return false
            val blackKing = locateKing(board, 'k') ?: return false
            if (kotlin.math.abs(whiteKing.first - blackKing.first) <= 1 &&
                kotlin.math.abs(whiteKing.second - blackKing.second) <= 1) return false
            return true
        }

        private fun locateKing(board: Array<CharArray>, king: Char): Pair<Int, Int>? {
            for (row in 0..7) for (file in 0..7) {
                if (board[row][file] == king) return row to file
            }
            return null
        }

        private fun metadataMatchesBoard(placement: String, metadata: FenMetadata): Boolean {
            val rows = placement.split('/')
            val board = Array(8) { CharArray(8) { '.' } }
            for (r in 0..7) {
                var f = 0
                for (c in rows[r]) if (c in '1'..'8') f += c - '0' else board[r][f++] = c
            }
            fun has(square: String, piece: Char): Boolean {
                val file = square[0] - 'a'
                val rank = square[1] - '1'
                return board[7 - rank][file] == piece
            }
            if ('K' in metadata.castling && (!has("e1", 'K') || !has("h1", 'R'))) return false
            if ('Q' in metadata.castling && (!has("e1", 'K') || !has("a1", 'R'))) return false
            if ('k' in metadata.castling && (!has("e8", 'k') || !has("h8", 'r'))) return false
            if ('q' in metadata.castling && (!has("e8", 'k') || !has("a8", 'r'))) return false
            if (metadata.enPassant != "-") {
                val file = metadata.enPassant[0]
                val pawnSquare = if (metadata.sideToMove == 'w') "${file}5" else "${file}4"
                val pawn = if (metadata.sideToMove == 'w') 'p' else 'P'
                if (!has(metadata.enPassant, '.') || !has(pawnSquare, pawn)) return false
            }
            return true
        }
    }
}


/** Advances FEN history fields from one already-detected visual move. */
object FenMetadataTracker {
    fun afterMove(metadata: FenMetadata, before: Map<String, Char>, move: MoveDeltaDetector.MoveDelta): FenMetadata? {
        if (!move.from.matches(Regex("[a-h][1-8]")) || !move.to.matches(Regex("[a-h][1-8]"))) return null
        if (move.promotion != null && move.promotion !in "qrbn") return null
        if (move.uci != move.from + move.to + (move.promotion?.toString() ?: "")) return null
        val moving = before[move.from] ?: return null
        if (move.promotion != null && (moving.lowercaseChar() != 'p' || move.to[1] !in "18")) return null
        if (moving.lowercaseChar() == 'p' && move.to[1] in "18" && move.promotion == null) return null
        if ((metadata.sideToMove == 'w') != moving.isUpperCase()) return null
        val destinationPiece = before[move.to]
        if (destinationPiece != null && destinationPiece.isUpperCase() == moving.isUpperCase()) return null
        if (move.capturedOn != null) {
            val captured = before[move.capturedOn] ?: return null
            if (captured.isUpperCase() == moving.isUpperCase()) return null
        } else if (destinationPiece != null) return null

        var rights = metadata.castling.filterNot { right ->
            (moving == 'K' && right in "KQ") || (moving == 'k' && right in "kq") ||
                (move.from == "h1" && right == 'K') || (move.from == "a1" && right == 'Q') ||
                (move.from == "h8" && right == 'k') || (move.from == "a8" && right == 'q') ||
                (move.capturedOn == "h1" && right == 'K') || (move.capturedOn == "a1" && right == 'Q') ||
                (move.capturedOn == "h8" && right == 'k') || (move.capturedOn == "a8" && right == 'q')
        }
        if (rights.isEmpty()) rights = "-"

        val enPassant = if (moving.lowercaseChar() == 'p' && move.from[0] == move.to[0] &&
            kotlin.math.abs(move.from[1] - move.to[1]) == 2) {
            "${move.from[0]}${(move.from[1].digitToInt() + move.to[1].digitToInt()) / 2}"
        } else "-"

        return runCatching {
            FenMetadata(
                sideToMove = if (metadata.sideToMove == 'w') 'b' else 'w',
                castling = rights,
                enPassant = enPassant,
                halfmoveClock = if (moving.lowercaseChar() == 'p' || move.capturedOn != null) 0 else metadata.halfmoveClock + 1,
                fullmoveNumber = metadata.fullmoveNumber + if (metadata.sideToMove == 'b') 1 else 0
            )
        }.getOrNull()
    }
}
