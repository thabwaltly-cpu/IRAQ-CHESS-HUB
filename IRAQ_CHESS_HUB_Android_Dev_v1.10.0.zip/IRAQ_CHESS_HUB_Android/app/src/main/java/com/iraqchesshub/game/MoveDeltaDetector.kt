package com.iraqchesshub.game

/**
 * Infers a single move from two confidently recognized board placements.
 * This is a visual-delta helper, not a legal-move validator. It deliberately returns
 * null for ambiguous/multi-piece changes instead of guessing a move.
 */
object MoveDeltaDetector {
    data class MoveDelta(
        val uci: String,
        val from: String,
        val to: String,
        val promotion: Char? = null,
        val isCastling: Boolean = false,
        val capturedOn: String? = null
    )

    fun detect(before: Map<String, Char>, after: Map<String, Char>): MoveDelta? {
        if (!validBoard(before) || !validBoard(after) || before == after) return null
        val changed = (before.keys + after.keys).filter { before[it] != after[it] }.toSet()

        detectCastling(before, after, changed)?.let { return it }
        detectEnPassant(before, after, changed)?.let { return it }

        // A normal move changes exactly its source and destination squares, including
        // captures and promotions. Any larger delta is treated as animation/recognition noise.
        if (changed.size != 2) return null
        val sources = changed.filter { sq -> before[sq] != null && after[sq] == null }
        val destinations = changed.filter { sq -> after[sq] != null && before[sq] != after[sq] }
        if (sources.size != 1 || destinations.size != 1) return null

        val from = sources.single()
        val to = destinations.single()
        val moving = before[from] ?: return null
        val landed = after[to] ?: return null
        if (moving.isUpperCase() != landed.isUpperCase()) return null
        val captured = before[to]
        if (captured != null && captured.isUpperCase() == moving.isUpperCase()) return null

        val promotion = if (moving.lowercaseChar() == 'p' && landed.lowercaseChar() in "qrbn" && to[1] in "18") {
            landed.lowercaseChar()
        } else {
            if (moving.lowercaseChar() != landed.lowercaseChar()) return null
            null
        }
        if (moving.lowercaseChar() == 'p' && to[1] in "18" && promotion == null) return null
        if (moving.lowercaseChar() != 'p' && promotion != null) return null

        return MoveDelta(
            uci = from + to + (promotion?.toString() ?: ""),
            from = from,
            to = to,
            promotion = promotion,
            capturedOn = to.takeIf { before[it] != null }
        )
    }


    private fun detectEnPassant(
        before: Map<String, Char>,
        after: Map<String, Char>,
        changed: Set<String>
    ): MoveDelta? {
        if (changed.size != 3) return null
        val destinations = changed.filter { after[it]?.let { piece -> piece in "Pp" } == true && before[it] == null }
        if (destinations.size != 1) return null
        val to = destinations.single()
        val landedPawn = after[to] ?: return null
        val rankStep = if (landedPawn.isUpperCase()) 1 else -1
        val sources = changed.filter { from ->
            val moving = before[from]
            moving == landedPawn && after[from] == null &&
                kotlin.math.abs(from[0] - to[0]) == 1 && to[1] - from[1] == rankStep
        }
        if (sources.size != 1) return null
        val from = sources.single()
        val capturedSquare = "${to[0]}${from[1]}"
        val capturedPiece = if (landedPawn.isUpperCase()) 'p' else 'P'
        if (capturedSquare !in changed || before[capturedSquare] != capturedPiece || after[capturedSquare] != null) return null
        return MoveDelta(from + to, from, to, capturedOn = capturedSquare)
    }

    private fun detectCastling(
        before: Map<String, Char>,
        after: Map<String, Char>,
        changed: Set<String>
    ): MoveDelta? {
        if (changed.size != 4) return null
        val candidates = listOf(
            Castle("e1", "g1", "h1", "f1", 'K'), Castle("e1", "c1", "a1", "d1", 'K'),
            Castle("e8", "g8", "h8", "f8", 'k'), Castle("e8", "c8", "a8", "d8", 'k')
        )
        return candidates.firstOrNull { c ->
            changed == setOf(c.kingFrom, c.kingTo, c.rookFrom, c.rookTo) &&
                before[c.kingFrom] == c.king && after[c.kingFrom] == null &&
                after[c.kingTo] == c.king && before[c.rookFrom] == (if (c.king.isUpperCase()) 'R' else 'r') &&
                after[c.rookFrom] == null && after[c.rookTo] == (if (c.king.isUpperCase()) 'R' else 'r')
        }?.let { c -> MoveDelta(c.kingFrom + c.kingTo, c.kingFrom, c.kingTo, isCastling = true) }
    }

    private fun validBoard(board: Map<String, Char>): Boolean =
        board.size <= 32 && board.all { (square, piece) ->
            square.matches(Regex("[a-h][1-8]")) && piece in "pnbrqkPNBRQK"
        }

    private data class Castle(
        val kingFrom: String, val kingTo: String,
        val rookFrom: String, val rookTo: String, val king: Char
    )
}
