package com.iraqchesshub.vision

import android.content.Context

/** Persists only user-confirmed normalized calibration; never guesses a board rectangle. */
class BoardCalibrationStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): SavedVisionSettings? {
        if (!prefs.getBoolean(KEY_CONFIGURED, false)) return null
        val left = prefs.getFloat(KEY_LEFT, Float.NaN)
        val top = prefs.getFloat(KEY_TOP, Float.NaN)
        val size = prefs.getFloat(KEY_SIZE, Float.NaN)
        val theme = prefs.getString(KEY_THEME, null) ?: return null
        val whiteAtBottom = prefs.getBoolean(KEY_WHITE_BOTTOM, true)
        if (!PieceTemplatePackSpec.isValidTheme(theme)) return null
        val calibration = runCatching { BoardCalibration(left, top, size, whiteAtBottom) }.getOrNull() ?: return null
        return SavedVisionSettings(calibration, theme)
    }

    fun save(calibration: BoardCalibration, theme: String) {
        require(PieceTemplatePackSpec.isValidTheme(theme)) { "Invalid theme name" }
        prefs.edit()
            .putBoolean(KEY_CONFIGURED, true)
            .putFloat(KEY_LEFT, calibration.left)
            .putFloat(KEY_TOP, calibration.top)
            .putFloat(KEY_SIZE, calibration.size)
            .putBoolean(KEY_WHITE_BOTTOM, calibration.whiteAtBottom)
            .putString(KEY_THEME, theme)
            .apply()
    }

    fun clear() { prefs.edit().clear().apply() }

    companion object {
        private const val PREFS = "iraq_chess_vision"
        private const val KEY_CONFIGURED = "configured"
        private const val KEY_LEFT = "left"
        private const val KEY_TOP = "top"
        private const val KEY_SIZE = "size"
        private const val KEY_WHITE_BOTTOM = "white_bottom"
        private const val KEY_THEME = "theme"
    }
}

data class SavedVisionSettings(val calibration: BoardCalibration, val theme: String)
