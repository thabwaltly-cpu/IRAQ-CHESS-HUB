package com.iraqchesshub.game

import android.content.Context

/** Stores only a user-provided, fully validated FEN seed for the current training/review session. */
class FenSeedStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadRaw(): String? = prefs.getString(KEY_FEN, null)

    fun load(): FenPosition? = loadRaw()?.let(FenPosition::parse)

    fun save(fen: String): FenPosition {
        val parsed = requireNotNull(FenPosition.parse(fen)) { "FEN must contain six valid fields and consistent board metadata" }
        check(prefs.edit().putString(KEY_FEN, parsed.toFen()).commit()) { "Could not persist FEN seed" }
        return parsed
    }

    fun clear() { prefs.edit().remove(KEY_FEN).apply() }

    companion object {
        private const val PREFS = "iraq_chess_game_seed"
        private const val KEY_FEN = "trusted_fen"
    }
}
