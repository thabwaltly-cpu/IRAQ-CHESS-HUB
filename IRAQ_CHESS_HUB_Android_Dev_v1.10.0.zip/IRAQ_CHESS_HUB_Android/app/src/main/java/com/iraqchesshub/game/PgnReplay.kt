package com.iraqchesshub.game

/** Replays a parsed PGN main line into validated FEN snapshots. */
data class PgnReplayResult(
    val positions: List<FenPosition>,
    val failedPly: Int? = null,
    val error: String? = null
) {
    val complete: Boolean get() = failedPly == null
}

object PgnReplay {
    private data class San(
        val piece: Char,
        val destination: String,
        val fromFile: Char?,
        val fromRank: Char?,
        val capture: Boolean,
        val promotion: Char?,
        val castle: String?
    )

    /** Returns initial position plus one FEN for every SAN move, or the first failing ply. */
    fun replay(game: PgnGame): PgnReplayResult {
        val initial = game.initialFen?.let(FenPosition::parse) ?: FenPosition.parse(START_FEN)
            ?: return PgnReplayResult(emptyList(), 0, "Invalid initial FEN")
        if (game.initialFen != null && game.headers["SetUp"] != "1") {
            return PgnReplayResult(emptyList(), 0, "FEN header requires SetUp=1")
        }
        val positions = mutableListOf(initial)
        var current = initial
        for ((index, token) in game.sanMoves.withIndex()) {
            val next = applySan(current, token)
                ?: return PgnReplayResult(positions.toList(), index + 1, "Illegal or ambiguous SAN: $token")
            positions += next
            current = next
        }
        return PgnReplayResult(positions.toList())
    }

    private fun applySan(position: FenPosition, raw: String): FenPosition? {
        val san = parseSan(raw) ?: return null
        val board = position.toPieceMap()
        val white = position.metadata.sideToMove == 'w'
        val destination = when (san.castle) {
            "K" -> if (white) "g1" else "g8"
            "Q" -> if (white) "c1" else "c8"
            else -> san.destination
        }
        val movingSymbol = if (white) san.piece.uppercaseChar() else san.piece.lowercaseChar()
        val candidates = mutableListOf<MoveDeltaDetector.MoveDelta>()

        for ((from, piece) in board) {
            if (piece != movingSymbol) continue
            if (san.fromFile != null && from[0] != san.fromFile) continue
            if (san.fromRank != null && from[1] != san.fromRank) continue
            val to = destination
            val target = board[to]
            if (san.capture != (target != null || (piece.lowercaseChar() == 'p' && from[0] != to[0] && position.metadata.enPassant == to))) continue
            val promotionChoices = if (san.promotion != null) listOf(san.promotion) else if (piece.lowercaseChar() == 'p' && to[1] in "18") listOf('q', 'r', 'b', 'n') else listOf(null)
            for (promotion in promotionChoices) {
                val epCapture = if (piece.lowercaseChar() == 'p' && from[0] != to[0] && target == null) "${to[0]}${from[1]}" else null
                val castle = san.castle != null
                val move = MoveDeltaDetector.MoveDelta(
                    uci = from + to + (promotion?.toString() ?: ""),
                    from = from,
                    to = to,
                    promotion = promotion,
                    isCastling = castle,
                    capturedOn = if (epCapture != null) epCapture else to.takeIf { target != null }
                )
                if (ChessMoveLegality.isLegal(position, move)) candidates += move
            }
        }
        if (candidates.size != 1) return null
        val move = candidates.single()
        val nextMetadata = FenMetadataTracker.afterMove(position.metadata, board, move) ?: return null
        val nextBoard = board.toMutableMap()
        val moving = nextBoard.remove(move.from) ?: return null
        move.capturedOn?.let(nextBoard::remove)
        val landed = move.promotion?.let { if (white) it.uppercaseChar() else it } ?: moving
        nextBoard[move.to] = landed
        if (move.isCastling) {
            val (rookFrom, rookTo) = when (move.from + move.to) {
                "e1g1" -> "h1" to "f1"
                "e1c1" -> "a1" to "d1"
                "e8g8" -> "h8" to "f8"
                "e8c8" -> "a8" to "d8"
                else -> return null
            }
            val rook = nextBoard.remove(rookFrom) ?: return null
            nextBoard[rookTo] = rook
        }
        return FenPosition.fromPieceMap(nextBoard, nextMetadata)
    }

    private fun parseSan(raw: String): San? {
        var token = raw.replace('0', 'O').replace(Regex("[+#?!]+$"), "")
        if (token == "O-O") return San('k', "g1", null, null, false, null, "K")
        if (token == "O-O-O") return San('k', "c1", null, null, false, null, "Q")
        val match = Regex("^([KQRBN])?([a-h])?([1-8])?(x)?([a-h][1-8])(=([QRBN]))?$").matchEntire(token) ?: return null
        val piece = match.groupValues[1].firstOrNull()?.lowercaseChar() ?: 'p'
        val fromFile = match.groupValues[2].firstOrNull()
        val fromRank = match.groupValues[3].firstOrNull()
        val capture = match.groupValues[4].isNotEmpty()
        val destination = match.groupValues[5]
        val promotion = match.groupValues[7].firstOrNull()?.lowercaseChar()
        if (promotion != null && piece != 'p') return null
        return San(piece, destination, fromFile, fromRank, capture, promotion, null)
    }

    const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
}
