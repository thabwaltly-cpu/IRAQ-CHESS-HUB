package com.iraqchesshub.game

/** Terminal and claimable outcomes derived from a trusted sequence of complete FEN positions. */
enum class GameOutcome {
    ONGOING,
    WHITE_WINS_BY_CHECKMATE,
    BLACK_WINS_BY_CHECKMATE,
    STALEMATE,
    INSUFFICIENT_MATERIAL,
    SEVENTY_FIVE_MOVE_RULE,
    FIVEFOLD_REPETITION,
    FIFTY_MOVE_CLAIM_AVAILABLE,
    THREEFOLD_REPETITION_CLAIM_AVAILABLE
}

object GameAdjudicator {
    /**
     * history must include the current position and every prior position since the start
     * of the game. Repetition identity uses placement, side-to-move, castling and EP fields.
     * This is conservative for en-passant positions whose target is not actually capturable.
     */
    fun evaluate(current: FenPosition, history: List<FenPosition> = listOf(current)): GameOutcome {
        val completeHistory = if (history.lastOrNull()?.toFen() == current.toFen()) history else history + current
        val hasMove = ChessMoveLegality.hasAnyLegalMove(current)
        if (!hasMove) {
            return if (ChessMoveLegality.isInCheck(current, current.metadata.sideToMove == 'w')) {
                if (current.metadata.sideToMove == 'w') GameOutcome.BLACK_WINS_BY_CHECKMATE
                else GameOutcome.WHITE_WINS_BY_CHECKMATE
            } else GameOutcome.STALEMATE
        }
        if (isInsufficientMaterial(current)) return GameOutcome.INSUFFICIENT_MATERIAL
        if (current.metadata.halfmoveClock >= 150) return GameOutcome.SEVENTY_FIVE_MOVE_RULE
        val repetitions = completeHistory.count { repetitionKey(it) == repetitionKey(current) }
        if (repetitions >= 5) return GameOutcome.FIVEFOLD_REPETITION
        if (current.metadata.halfmoveClock >= 100) return GameOutcome.FIFTY_MOVE_CLAIM_AVAILABLE
        if (repetitions >= 3) return GameOutcome.THREEFOLD_REPETITION_CLAIM_AVAILABLE
        return GameOutcome.ONGOING
    }

    fun isInsufficientMaterial(position: FenPosition): Boolean {
        val pieces = position.toPieceMap()
        val nonKings = pieces.filterValues { it.lowercaseChar() != 'k' }
        if (nonKings.isEmpty()) return true
        if (nonKings.values.any { it.lowercaseChar() in "pqr" }) return false
        if (nonKings.size == 1) return nonKings.values.single().lowercaseChar() in "bn"
        // Bishop-only endings are dead when every bishop is confined to the same square color.
        if (nonKings.values.all { it.lowercaseChar() == 'b' }) {
            val colors = nonKings.keys.map { square ->
                ((square[0] - 'a') + (square[1] - '1')) % 2
            }.toSet()
            return colors.size == 1
        }
        return false
    }

    private fun repetitionKey(position: FenPosition): String =
        "${position.placement} ${position.metadata.sideToMove} ${position.metadata.castling} ${position.metadata.enPassant}"
}
