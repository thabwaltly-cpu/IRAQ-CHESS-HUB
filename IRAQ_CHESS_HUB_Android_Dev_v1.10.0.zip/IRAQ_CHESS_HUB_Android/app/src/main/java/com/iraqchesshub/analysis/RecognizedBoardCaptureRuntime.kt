package com.iraqchesshub.analysis

import com.iraqchesshub.game.FenPosition
import com.iraqchesshub.game.PositionStabilityGate
import com.iraqchesshub.vision.BoardObservation

/**
 * Runtime bridge used by the capture service. It requires three matching observations of the
 * exact user-supplied FEN placement before seeding, then delegates subsequent stable changes to
 * the normal move tracker. Historic FEN fields are never inferred from screenshots.
 */
class RecognizedBoardCaptureRuntime(
    private val trustedSeed: FenPosition?,
    private val coordinator: RecognizedBoardAnalysisCoordinator,
    seedStableFrames: Int = 3
) {
    sealed class Result {
        data class WaitingForSeedStability(val placement: String) : Result()
        data class Seeded(val position: FenPosition) : Result()
        data class SeedPlacementMismatch(val expected: String, val observed: String) : Result()
        data class Update(val value: RecognizedBoardAnalysisCoordinator.Result) : Result()
        data class NeedsTrustedSeed(val observedPlacement: String) : Result()
        data object InvalidObservation : Result()
    }

    private val seedGate = PositionStabilityGate(seedStableFrames)
    private var seeded = false

    fun process(observation: BoardObservation): Result {
        if (!observation.confidence.isFinite() || observation.confidence < 0.80f) return Result.InvalidObservation
        val pieces = observation.toPieceMap() ?: return Result.InvalidObservation
        val observedPlacement = observation.toFenPlacement() ?: return Result.InvalidObservation
        val seed = trustedSeed
        if (!seeded) {
            if (seed == null) return Result.NeedsTrustedSeed(observedPlacement)
            val observed = FenPosition.fromPieceMap(pieces, seed.metadata) ?: return Result.InvalidObservation
            if (observed.placement != seed.placement) {
                seedGate.reset()
                return Result.SeedPlacementMismatch(seed.placement, observed.placement)
            }
            if (!seedGate.accept(observed.placement)) return Result.WaitingForSeedStability(observed.placement)
            return when (val seededResult = coordinator.seed(observation, seed.metadata)) {
                is RecognizedBoardAnalysisCoordinator.Result.Seeded -> {
                    seeded = true
                    seedGate.reset()
                    Result.Seeded(seededResult.position)
                }
                else -> Result.InvalidObservation
            }
        }
        return Result.Update(coordinator.process(observation))
    }

    fun currentPosition(): FenPosition? = coordinator.currentPosition()
}
