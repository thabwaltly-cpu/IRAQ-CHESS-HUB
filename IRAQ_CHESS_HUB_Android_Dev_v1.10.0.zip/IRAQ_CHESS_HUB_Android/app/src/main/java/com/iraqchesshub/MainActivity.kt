package com.iraqchesshub

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.iraqchesshub.capture.CaptureRuntimeStatusStore
import com.iraqchesshub.capture.ScreenCaptureService
import com.iraqchesshub.overlay.ArrowOverlayService
import com.iraqchesshub.vision.BoardCalibration
import com.iraqchesshub.vision.BoardCalibrationStore
import com.iraqchesshub.vision.PieceTemplatePackStore
import com.iraqchesshub.game.FenSeedStore
import com.iraqchesshub.game.PgnGame
import com.iraqchesshub.game.PgnParser
import com.iraqchesshub.game.PgnReplay
import com.iraqchesshub.game.PgnReplayResult

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IraqChessHubScreen() }
    }
}

@Composable
private fun IraqChessHubScreen() {
    val context = LocalContext.current
    var overlayReady by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var captureStarted by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("جاهز. احفظ FEN البداية والمعايرة قبل الالتقاط.") }
    val runtimeStatusStore = remember { CaptureRuntimeStatusStore(context) }
    var runtimeStatus by remember { mutableStateOf(runtimeStatusStore.load()) }
    val seedStore = remember { FenSeedStore(context) }
    var fenText by remember { mutableStateOf(seedStore.loadRaw() ?: STARTING_FEN) }
    var fenSaved by remember { mutableStateOf(seedStore.load() != null) }
    var trainingReviewMode by remember { mutableStateOf(false) }
    var importedPgn by remember { mutableStateOf<PgnGame?>(null) }
    var pgnReplay by remember { mutableStateOf<PgnReplayResult?>(null) }
    var replayPly by remember { mutableIntStateOf(0) }
    val pgnImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            message = "لم يتم اختيار ملف PGN."
        } else {
            runCatching {
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("تعذر فتح الملف")
                require(content.length <= 2_000_000) { "حجم PGN يتجاوز 2 MB" }
                val parsed = PgnParser.parse(content) ?: error("صيغة PGN غير صالحة أو غير مدعومة")
                val replay = PgnReplay.replay(parsed)
                require(replay.positions.isNotEmpty()) { replay.error ?: "تعذر إنشاء وضعية البداية" }
                parsed to replay
            }.onSuccess { (parsed, replay) ->
                importedPgn = parsed
                pgnReplay = replay
                replayPly = 0
                message = if (replay.complete) "تم استيراد المباراة والتحقق من ${parsed.sanMoves.size} نقلة." else "تم استيراد PGN جزئياً؛ توقفت المراجعة عند النقلة ${replay.failedPly}: ${replay.error}"
            }.onFailure { message = "فشل استيراد PGN: ${it.message}" }
        }
    }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                runtimeStatus = runtimeStatusStore.load()
                captureStarted = runtimeStatus.active
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(CaptureRuntimeStatusStore.ACTION_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }
    val calibrationStore = remember { BoardCalibrationStore(context) }
    val savedSettings = remember { calibrationStore.load() }
    var left by remember { mutableFloatStateOf(savedSettings?.calibration?.left ?: 0.05f) }
    var top by remember { mutableFloatStateOf(savedSettings?.calibration?.top ?: 0.10f) }
    var size by remember { mutableFloatStateOf(savedSettings?.calibration?.size ?: 0.80f) }
    var whiteAtBottom by remember { mutableStateOf(savedSettings?.calibration?.whiteAtBottom ?: true) }
    var theme by remember { mutableStateOf(savedSettings?.theme ?: "default") }
    var calibrationSaved by remember { mutableStateOf(savedSettings != null) }
    var templatePackRevision by remember { mutableIntStateOf(0) }
    val templatesAvailable = remember(theme, templatePackRevision) { themeTemplatesAvailable(context, theme) }
    val templateImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) {
            message = "لم يتم اختيار ملف القوالب."
        } else {
            runCatching { PieceTemplatePackStore(context).installZip(uri, theme) }
                .onSuccess {
                    templatePackRevision++
                    message = "تم تثبيت حزمة القوالب للثيم '$theme' (26 صورة PNG). احفظ المعايرة إذا غيّرت اسم الثيم."
                }
                .onFailure { message = "فشل استيراد حزمة القوالب: ${it.message}" }
        }
    }

    val captureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_TRAINING_REVIEW_MODE, trainingReviewMode)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            captureStarted = true
            message = "تم إرسال طلب التقاط الشاشة. راقب حالة التعرف الحية أدناه."
        } else {
            message = "لم تتم الموافقة على التقاط الشاشة."
        }
    }

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF101010)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("IRAQ CHESS HUB", color = Color(0xFFE53935), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Text("مساعد تحليل الشطرنج للأندرويد", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("وضع التدريب والمراجعة — التقييم الاحترافي", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodyMedium)
                StatusCard("الجهاز المستهدف", "HONOR · MagicOS 9 (إعداد مبدئي؛ لم يُختبر على جهازك)")
                StatusCard("التطبيقات المستهدفة", "Chess.com · Lichess · تطبيقات شطرنج أخرى حسب شكل الرقعة")
                StatusCard("نمط التحليل", "احترافي: تقييم بالأرقام + عمق البحث + النقلات المرشحة + تصنيف الخطأ")
                StatusCard("محرك التحليل", "Stockfish 19 حقيقي — تُبنى نسخة Android ARM64 تلقائياً مع APK عبر GitHub Actions")
                StatusCard("المرحلة الحالية", "الالتقاط والتعرّف والتحليل الحي قيد التحقق النهائي — التدريب والمراجعة فقط")

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202020))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("وضعية البداية (FEN موثوق)", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                        Text("ابدأ بالوضعية القياسية أو ألصق FEN الحالي من مصدر المباراة. لا يمكن للصورة وحدها معرفة دور اللعب أو حقوق التبييت.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = fenText,
                            onValueChange = { fenText = it; fenSaved = false },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("FEN — الحقول الستة") },
                            minLines = 2,
                            maxLines = 4,
                            singleLine = false
                        )
                        Button(modifier = Modifier.fillMaxWidth(), onClick = {
                            runCatching { seedStore.save(fenText) }
                                .onSuccess { parsed ->
                                    fenText = parsed.toFen()
                                    fenSaved = true
                                    message = "تم حفظ FEN بعد التحقق من الحقول والقطع والبيانات الوصفية."
                                }
                                .onFailure { fenSaved = false; message = "FEN غير صالح: ${it.message}" }
                        }) { Text("التحقق من FEN وحفظه") }
                        Text(if (fenSaved) "FEN: محفوظ وصالح" else "FEN: يحتاج تحققاً وحفظاً", color = if (fenSaved) Color(0xFF81C784) else Color(0xFFFFCC80))
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202020))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("استيراد ومراجعة مباراة PGN", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                        Text("اختر ملف PGN لعرض بيانات المباراة والتنقل بين الوضعيات التي تم التحقق منها. إذا احتوت المباراة على نقلة غير قانونية، تتوقف المراجعة عند آخر وضعية سليمة.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                            pgnImportLauncher.launch(arrayOf("application/x-chess-pgn", "text/plain", "application/octet-stream"))
                        }) { Text("اختيار ملف PGN") }
                        importedPgn?.let { game ->
                            Text("${game.white.ifBlank { "الأبيض" }} — ${game.black.ifBlank { "الأسود" }}", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${game.event.ifBlank { "مباراة" }} · النتيجة: ${game.result}", color = Color.LightGray)
                        }
                        pgnReplay?.let { replay ->
                            val maxPly = (replay.positions.size - 1).coerceAtLeast(0)
                            Text("الوضعية ${replayPly + 1} من ${replay.positions.size} · النقلات المنفذة: $replayPly", color = Color.White)
                            if (replayPly > 0) {
                                Text("آخر نقلة: ${game.sanMoves.getOrNull(replayPly - 1) ?: "—"}", color = Color(0xFFFFCC80))
                            } else {
                                Text("الوضعية الابتدائية", color = Color(0xFFFFCC80))
                            }
                            Slider(value = replayPly.toFloat(), onValueChange = { replayPly = it.toInt().coerceIn(0, maxPly) }, valueRange = 0f..maxPly.coerceAtLeast(1).toFloat(), enabled = maxPly > 0)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { replayPly = (replayPly - 1).coerceAtLeast(0) }, enabled = replayPly > 0) { Text("السابق") }
                                Button(onClick = { replayPly = (replayPly + 1).coerceAtMost(maxPly) }, enabled = replayPly < maxPly) { Text("التالي") }
                                OutlinedButton(onClick = { replayPly = 0 }, enabled = replayPly > 0) { Text("البداية") }
                            }
                            Text("FEN للوضعية الحالية:", color = Color(0xFF81C784), fontWeight = FontWeight.Bold)
                            Text(replay.positions[replayPly].toFen(), color = Color.White, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                                val selectedFen = replay.positions[replayPly].toFen()
                                runCatching { seedStore.save(selectedFen) }
                                    .onSuccess {
                                        fenText = selectedFen
                                        fenSaved = true
                                        message = "تم اعتماد FEN المحدد كبداية موثوقة للالتقاط بعد التأكد من مطابقة الرقعة الظاهرة."
                                    }
                                    .onFailure { message = "تعذر حفظ FEN المحدد: ${it.message}" }
                            }) { Text("اعتماد هذه الوضعية كبداية للالتقاط") }
                            if (!replay.complete) Text("توقف الاستيراد عند النقلة ${replay.failedPly}: ${replay.error}", color = Color(0xFFFFCC80))
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202020))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حدود الاستخدام", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Switch(checked = trainingReviewMode, onCheckedChange = { trainingReviewMode = it })
                            Text("أنا أستخدمه في التدريب أو مراجعة مباراة، وليس أثناء مباراة مصنفة مباشرة.", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202020))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("معايرة الرقعة يدوياً", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                        Text("الإزاحة الأفقية والعمودية نسبتان من عرض وارتفاع الشاشة. حجم الرقعة نسبة من أقصر بُعد؛ لذلك قد تختلف الحدود بين الوضعين العمودي والأفقي. إذا خرجت الرقعة عن الشاشة سيرفضها التطبيق بأمان.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Text("الإزاحة الأفقية: ${(left * 100).toInt()}%", color = Color.White)
                        Slider(value = left, onValueChange = { value -> left = value.coerceIn(0f, 1f); calibrationSaved = false }, valueRange = 0f..1f)
                        Text("الإزاحة العمودية: ${(top * 100).toInt()}%", color = Color.White)
                        Slider(value = top, onValueChange = { value -> top = value.coerceIn(0f, 1f); calibrationSaved = false }, valueRange = 0f..1f)
                        Text("حجم الرقعة: ${(size * 100).toInt()}% من أقصر بُعد للشاشة", color = Color.White)
                        Slider(value = size, onValueChange = { size = it.coerceIn(0.2f, 1f); calibrationSaved = false }, valueRange = 0.2f..1f)
                        OutlinedTextField(value = theme, onValueChange = { theme = it; calibrationSaved = false }, label = { Text("اسم مجموعة القطع (Theme)") }, singleLine = true)
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { templateImportLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }
                        ) { Text("استيراد حزمة القوالب ZIP (26 PNG)") }
                        Text(
                            if (templatesAvailable) "القوالب: 26/26 متوفرة لهذا الثيم" else "القوالب: غير مكتملة — استورد ZIP يحوي 26 PNG",
                            color = if (templatesAvailable) Color(0xFF81C784) else Color(0xFFFFCC80)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("الأبيض أسفل الرقعة", color = Color.White)
                            Switch(checked = whiteAtBottom, onCheckedChange = { whiteAtBottom = it; calibrationSaved = false })
                        }
                        Button(modifier = Modifier.fillMaxWidth(), onClick = {
                            val validTheme = com.iraqchesshub.vision.PieceTemplatePackSpec.isValidTheme(theme)
                            if (!validTheme) {
                                message = "اسم المجموعة غير صالح. استخدم أحرفاً إنجليزية وأرقاماً وشرطة فقط."
                            } else {
                                runCatching { calibrationStore.save(BoardCalibration(left, top, size, whiteAtBottom), theme) }
                                    .onSuccess {
                                        calibrationSaved = true
                                        message = if (themeTemplatesAvailable(context, theme)) "تم حفظ المعايرة ومجموعة القوالب متوفرة." else "تم حفظ المعايرة. استورد ZIP يحوي 26 صورة PNG لهذا الثيم حتى يبدأ التعرف."
                                    }
                                    .onFailure { message = "تعذر حفظ المعايرة: ${it.message}" }
                            }
                        }) { Text("حفظ المعايرة") }
                        Text(if (calibrationSaved) "المعايرة: محفوظة" else "المعايرة: لم تُحفظ بعد", color = if (calibrationSaved) Color(0xFF81C784) else Color(0xFFFFCC80))
                    }
                }

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        overlayReady = Settings.canDrawOverlays(context)
                        if (!overlayReady) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                            message = "فعّل السماح بالظهور فوق التطبيقات، ثم ارجع للتطبيق."
                        } else {
                            context.startService(Intent(context, ArrowOverlayService::class.java).apply {
                                action = ArrowOverlayService.ACTION_SHOW_DEMO
                            })
                            message = "تم طلب إظهار طبقة الأسهم التجريبية."
                        }
                    }
                ) { Text(if (overlayReady) "إظهار طبقة الأسهم التجريبية" else "السماح بالنافذة العائمة") }

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        when {
                            !trainingReviewMode -> message = "فعّل وضع التدريب/المراجعة فقط قبل بدء التحليل."
                            !calibrationSaved -> message = "احفظ معايرة الرقعة أولاً."
                            !fenSaved -> message = "تحقق من FEN واحفظه أولاً."
                            !templatesAvailable -> message = "استورد أولاً حزمة قوالب صحيحة تحتوي 26 صورة PNG لهذا الثيم."
                            else -> {
                                val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                captureLauncher.launch(manager.createScreenCaptureIntent())
                            }
                        }
                    },
                    enabled = calibrationSaved && fenSaved && trainingReviewMode && templatesAvailable
                ) { Text("بدء التقاط الشاشة بموافقتي") }

                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        context.stopService(Intent(context, ScreenCaptureService::class.java))
                        context.stopService(Intent(context, ArrowOverlayService::class.java))
                        captureStarted = false
                        message = "تم إيقاف خدمات الالتقاط والنافذة العائمة."
                    }
                ) { Text("إيقاف كل شيء", color = Color.White) }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF252525))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("الحالة", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(message, color = Color.White)
                        Text(runtimeStatus.message, color = Color(0xFFB0BEC5))
                        runtimeStatus.fen?.let { Text("FEN الحالي: $it", color = Color(0xFF81C784), style = MaterialTheme.typography.bodySmall) }
                        Text(if (runtimeStatus.active) "حالة الالتقاط: نشط" else "حالة الالتقاط: متوقف", color = Color.LightGray)
                    }
                }

                Text("ملاحظة تطويرية: التعرف يحتاج حزمة 26 قالب PNG مطابقة تماماً للوحة والقطع. التحليل يحتاج ملف Stockfish متوافقاً مع Android ARM64. لا تستخدم الأسهم أو التحليل أثناء اللعب المصنف المباشر.", color = Color(0xFFFFCC80), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202020))) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White)
        }
    }
}

private const val STARTING_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

private fun themeTemplatesAvailable(context: Context, theme: String): Boolean {
    if (!com.iraqchesshub.vision.PieceTemplatePackSpec.isValidTheme(theme)) return false
    if (runCatching { PieceTemplatePackStore(context).hasPack(theme) }.getOrDefault(false)) return true
    val files = runCatching { context.assets.list("piece_templates/$theme")?.toSet().orEmpty() }.getOrDefault(emptySet())
    return com.iraqchesshub.vision.PieceTemplatePackSpec.requiredFiles.all { it in files }
}
