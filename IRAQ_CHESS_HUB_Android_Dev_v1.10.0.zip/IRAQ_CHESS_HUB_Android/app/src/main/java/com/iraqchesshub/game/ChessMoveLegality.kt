package com.iraqchesshub.game

/**
 * Rules-level validation for a single observed chess move.
 *
 * This validates ordinary chess piece movement, captures, promotion, en-passant, castling,
 * attacked squares and king safety. It assumes the supplied FEN is the trusted game state;
 * it does not prove that an arbitrary imported historical position could have arisen legally.
 */
object ChessMoveLegality {
    /** Returns whether the requested side's king is currently attacked. */
    fun isInCheck(position: FenPosition, white: Boolean): Boolean {
        val king = if (white) 'K' else 'k'
        val kingSquare = position.toPieceMap().entries.firstOrNull { it.value == king }?.key ?: return true
        return isSquareAttacked(position.toPieceMap(), kingSquare, byWhite = !white)
    }

    /** Enumerates legal moves for the side to move; used for mate/stalemate adjudication. */
    fun hasAnyLegalMove(position: FenPosition): Boolean {
        val pieces = position.toPieceMap()
        val white = position.metadata.sideToMove == 'w'
        for ((from, piece) in pieces) {
            if (piece.isUpperCase() != white) continue
            for (file in 'a'..'h') for (rank in '1'..'8') {
                val to = "$file$rank"
                if (to == from) continue
                val isPawnPromotion = piece.lowercaseChar() == 'p' && rank in "18"
                val promotions = if (isPawnPromotion) listOf('q', 'r', 'b', 'n') else listOf(null)
                for (promotion in promotions) {
                    val capturedOn = when {
                        pieces[to] != null -> to
                        piece.lowercaseChar() == 'p' && from[0] != to[0] && position.metadata.enPassant == to -> "${to[0]}${from[1]}"
                        else -> null
                    }
                    val isCastle = piece.lowercaseChar() == 'k' && from[1] == to[1] && kotlin.math.abs(from[0] - to[0]) == 2
                    val move = MoveDeltaDetector.MoveDelta(
                        uci = from + to + (promotion?.toString() ?: ""),
                        from = from,
                        to = to,
                        promotion = promotion,
                        isCastling = isCastle,
                        capturedOn = capturedOn
                    )
                    if (isLegal(position, move)) return true
                }
            }
        }
        return false
    }

    fun isLegal(position: FenPosition, move: MoveDeltaDetector.MoveDelta): Boolean {
        if (!move.from.matches(SQUARE) || !move.to.matches(SQUARE) || move.from == move.to) return false
        if (move.uci != move.from + move.to + (move.promotion?.toString() ?: "")) return false

        val board = position.toPieceMap().toMutableMap()
        val moving = board[move.from] ?: return false
        val white = moving.isUpperCase()
        if ((position.metadata.sideToMove == 'w') != white) return false
        val target = board[move.to]
        if (target?.lowercaseChar() == 'k') return false
        if (target != null && target.isUpperCase() == white) return false

        if (move.isCastling) return isLegalCastle(position, move, board, moving, white)

        // A two-square king move is only valid through the explicit castling path above.
        if (moving.lowercaseChar() == 'k' && move.from[1] == move.to[1] &&
            kotlin.math.abs(move.from[0] - move.to[0]) == 2) return false

        val fromFile = move.from[0] - 'a'
        val fromRank = move.from[1].digitToInt()
        val toFile = move.to[0] - 'a'
        val toRank = move.to[1].digitToInt()
        val fileDelta = toFile - fromFile
        val rankDelta = toRank - fromRank
        var capturedSquare: String? = null

        when (moving.lowercaseChar()) {
            'p' -> {
                val direction = if (white) 1 else -1
                val startRank = if (white) 2 else 7
                val promotionRank = if (white) 8 else 1
                when {
                    fileDelta == 0 && rankDelta == direction -> {
                        if (target != null) return false
                    }
                    fileDelta == 0 && rankDelta == 2 * direction && fromRank == startRank -> {
                        val middle = square(fromFile, fromRank + direction)
                        if (target != null || board[middle] != null) return false
                    }
                    kotlin.math.abs(fileDelta) == 1 && rankDelta == direction -> {
                        if (target != null) {
                            if (target.isUpperCase() == white) return false
                            capturedSquare = move.to
                        } else {
                            // En-passant is legal only when the trusted FEN explicitly names
                            // this target and the opposing pawn is still on its capture square.
                            if (position.metadata.enPassant != move.to) return false
                            val capturedRank = fromRank
                            val captured = square(toFile, capturedRank)
                            val expectedPawn = if (white) 'p' else 'P'
                            if (board[captured] != expectedPawn) return false
                            capturedSquare = captured
                        }
                    }
                    else -> return false
                }
                if (move.to[1].digitToInt() == promotionRank) {
                    if (move.promotion == null || move.promotion !in PROMOTIONS) return false
                } else if (move.promotion != null) return false
            }
            'n' -> {
                if (move.promotion != null || !(
                        (kotlin.math.abs(fileDelta) == 1 && kotlin.math.abs(rankDelta) == 2) ||
                            (kotlin.math.abs(fileDelta) == 2 && kotlin.math.abs(rankDelta) == 1)
                    )) return false
                if (target != null) capturedSquare = move.to
            }
            'b' -> {
                if (move.promotion != null || kotlin.math.abs(fileDelta) != kotlin.math.abs(rankDelta) ||
                    !pathIsClear(board, fromFile, fromRank, toFile, toRank)) return false
                if (target != null) capturedSquare = move.to
            }
            'r' -> {
                if (move.promotion != null || (fileDelta != 0 && rankDelta != 0) ||
                    !pathIsClear(board, fromFile, fromRank, toFile, toRank)) return false
                if (target != null) capturedSquare = move.to
            }
            'q' -> {
                val straight = fileDelta == 0 || rankDelta == 0
                val diagonal = kotlin.math.abs(fileDelta) == kotlin.math.abs(rankDelta)
                if (move.promotion != null || (!straight && !diagonal) ||
                    !pathIsClear(board, fromFile, fromRank, toFile, toRank)) return false
                if (target != null) capturedSquare = move.to
            }
            'k' -> {
                if (move.promotion != null || kotlin.math.abs(fileDelta) > 1 || kotlin.math.abs(rankDelta) > 1) return false
                if (target != null) capturedSquare = move.to
            }
            else -> return false
        }

        if (move.capturedOn != capturedSquare) return false
        if (capturedSquare != null) {
            val captured = board[capturedSquare] ?: return false
            if (captured.isUpperCase() == white || captured.lowercaseChar() == 'k') return false
            board.remove(capturedSquare)
        }
        board.remove(move.from)
        val landed = if (move.promotion != null) {
            if (white) move.promotion.uppercaseChar() else move.promotion
        } else moving
        board[move.to] = landed

        val ownKing = if (white) 'K' else 'k'
        val kingSquare = board.entries.firstOrNull { it.value == ownKing }?.key ?: return false
        return !isSquareAttacked(board, kingSquare, byWhite = !white)
    }

    private fun isLegalCastle(
        position: FenPosition,
        move: MoveDeltaDetector.MoveDelta,
        board: MutableMap<String, Char>,
        moving: Char,
        white: Boolean
    ): Boolean {
        if (move.promotion != null || move.capturedOn != null) return false
        val castle = when (move.from + move.to) {
            "e1g1" -> Castle('K', 'K', "h1", "f1", listOf("f1", "g1"), listOf("f1", "g1"))
            "e1c1" -> Castle('K', 'Q', "a1", "d1", listOf("d1", "c1", "b1"), listOf("d1", "c1"))
            "e8g8" -> Castle('k', 'k', "h8", "f8", listOf("f8", "g8"), listOf("f8", "g8"))
            "e8c8" -> Castle('k', 'q', "a8", "d8", listOf("d8", "c8", "b8"), listOf("d8", "c8"))
            else -> return false
        }
        val king = if (white) 'K' else 'k'
        val rook = if (white) 'R' else 'r'
        if (moving != king || castle.king != king || castle.right !in position.metadata.castling ||
            board[move.from] != king || board[castle.rookFrom] != rook ||
            castle.emptySquares.any { board[it] != null }) return false

        if (isSquareAttacked(board, move.from, byWhite = !white)) return false

        // Test each king transit/destination square with the king moved off its origin.
        for (square in castle.kingPath) {
            val transitBoard = board.toMutableMap()
            transitBoard.remove(move.from)
            transitBoard[square] = king
            if (isSquareAttacked(transitBoard, square, byWhite = !white)) return false
        }

        board.remove(move.from)
        board.remove(castle.rookFrom)
        board[move.to] = king
        board[castle.rookTo] = rook
        val kingSquare = board.entries.firstOrNull { it.value == king }?.key ?: return false
        return !isSquareAttacked(board, kingSquare, byWhite = !white)
    }

    private fun pathIsClear(
        board: Map<String, Char>,
        fromFile: Int,
        fromRank: Int,
        toFile: Int,
        toRank: Int
    ): Boolean {
        val fileStep = (toFile - fromFile).compareTo(0)
        val rankStep = (toRank - fromRank).compareTo(0)
        var file = fromFile + fileStep
        var rank = fromRank + rankStep
        while (file != toFile || rank != toRank) {
            if (board[square(file, rank)] != null) return false
            file += fileStep
            rank += rankStep
        }
        return true
    }

    /** True when a square is attacked by the requested color, independent of pinned-piece legality. */
    private fun isSquareAttacked(board: Map<String, Char>, target: String, byWhite: Boolean): Boolean {
        val tf = target[0] - 'a'
        val tr = target[1].digitToInt()

        // Pawns attack diagonally forward, not along their movement direction.
        val pawnSourceRank = tr - if (byWhite) 1 else -1
        val pawn = if (byWhite) 'P' else 'p'
        for (df in intArrayOf(-1, 1)) {
            val file = tf + df
            if (file in 0..7 && pawnSourceRank in 1..8 && board[square(file, pawnSourceRank)] == pawn) return true
        }

        val knight = if (byWhite) 'N' else 'n'
        val knightOffsets = arrayOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        if (knightOffsets.any { (df, dr) ->
                val f = tf + df; val r = tr + dr
                f in 0..7 && r in 1..8 && board[square(f, r)] == knight
            }) return true

        val king = if (byWhite) 'K' else 'k'
        for (df in -1..1) for (dr in -1..1) {
            if (df == 0 && dr == 0) continue
            val f = tf + df; val r = tr + dr
            if (f in 0..7 && r in 1..8 && board[square(f, r)] == king) return true
        }

        val rays = listOf(
            Triple(1, 0, "rq"), Triple(-1, 0, "rq"),
            Triple(0, 1, "rq"), Triple(0, -1, "rq"),
            Triple(1, 1, "bq"), Triple(1, -1, "bq"),
            Triple(-1, 1, "bq"), Triple(-1, -1, "bq")
        )
        for ((df, dr, types) in rays) {
            var f = tf + df
            var r = tr + dr
            while (f in 0..7 && r in 1..8) {
                val piece = board[square(f, r)]
                if (piece != null) {
                    val sameColor = piece.isUpperCase() == byWhite
                    if (sameColor && piece.lowercaseChar() in types) return true
                    break
                }
                f += df
                r += dr
            }
        }
        return false
    }

    private fun square(file: Int, rank: Int): String = "${'a' + file}$rank"

    private data class Castle(
        val king: Char,
        val right: Char,
        val rookFrom: String,
        val rookTo: String,
        val emptySquares: List<String>,
        val kingPath: List<String>
    )

    private val SQUARE = Regex("[a-h][1-8]")
    private const val PROMOTIONS = "qrbn"
}
