package com.iraqchesshub.vision

/** Pure naming rules shared by the importer, UI, and tests. */
object PieceTemplatePackSpec {
    val requiredFiles: Set<String> = buildList {
        add("empty_light.png")
        add("empty_dark.png")
        for (piece in "PNBRQKpnbrqk") {
            add("${piece}_light.png")
            add("${piece}_dark.png")
        }
    }.toSet()

    fun isValidTheme(theme: String): Boolean = theme.matches(Regex("[A-Za-z0-9_-]{1,48}"))

    fun safeEntryFileName(path: String): String? {
        if (path.isBlank() || path.startsWith('/') || path.startsWith('\\') || '\\' in path) return null
        val parts = path.split('/')
        if (parts.any { it.isBlank() || it == "." || it == ".." }) return null
        if (parts.size !in 1..2) return null
        val fileName = parts.last()
        return fileName.takeIf { it in requiredFiles }
    }
}
