package com.iraqchesshub.engine

import com.iraqchesshub.analysis.EngineScore
import com.iraqchesshub.analysis.UciScoreParser
import com.iraqchesshub.game.FenPosition
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Minimal UCI process adapter. Requires a legally distributable Stockfish Android binary.
 * A dedicated reader thread prevents readLine() from defeating protocol timeouts.
 */
class StockfishUciEngine(private val executable: File) : AutoCloseable {
    private var process: Process? = null
    private var writer: OutputStreamWriter? = null
    private var output = LinkedBlockingQueue<String>()
    private var readerThread: Thread? = null
    @Volatile private var detectedEngineName: String? = null

    /** Engine identity returned by the UCI `id name` handshake line, when available. */
    val engineName: String? get() = detectedEngineName

    @Synchronized fun start() {
        check(process?.isAlive != true) { "Engine already running" }
        require(executable.exists()) { "Stockfish binary not installed: ${executable.absolutePath}" }
        require(executable.canExecute() || executable.setExecutable(true)) { "Cannot execute Stockfish binary" }
        output = LinkedBlockingQueue()
        detectedEngineName = null
        val child = ProcessBuilder(executable.absolutePath).redirectErrorStream(true).start()
        process = child
        writer = OutputStreamWriter(child.outputStream)
        readerThread = Thread({
            try {
                BufferedReader(InputStreamReader(child.inputStream)).use { reader ->
                    while (true) {
                        val line = reader.readLine()
                        if (line == null) {
                            output.put(EOF)
                            break
                        }
                        output.put(line)
                    }
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } catch (failure: Exception) {
                output.offer("__UCI_READER_ERROR__ ${failure.message.orEmpty()}")
            }
        }, "Stockfish-UCI-reader").apply { isDaemon = true; start() }

        try {
            send("uci")
            readUntil("uciok", STARTUP_TIMEOUT_SECONDS)
            send("isready")
            readUntil("readyok", STARTUP_TIMEOUT_SECONDS)
        } catch (failure: Exception) {
            terminateProcess()
            throw failure
        }
    }

    /** Configure conservative mobile defaults after the UCI handshake. */
    @Synchronized fun configure(threads: Int = 2, hashMb: Int = 128) {
        require(threads in 1..4) { "Threads must be between 1 and 4" }
        require(hashMb in 16..512) { "Hash must be between 16 and 512 MB" }
        check(process?.isAlive == true) { "Engine is not running" }
        try {
            send("setoption name Threads value $threads")
            send("setoption name Hash value $hashMb")
            send("isready")
            readUntil("readyok", STARTUP_TIMEOUT_SECONDS)
        } catch (failure: Exception) {
            terminateProcess()
            throw failure
        }
    }

    @Synchronized fun analyze(position: FenPosition, depth: Int = 12, timeoutSeconds: Long = ANALYSIS_TIMEOUT_SECONDS): EngineResult =
        analyze(position.toFen(), depth, timeoutSeconds)

    @Synchronized fun analyze(fen: String, depth: Int = 12, timeoutSeconds: Long = ANALYSIS_TIMEOUT_SECONDS): EngineResult {
        require(FenPosition.parse(fen) != null) { "Invalid or incomplete six-field FEN" }
        require(depth in 1..30)
        require(timeoutSeconds in 1..300)
        check(process?.isAlive == true) { "Engine is not running" }
        send("position fen $fen")
        send("go depth $depth")
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds)
        var bestMove: String? = null
        var score: EngineScore? = null
        var reachedDepth = 0
        var pv: List<String> = emptyList()
        try {
            while (bestMove == null) {
                val line = nextLine(deadline)
                if (line.startsWith("info ")) {
                    val tokens = line.trim().split(Regex("\\s+"))
                    val d = tokens.indexOf("depth")
                    if (d >= 0 && d + 1 < tokens.size) reachedDepth = tokens[d + 1].toIntOrNull() ?: reachedDepth
                    UciScoreParser.parse(line)?.let { score = it }
                    val p = tokens.indexOf("pv")
                    if (p >= 0 && p + 1 < tokens.size) pv = tokens.drop(p + 1)
                }
                if (line.startsWith("bestmove ")) {
                    bestMove = line.trim().split(Regex("\\s+" )).getOrNull(1)
                    if (bestMove == null || bestMove == "(none)") error("Engine returned no legal best move")
                }
            }
            return EngineResult(bestMove, score, reachedDepth, pv)
        } catch (failure: Exception) {
            // UCI has no request IDs. After a failed search, a late bestmove could be
            // mistaken for the next search result, so discard this process entirely.
            terminateProcess()
            throw failure
        }
    }

    private fun send(command: String) {
        writer?.apply { write(command); write("\n"); flush() } ?: error("Engine not started")
    }

    private fun readUntil(token: String, timeoutSeconds: Long) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds)
        while (true) {
            val line = nextLine(deadline).trim()
            if (line.startsWith("id name ")) detectedEngineName = line.removePrefix("id name ").trim()
            if (line == token) return
        }
    }

    private fun nextLine(deadlineNanos: Long): String {
        val remaining = deadlineNanos - System.nanoTime()
        if (remaining <= 0) error("Timed out waiting for Stockfish output")
        val line = output.poll(remaining, TimeUnit.NANOSECONDS)
            ?: error("Timed out waiting for Stockfish output")
        if (line == EOF) error("Stockfish process ended")
        if (line.startsWith("__UCI_READER_ERROR__")) error(line)
        return line
    }

    @Synchronized fun isRunning(): Boolean = process?.isAlive == true

    @Synchronized override fun close() {
        if (process?.isAlive == true) {
            runCatching { send("quit") }
            runCatching { process?.waitFor(1, TimeUnit.SECONDS) }
        }
        terminateProcess()
    }

    private fun terminateProcess() {
        val child = process
        runCatching { child?.destroy() }
        if (child?.isAlive == true) runCatching { child.destroyForcibly() }
        readerThread?.interrupt()
        runCatching { writer?.close() }
        process = null
        writer = null
        readerThread = null
        output.clear()
    }

    companion object {
        private const val STARTUP_TIMEOUT_SECONDS = 8L
        private const val ANALYSIS_TIMEOUT_SECONDS = 60L
        private const val EOF = "__UCI_EOF__"
    }
}

data class EngineResult(
    val bestMoveUci: String,
    val score: EngineScore?,
    val depth: Int,
    val principalVariationUci: List<String>
)
