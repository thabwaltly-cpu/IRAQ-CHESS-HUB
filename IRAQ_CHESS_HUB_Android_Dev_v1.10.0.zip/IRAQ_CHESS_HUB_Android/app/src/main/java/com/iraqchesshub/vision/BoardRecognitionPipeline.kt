package com.iraqchesshub.vision

import android.content.Context
import android.graphics.Bitmap
import com.iraqchesshub.game.FenMetadata
import com.iraqchesshub.game.FenPosition
import java.io.File

/**
 * Board vision pipeline. A calibrated, theme-specific template classifier can be installed
 * with [calibrated]. Without calibration/templates the safe default returns no detection.
 */
class BoardRecognitionPipeline(
    private val locator: ChessBoardLocator = NotImplementedBoardLocator(),
    private val classifier: ChessPieceClassifier = NotImplementedChessPieceClassifier()
) : AutoCloseable {
    fun process(frame: Bitmap): BoardObservation? {
        val bounds = locator.locate(frame) ?: return null
        val pieces = classifier.classify(frame, bounds) ?: return null
        if (pieces.size > 32 || pieces.any { !it.confidence.isFinite() || it.confidence !in 0f..1f }) return null
        val confidence = if (pieces.isEmpty()) 0f else pieces.map { it.confidence }.average().toFloat()
        if (confidence < 0.80f) return null
        return BoardObservation(bounds, pieces, confidence)
    }

    override fun close() {
        (classifier as? java.io.Closeable)?.close()
    }

    companion object {
        fun calibrated(
            context: Context,
            calibration: BoardCalibration,
            theme: String,
            templateDirectory: File? = null
        ): BoardRecognitionPipeline = BoardRecognitionPipeline(
            locator = CalibratedBoardLocator(calibration),
            classifier = TemplateChessPieceClassifier(
                context = context,
                theme = theme,
                whiteAtBottom = calibration.whiteAtBottom,
                templateDirectory = templateDirectory
            )
        )
    }
}

data class BoardBounds(val left: Int, val top: Int, val width: Int, val height: Int)
data class DetectedPiece(val square: String, val symbol: Char, val confidence: Float)
data class BoardObservation(val bounds: BoardBounds, val pieces: List<DetectedPiece>, val confidence: Float) {
    /** Safe snapshot representation for visual move-delta detection. */
    fun toPieceMap(): Map<String, Char>? {
        if (pieces.size > 32 || pieces.map { it.square }.toSet().size != pieces.size) return null
        if (pieces.any { !it.confidence.isFinite() || it.confidence !in 0.80f..1.0f ||
                    !it.square.matches(Regex("[a-h][1-8]")) || it.symbol !in "pnbrqkPNBRQK" }) return null
        return pieces.associate { it.square to it.symbol }
    }

    /** Creates a complete FEN only when the caller supplies trusted game metadata. */
    fun toFenPosition(metadata: FenMetadata): FenPosition? =
        if (confidence.isFinite() && confidence >= 0.80f) FenPosition.fromPieces(pieces, metadata) else null

    /** Converts recognized piece placement to the placement field of a FEN string. */
    fun toFenPlacement(): String? {
        if (pieces.size > 32 || pieces.map { it.square }.toSet().size != pieces.size) return null
        if (pieces.any { it.square.length != 2 || it.square[0] !in 'a'..'h' || it.square[1] !in '1'..'8' || it.symbol !in "pnbrqkPNBRQK" || !it.confidence.isFinite() || it.confidence !in 0.80f..1.0f }) return null
        val board = Array(8) { CharArray(8) { '1' } }
        for (piece in pieces) {
            val file = piece.square[0] - 'a'
            val rank = piece.square[1] - '1'
            board[7 - rank][file] = piece.symbol
        }
        return board.joinToString("/") { row ->
            val out = StringBuilder(); var empties = 0
            for (cell in row) {
                if (cell == '1') empties++ else {
                    if (empties > 0) { out.append(empties); empties = 0 }
                    out.append(cell)
                }
            }
            if (empties > 0) out.append(empties)
            out.toString()
        }
    }
}

interface ChessBoardLocator { fun locate(frame: Bitmap): BoardBounds? }
interface ChessPieceClassifier { fun classify(frame: Bitmap, bounds: BoardBounds): List<DetectedPiece>? }

private class NotImplementedBoardLocator : ChessBoardLocator {
    override fun locate(frame: Bitmap): BoardBounds? = null
}
private class NotImplementedChessPieceClassifier : ChessPieceClassifier {
    override fun classify(frame: Bitmap, bounds: BoardBounds): List<DetectedPiece>? = null
}
