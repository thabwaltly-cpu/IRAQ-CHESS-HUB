package com.iraqchesshub.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import java.io.Closeable
import java.io.File
import kotlin.math.abs

/**
 * Per-theme template classifier for calibrated 8x8 boards.
 *
 * Required assets: an app-private imported theme directory or assets/piece_templates/<theme>/
 * Template names: empty_light, empty_dark, P_light, P_dark ... k_dark.
 * Each template must be a crop of one complete square (including its square background).
 * This is a starter classifier, not a universal neural model: a separate template set is
 * needed for each board theme/piece set and confidence must be checked before trusting output.
 */
class TemplateChessPieceClassifier(
    context: Context,
    private val theme: String,
    private val whiteAtBottom: Boolean = true,
    private val minimumConfidence: Float = 0.82f,
    private val maximumDistance: Float = 0.20f,
    private val templateDirectory: File? = null
) : ChessPieceClassifier, Closeable {
    private val assets = context.applicationContext.assets
    private val templates: List<Template>

    init {
        require(PieceTemplatePackSpec.isValidTheme(theme)) { "Invalid theme name" }
        val names = buildList {
            add("empty_light"); add("empty_dark")
            for (piece in "PNBRQKpnbrqk") { add("${piece}_light"); add("${piece}_dark") }
        }
        templates = names.mapNotNull { name ->
            runCatching {
                val bitmap = if (templateDirectory != null) {
                    val file = File(templateDirectory, "$name.png")
                    if (!file.isFile) return@runCatching null
                    android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                } else {
                    assets.open("piece_templates/$theme/$name.png").use {
                        android.graphics.BitmapFactory.decodeStream(it)
                    }
                } ?: return@runCatching null
                Template(name, feature(bitmap).also { bitmap.recycle() })
            }.getOrNull()
        }
        require(templates.size == 26) {
            "Theme '$theme' needs all 26 PNG templates in the imported pack or assets/piece_templates/$theme/"
        }
    }

    override fun classify(frame: Bitmap, bounds: BoardBounds): List<DetectedPiece>? {
        if (bounds.width <= 0 || bounds.height <= 0 || bounds.left < 0 || bounds.top < 0 ||
            bounds.left + bounds.width > frame.width || bounds.top + bounds.height > frame.height) return null
        if (kotlin.math.abs(bounds.width - bounds.height) > maxOf(bounds.width, bounds.height) * 0.04f) return null

        val output = ArrayList<DetectedPiece>(32)
        for (screenRow in 0 until 8) {
            for (screenCol in 0 until 8) {
                val cellW = bounds.width / 8f
                val cellH = bounds.height / 8f
                val l = bounds.left + (screenCol * cellW).toInt()
                val t = bounds.top + (screenRow * cellH).toInt()
                val r = bounds.left + ((screenCol + 1) * cellW).toInt()
                val b = bounds.top + ((screenRow + 1) * cellH).toInt()
                if (r <= l || b <= t) return null
                val crop = Bitmap.createBitmap(frame, l, t, r - l, b - t)
                val vector = try { feature(crop) } finally { crop.recycle() }
                val ranked = templates.map { it.name to distance(vector, it.vector) }.sortedBy { it.second }
                val best = ranked.firstOrNull() ?: return null
                val second = ranked.getOrNull(1)?.second ?: 1f
                val confidence = (1f - best.second / maximumDistance).coerceIn(0f, 1f)
                if (best.second > maximumDistance || confidence < minimumConfidence || second - best.second < 0.008f) return null
                if (!best.first.startsWith("empty_")) {
                    val file = if (whiteAtBottom) screenCol else 7 - screenCol
                    val rank = if (whiteAtBottom) 7 - screenRow else screenRow
                    output += DetectedPiece("${'a' + file}${rank + 1}", best.first[0], confidence)
                }
            }
        }
        return output
    }

    private fun feature(bitmap: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(bitmap, FEATURE_SIZE, FEATURE_SIZE, true)
        val result = FloatArray(FEATURE_SIZE * FEATURE_SIZE * 3)
        var index = 0
        for (y in 0 until FEATURE_SIZE) for (x in 0 until FEATURE_SIZE) {
            val color = scaled.getPixel(x, y)
            result[index++] = Color.red(color) / 255f
            result[index++] = Color.green(color) / 255f
            result[index++] = Color.blue(color) / 255f
        }
        if (scaled !== bitmap) scaled.recycle()
        return result
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        var total = 0f
        for (i in a.indices) total += abs(a[i] - b[i])
        return total / a.size
    }

    override fun close() { /* template vectors are managed by the GC */ }

    private data class Template(val name: String, val vector: FloatArray)

    companion object { private const val FEATURE_SIZE = 24 }
}
