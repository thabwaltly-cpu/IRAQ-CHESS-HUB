package com.iraqchesshub.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/** Full-screen transparent overlay. Coordinates are normalized to the full display. */
class ArrowOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var arrowView: ArrowCanvasView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_SHOW_DEMO -> showOverlay(demo = true)
            ACTION_SHOW_MOVE -> {
                val move = intent.getStringExtra(EXTRA_UCI_MOVE).orEmpty()
                val left = intent.getFloatExtra(EXTRA_BOARD_LEFT, 0.1f)
                val top = intent.getFloatExtra(EXTRA_BOARD_TOP, 0.2f)
                val size = intent.getFloatExtra(EXTRA_BOARD_SIZE, 0.8f)
                val boardWidth = intent.getFloatExtra(EXTRA_BOARD_WIDTH, size)
                val boardHeight = intent.getFloatExtra(EXTRA_BOARD_HEIGHT, size)
                val whiteAtBottom = intent.getBooleanExtra(EXTRA_WHITE_AT_BOTTOM, true)
                val arrow = BoardArrowMapper.map(move, left, top, boardWidth, boardHeight, whiteAtBottom)
                if (arrow != null) showOverlay(demo = false, arrow = arrow)
            }
        }
        return START_NOT_STICKY
    }

    private fun showOverlay(demo: Boolean, arrow: FloatArray? = null) {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (arrowView != null) {
            if (demo) arrowView?.setArrow(0.28f, 0.60f, 0.49f, 0.39f)
            else arrow?.let { arrowView?.setArrow(it[0], it[1], it[2], it[3]) }
            return
        }
        arrowView = ArrowCanvasView(this).apply {
            if (demo) setArrow(0.28f, 0.60f, 0.49f, 0.39f)
            else arrow?.let { setArrow(it[0], it[1], it[2], it[3]) }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager?.addView(arrowView, params)
    }

    override fun onDestroy() {
        arrowView?.let { view -> runCatching { windowManager?.removeView(view) } }
        arrowView = null
        windowManager = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW_DEMO = "com.iraqchesshub.overlay.SHOW_DEMO"
        const val ACTION_SHOW_MOVE = "com.iraqchesshub.overlay.SHOW_MOVE"
        const val ACTION_HIDE = "com.iraqchesshub.overlay.HIDE"
        const val EXTRA_UCI_MOVE = "uci_move"
        const val EXTRA_BOARD_LEFT = "board_left_norm"
        const val EXTRA_BOARD_TOP = "board_top_norm"
        const val EXTRA_BOARD_SIZE = "board_size_norm"
        const val EXTRA_BOARD_WIDTH = "board_width_norm"
        const val EXTRA_BOARD_HEIGHT = "board_height_norm"
        const val EXTRA_WHITE_AT_BOTTOM = "white_at_bottom"
    }
}

private class ArrowCanvasView(context: android.content.Context) : View(context) {
    private val shaft = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 55, 55); strokeWidth = 12f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 55, 55); style = Paint.Style.FILL
    }
    private var points: FloatArray? = null

    fun setArrow(x1: Float, y1: Float, x2: Float, y2: Float) {
        points = floatArrayOf(x1, y1, x2, y2)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = points ?: return
        val sx = p[0] * width; val sy = p[1] * height
        val ex = p[2] * width; val ey = p[3] * height
        canvas.drawLine(sx, sy, ex, ey, shaft)
        val angle = kotlin.math.atan2((ey - sy).toDouble(), (ex - sx).toDouble())
        val length = 34f
        val path = Path().apply {
            moveTo(ex, ey)
            lineTo((ex - length * kotlin.math.cos(angle - 0.55)).toFloat(), (ey - length * kotlin.math.sin(angle - 0.55)).toFloat())
            lineTo((ex - length * kotlin.math.cos(angle + 0.55)).toFloat(), (ey - length * kotlin.math.sin(angle + 0.55)).toFloat())
            close()
        }
        canvas.drawPath(path, head)
    }
}


/** Maps a UCI move such as e2e4 to screen-normalized square centers. */
object BoardArrowMapper {
    /** Backward-compatible square-board overload. */
    fun map(
        uciMove: String,
        boardLeft: Float,
        boardTop: Float,
        boardSize: Float,
        whiteAtBottom: Boolean
    ): FloatArray? = map(uciMove, boardLeft, boardTop, boardSize, boardSize, whiteAtBottom)

    /** Uses independent normalized width/height so square boards map correctly on any display aspect. */
    fun map(
        uciMove: String,
        boardLeft: Float,
        boardTop: Float,
        boardWidth: Float,
        boardHeight: Float,
        whiteAtBottom: Boolean
    ): FloatArray? {
        if (uciMove.length !in 4..5 || boardWidth <= 0f || boardHeight <= 0f) return null
        if (boardLeft < 0f || boardTop < 0f || boardLeft + boardWidth > 1f || boardTop + boardHeight > 1f) return null
        val from = squareCenter(uciMove.substring(0, 2), boardLeft, boardTop, boardWidth, boardHeight, whiteAtBottom) ?: return null
        val to = squareCenter(uciMove.substring(2, 4), boardLeft, boardTop, boardWidth, boardHeight, whiteAtBottom) ?: return null
        return floatArrayOf(from.first, from.second, to.first, to.second)
    }

    private fun squareCenter(
        square: String, left: Float, top: Float, width: Float, height: Float, whiteAtBottom: Boolean
    ): Pair<Float, Float>? {
        if (square.length != 2 || square[0] !in 'a'..'h' || square[1] !in '1'..'8') return null
        val file = square[0] - 'a'
        val rank = square[1] - '1'
        val col = if (whiteAtBottom) file else 7 - file
        val row = if (whiteAtBottom) 7 - rank else rank
        val cellWidth = width / 8f
        val cellHeight = height / 8f
        return (left + (col + 0.5f) * cellWidth) to (top + (row + 0.5f) * cellHeight)
    }
}
