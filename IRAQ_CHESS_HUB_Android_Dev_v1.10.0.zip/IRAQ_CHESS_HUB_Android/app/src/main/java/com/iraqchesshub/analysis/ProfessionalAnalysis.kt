package com.iraqchesshub.analysis

import kotlin.math.abs

/**
 * Converts UCI engine scores into a consistent White-perspective evaluation and
 * estimates the quality of a move for training/review. Scores are centipawns.
 */
enum class SideToMove { WHITE, BLACK }

enum class MoveQuality(val arabic: String) {
    BRILLIANT("نقلة قوية جداً"),
    GOOD("نقلة جيدة"),
    INACCURACY("عدم دقة"),
    MISTAKE("خطأ"),
    BLUNDER("خطأ فادح")
}

data class EngineScore(
    val centipawns: Int? = null,
    val mateIn: Int? = null
) {
    init { require(centipawns != null || mateIn != null) }

    /** White-positive pawns. Mate is represented separately, never flattened to cp. */
    fun whitePerspective(sideToMove: SideToMove): WhiteEvaluation = when {
        mateIn != null -> WhiteEvaluation(mateIn = if (sideToMove == SideToMove.WHITE) mateIn else -mateIn)
        else -> {
            val cp = centipawns!! * if (sideToMove == SideToMove.WHITE) 1 else -1
            WhiteEvaluation(pawns = cp / 100.0)
        }
    }
}

data class WhiteEvaluation(val pawns: Double? = null, val mateIn: Int? = null) {
    fun display(): String = when {
        mateIn != null && mateIn > 0 -> "مات للأبيض خلال $mateIn نقلات"
        mateIn != null && mateIn < 0 -> "مات للأسود خلال ${abs(mateIn)} نقلات"
        mateIn == 0 -> "مات"
        else -> {
            val value = pawns ?: 0.0
            val sign = if (value > 0) "+" else ""
            sign + String.format(java.util.Locale.US, "%.2f", value)
        }
    }
}

data class MoveReview(
    val lossCentipawns: Int,
    val quality: MoveQuality,
    val explanationArabic: String
)

object ProfessionalAnalyzer {
    /**
     * Compare the position before and after a move from the mover's point of view.
     * Scores must be engine scores for the respective side-to-move positions.
     * Mate scores are handled conservatively and not assigned a numeric centipawn loss.
     */
    fun reviewMove(
        before: EngineScore,
        after: EngineScore,
        mover: SideToMove
    ): MoveReview? {
        if (before.mateIn != null || after.mateIn != null) return null
        val beforeWhite = before.whitePerspective(mover).pawns ?: return null
        val afterSide = if (mover == SideToMove.WHITE) SideToMove.BLACK else SideToMove.WHITE
        val afterWhite = after.whitePerspective(afterSide).pawns ?: return null
        val moverSign = if (mover == SideToMove.WHITE) 1.0 else -1.0
        val loss = ((beforeWhite - afterWhite) * moverSign * 100.0).toInt().coerceAtLeast(0)
        val quality = when {
            loss <= 15 -> MoveQuality.GOOD
            loss <= 50 -> MoveQuality.INACCURACY
            loss <= 100 -> MoveQuality.MISTAKE
            else -> MoveQuality.BLUNDER
        }
        val explanation = when (quality) {
            MoveQuality.GOOD -> "حافظت على أفضلية الموقف تقريباً."
            MoveQuality.INACCURACY -> "النقلة أضعفت الموقف قليلاً؛ راجع النقلات المرشحة."
            MoveQuality.MISTAKE -> "خسرت جزءاً ملحوظاً من التقييم؛ ابحث عن تهديد الخصم."
            MoveQuality.BLUNDER -> "النقلة سببت تراجعاً كبيراً؛ افحص القطع المعلّقة والتكتيكات."
            MoveQuality.BRILLIANT -> "تستحق مراجعة أعمق للتأكد من وجود فكرة تكتيكية."
        }
        return MoveReview(loss, quality, explanation)
    }

    fun qualityForLoss(lossCentipawns: Int): MoveQuality = when {
        lossCentipawns <= 15 -> MoveQuality.GOOD
        lossCentipawns <= 50 -> MoveQuality.INACCURACY
        lossCentipawns <= 100 -> MoveQuality.MISTAKE
        else -> MoveQuality.BLUNDER
    }
}

/** Parses the score portion of a Stockfish UCI `info` line. */
object UciScoreParser {
    fun parse(line: String): EngineScore? {
        val tokens = line.trim().split(Regex("\\s+"))
        val scoreIndex = tokens.indexOf("score")
        if (scoreIndex < 0 || scoreIndex + 2 >= tokens.size) return null
        return when (tokens[scoreIndex + 1]) {
            "cp" -> tokens[scoreIndex + 2].toIntOrNull()?.let { EngineScore(centipawns = it) }
            "mate" -> tokens[scoreIndex + 2].toIntOrNull()?.let { EngineScore(mateIn = it) }
            else -> null
        }
    }
}
