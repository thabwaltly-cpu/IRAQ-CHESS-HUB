package com.iraqchesshub.game

/**
 * Converts a sequence of stable, high-confidence board snapshots into one-shot position updates.
 *
 * The caller must seed this tracker from a trusted starting FEN/PGN state. A screenshot cannot
 * establish side-to-move, castling history, en-passant history, or move counters by itself.
 * A detected transition is also checked against standard chess movement and king-safety rules.
 */
class LiveBoardTracker(
    requiredStableFrames: Int = 3,
    private val minimumConfidence: Float = 0.80f
) {
    private val stabilityGate = PositionStabilityGate(requiredStableFrames)
    private var previousBoard: Map<String, Char>? = null
    private var metadata: FenMetadata? = null
    private var position: FenPosition? = null
    private val positionHistory = mutableListOf<FenPosition>()

    init {
        require(minimumConfidence.isFinite() && minimumConfidence in 0f..1f)
    }

    enum class Rejection {
        INVALID_CONFIDENCE,
        INVALID_BOARD,
        NO_SINGLE_MOVE,
        TRANSITION_MISMATCH,
        ILLEGAL_MOVE,
        METADATA_MISMATCH,
        INVALID_FEN,
        GAME_FINISHED
    }

    sealed class Update {
        data object WaitingForStability : Update()
        data object NeedsTrustedSeed : Update()
        data class Unchanged(val position: FenPosition) : Update()
        data class MoveAccepted(
            val move: MoveDeltaDetector.MoveDelta,
            val position: FenPosition
        ) : Update()
        data class Rejected(val reason: Rejection) : Update()
    }

    /**
     * Seeds the stable current board with metadata from a trusted FEN or PGN/game-history source.
     * Call only after the visible board has already been confirmed stable by the caller.
     */
    @Synchronized
    fun seed(board: Map<String, Char>, trustedMetadata: FenMetadata): FenPosition? {
        val snapshot = board.toMap()
        if (!isValidBoard(snapshot)) return null
        val seeded = FenPosition.fromPieceMap(snapshot, trustedMetadata) ?: return null
        previousBoard = snapshot
        metadata = trustedMetadata
        position = seeded
        positionHistory.clear()
        positionHistory += seeded
        stabilityGate.reset()
        return seeded
    }

    /** Accepts a recognized snapshot. A move is emitted only once after N matching snapshots. */
    @Synchronized
    fun accept(board: Map<String, Char>, confidence: Float): Update {
        if (!confidence.isFinite() || confidence !in minimumConfidence..1.0f) {
            stabilityGate.reset()
            return Update.Rejected(Rejection.INVALID_CONFIDENCE)
        }
        val snapshot = board.toMap()
        if (!isValidBoard(snapshot)) {
            stabilityGate.reset()
            return Update.Rejected(Rejection.INVALID_BOARD)
        }
        if (!stabilityGate.accept(canonicalKey(snapshot))) return Update.WaitingForStability

        val before = previousBoard ?: return Update.NeedsTrustedSeed
        val current = position ?: return Update.NeedsTrustedSeed
        if (currentOutcome()?.isTerminal() == true) return Update.Rejected(Rejection.GAME_FINISHED)
        if (snapshot == before) return Update.Unchanged(current)

        val move = MoveDeltaDetector.detect(before, snapshot)
            ?: return Update.Rejected(Rejection.NO_SINGLE_MOVE)
        if (!transitionMatches(before, snapshot, move)) {
            return Update.Rejected(Rejection.TRANSITION_MISMATCH)
        }
        if (!ChessMoveLegality.isLegal(current, move)) {
            return Update.Rejected(Rejection.ILLEGAL_MOVE)
        }
        val nextMetadata = FenMetadataTracker.afterMove(metadata ?: return Update.NeedsTrustedSeed, before, move)
            ?: return Update.Rejected(Rejection.METADATA_MISMATCH)
        val nextPosition = FenPosition.fromPieceMap(snapshot, nextMetadata)
            ?: return Update.Rejected(Rejection.INVALID_FEN)

        // Commit only after every validation passes. Rejected frames never corrupt game state.
        previousBoard = snapshot
        metadata = nextMetadata
        position = nextPosition
        positionHistory += nextPosition
        return Update.MoveAccepted(move, nextPosition)
    }

    @Synchronized
    fun currentPosition(): FenPosition? = position

    /** Game state derived from every accepted position since the trusted seed. */
    @Synchronized
    fun currentOutcome(): GameOutcome? = position?.let { GameAdjudicator.evaluate(it, positionHistory) }

    @Synchronized
    fun reset() {
        previousBoard = null
        metadata = null
        position = null
        positionHistory.clear()
        stabilityGate.reset()
    }

    private fun isValidBoard(board: Map<String, Char>): Boolean =
        board.size in 2..32 &&
            board.all { (square, piece) -> square.matches(SQUARE) && piece in PIECES } &&
            board.values.count { it == 'K' } == 1 &&
            board.values.count { it == 'k' } == 1

    private fun canonicalKey(board: Map<String, Char>): String =
        board.toSortedMap().entries.joinToString("|") { (square, piece) -> "$square$piece" }

    /** Replays the detected delta and requires an exact match with the next observed snapshot. */
    private fun transitionMatches(
        before: Map<String, Char>,
        after: Map<String, Char>,
        move: MoveDeltaDetector.MoveDelta
    ): Boolean {
        if (!move.from.matches(SQUARE) || !move.to.matches(SQUARE)) return false
        if (move.uci != move.from + move.to + (move.promotion?.toString() ?: "")) return false
        val moving = before[move.from] ?: return false
        if (move.capturedOn != null && !move.capturedOn.matches(SQUARE)) return false

        val expected = before.toMutableMap()
        expected.remove(move.from)

        if (move.isCastling) {
            val rookMove = when (move.from + move.to) {
                "e1g1" -> "h1" to "f1"
                "e1c1" -> "a1" to "d1"
                "e8g8" -> "h8" to "f8"
                "e8c8" -> "a8" to "d8"
                else -> return false
            }
            val rook = if (moving == 'K') 'R' else if (moving == 'k') 'r' else return false
            val pathSquares = when (move.from + move.to) {
                "e1g1" -> listOf("f1", "g1")
                "e1c1" -> listOf("d1", "c1", "b1")
                "e8g8" -> listOf("f8", "g8")
                "e8c8" -> listOf("d8", "c8", "b8")
                else -> return false
            }
            if (before[rookMove.first] != rook || pathSquares.any { before[it] != null }) return false
            expected.remove(rookMove.first)
            expected[rookMove.second] = rook
            expected[move.to] = moving
            return expected == after
        }

        if (move.capturedOn != null) {
            val captured = expected.remove(move.capturedOn) ?: return false
            if (captured.isUpperCase() == moving.isUpperCase()) return false
        } else if (before[move.to] != null) {
            return false
        }

        val landed = after[move.to] ?: return false
        val expectedLanded = if (move.promotion != null) {
            if (moving.lowercaseChar() != 'p' || move.to[1] !in "18" || move.promotion !in "qrbn") return false
            if (moving.isUpperCase()) move.promotion.uppercaseChar() else move.promotion
        } else {
            if (moving.lowercaseChar() == 'p' && move.to[1] in "18") return false
            moving
        }
        if (landed != expectedLanded) return false
        expected.remove(move.to)
        expected[move.to] = expectedLanded
        return expected == after
    }

    companion object {
        private val SQUARE = Regex("[a-h][1-8]")
        private const val PIECES = "pnbrqkPNBRQK"
    }
}


private fun GameOutcome.isTerminal(): Boolean = when (this) {
    GameOutcome.ONGOING,
    GameOutcome.FIFTY_MOVE_CLAIM_AVAILABLE,
    GameOutcome.THREEFOLD_REPETITION_CLAIM_AVAILABLE -> false
    else -> true
}
